"use strict";
var gamePingPong;
(function (gamePingPong) {
    var APaddle = /** @class */ (function () {
        function APaddle(x, y, width, height, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawimg();
        }
        APaddle.prototype.drawimg = function () {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        return APaddle;
    }());
    gamePingPong.APaddle = APaddle;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var Ball = /** @class */ (function () {
        function Ball(x, y, radius, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = 2 * radius;
            this.width = 2 * radius;
            this.stage = stage;
            this.drawimg();
        }
        Ball.prototype.drawimg = function () {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawCircle(this.x, this.y, this.width / 2);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        return Ball;
    }());
    gamePingPong.Ball = Ball;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var Bound = /** @class */ (function () {
        function Bound(x, y, width, height, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawimg();
        }
        Bound.prototype.drawimg = function () {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        return Bound;
    }());
    gamePingPong.Bound = Bound;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var MainGame = /** @class */ (function () {
        function MainGame() {
            this.app = new PIXI.Application(800, 600, { backgroundColor: 0x451542 });
            document.body.appendChild(this.app.view);
            this.ball = new gamePingPong.Ball(450, 10, 10, this.app);
            this.boundTop = new gamePingPong.Bound(0, 0, 800, 0, this.app);
            this.boundLeft = new gamePingPong.Bound(0, 0, 0, 600, this.app);
            this.boundRight = new gamePingPong.Bound(800, 0, 0, 600, this.app);
            this.boundBottom = new gamePingPong.Bound(0, 600, 800, 0, this.app);
            this.paddle1 = new gamePingPong.APaddle(10, 10, 10, 100, this.app);
            this.paddle2 = new gamePingPong.APaddle(780, 10, 10, 100, this.app);
        }
        return MainGame;
    }());
    gamePingPong.MainGame = MainGame;
    var ob1 = new MainGame();
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var Paddle = /** @class */ (function () {
        function Paddle(x, y, width, height, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawimg();
        }
        Paddle.prototype.drawimg = function () {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        return Paddle;
    }());
    gamePingPong.Paddle = Paddle;
})(gamePingPong || (gamePingPong = {}));
