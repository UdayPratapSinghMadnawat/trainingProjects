
namespace gamePingPong {
export class MainGame {
 app : PIXI.Application;
 paddle1: APaddle;
 paddle2: APaddle;
 boundTop : Bound;
 boundRight: Bound;
 boundLeft: Bound;
 boundBottom: Bound;
 ball:  Ball;
 
 
  constructor() {
     this.app = new PIXI.Application(800,600,{backgroundColor:0x451542});
     document.body.appendChild(this.app.view);
            this.ball = new Ball(450, 10, 10, this.app);
            this.boundTop = new Bound(0, 0, 800, 0, this.app);
            this.boundLeft = new Bound(0, 0, 0, 600, this.app);
            this.boundRight = new Bound(800, 0, 0, 600, this.app);
            this.boundBottom = new Bound(0, 600, 800, 0, this.app);
      this.paddle1 = new APaddle(10, 10, 10, 100, this.app);
      this.paddle2 = new APaddle(780, 10, 10, 100, this.app);
            
            
            

  }
}

var ob1 = new MainGame();
}