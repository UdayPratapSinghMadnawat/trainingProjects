class RigidBodies {  
    private x1: number;
    private y1: number;
    private x2: number;
    private y2: number;


    constructor(x1:number ,x2: number,y1: number,y2: number) {
        this.x1=x1;
        this.x2=x2;
        this.y1=y1;
        this.y2=y2;
        

    }
}