namespace gamePingPong {
    /// <reference path="Ball.ts" />
    
     export class PingPongGameController extends GameController {
         collider!:Collider;
         app!: PIXI.Application;
         paddle1!: APaddle  ;
         paddle2!: APaddle  ;
         boundTop!: Bound  ;
         boundRight!: Bound  ;
         boundLeft!: Bound  ;
         boundBottom!: Bound 
         ball!: Ball;
moveVelocityX:number=2;
moveVelocityY:number=2;

start() {
var sw: number = this.app.screen.width;
var sh: number = this.app.screen.height;
    this.ball = new Ball(sw/2-50, sh/60, sh/60, this.app);
    this.boundTop = new Bound(0, 0, sw, sh/300, this.app);
    this.boundLeft = new Bound(0, 0, sw/400, sh, this.app);
    this.boundRight = new Bound(sw-2, 0, 2, sh, this.app);
    this.boundBottom = new Bound(0, sh-2, sw, 2, this.app);
    this.paddle1 = new APaddle(sw/80, sh/60, sw/80, sh/4, this.app);
    this.paddle2 = new APaddle(sw-sw/40,sh/60 , sw/80,sh/4, this.app);
    this.collider = new Collider();
}
makeUpdation(delta :number) {

      let _this = this; 
    //move ball 
    moveBall();

    function moveBall(): any {
        _this.ball.moveTo(_this.moveVelocityX, _this.moveVelocityY);
    }


    //move paddle 
 movePaddle();
 function movePaddle() {
    movePaddle1();
    movePaddle2();
     
function movePaddle1() {
    _this.paddle1.moveTo(_this.paddle1.x, _this.moveVelocityY);
}


function movePaddle2() {

    let x1 =  _this.app.renderer.plugins.interaction.mouse.global.x;
    let y1 =  _this.app.renderer.plugins.interaction.mouse.global.y;
     if(y1 < 0)
         y1 = 0;
 if(y1 > _this.app.screen.height)
        y1 = _this.app.screen.height;

     _this.paddle2.y = y1;
     _this.paddle2.graphics.position.y = y1-_this.paddle2.height/2;

  // _this.paddle2.moveTo(_this.paddle2.x, y1-_this.paddle2.height / 2);

}
}


    // handle  collision 
handleCollision();

    function handleCollision() { 
        _this.collider.isCollide(_this.paddle1,_this.ball,()=>{ 
            _this.moveVelocityX *= -1;
            
        });

        _this.collider.isCollide(_this.paddle2, _this.ball, ()=>{
            _this.moveVelocityX *= -1;
           
        });

        _this.collider.isCollide(_this.boundBottom, _this.ball, ()=>{
            _this.moveVelocityY *= -1;
            
        });
        _this.collider.isCollide(_this.boundLeft, _this.ball, ()=>{
            _this.moveVelocityX *= -1;
           
        });
        _this.collider.isCollide(_this.boundTop, _this.ball, ()=>{
            _this.moveVelocityY *= -1;
            
        });
        _this.collider.isCollide(_this.boundRight, _this.ball, ()=>{
            _this.moveVelocityX *= -1;
           
        });
    }

    //update stage 

    updateStage();

    function updateStage() {
_this.collider.isCollide(_this.paddle1,_this.ball,function(){})

    }
   


   
  
    }


}
}