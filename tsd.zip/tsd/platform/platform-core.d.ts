/* tslint:disable */
/// <reference path="../base/base-core.d.ts" />
declare namespace ingenuity {
    interface IInitGameResponse extends IObject {
        user?: IObject;
    }
    interface IBetResponse extends IObject {
        bet?: IObject;
    }
}
declare namespace ingenuity.platform {
    const EventConstants: {
        ENVIRONMENT_READY: string;
        HIDE_LOADER: string;
        ASSETS_LOADED: string;
        INIT_GAME: string;
        INIT_GAME_RESPONSE_RECEIVED: string;
        GAME_CLOSE_RESPONSE_RECEIVED: string;
        OPEN_GAME_COMPLETE: string;
        LOADING_STARTED: string;
        LOADING_PROGRESS: string;
        LOADING_COMPLETE: string;
        GAME_INITIALISED: string;
        GAME_STATUS_CHANGED: string;
        SOUND_STATUS_CHANGED: string;
        SHOW_GAME: string;
        PLACE_BET: string;
        PLACE_BET_RESPONSE: string;
        GAMEPLAY_STARTED: string;
        GAMEPLAY_STARTED_RESPONSE: string;
        GAMEPLAY_ENDED: string;
        GAMEPLAY_ENDED_RESPONSE: string;
        BALANCE_UPDATED: string;
        JACKPOT_UPDATED: string;
        FULLSCREEN_MODE_ON: string;
        FULLSCREEN_MODE_OFF: string;
        TOTALWIN_UPDATED: string;
        TOTALBET_UPDATED: string;
        PAYTABLE_STATUS_CHANGED: string;
        AUTOPLAY_LIMIT_REACHED: string;
        GAME_VERSION_UPDATE: string;
        GAME_READY_FOR_UNLOAD: string;
        MENU_OPEN: string;
        MENU_CLOSED: string;
        POPUP_SHOW: string;
        TOPBAR_CHANGED: string;
        POPUP_CLOSE: string;
        ENVIROMENT_ERROR: string;
        OPERATOR_CHANGES_BET: string;
        SCREEN_INTRECTION_BLOCK: string;
        GAME_SUSPENDED: string;
        REQUEST_STATUS: string;
        LOADING_TYPE: string;
        GAME_STATE_CHANGED: string;
        SOUND_STATE_CHANGED: string;
        AUTOPLAY_ACTIVATED_GAME: string;
        AUTOPLAY_ACTIVATED_CONFIRMATION: string;
        RESIZE: string;
        BONUS_BET_RESPONSE: string;
        FREE_BET_RESPONSE: string;
        PARSE_JACKPOT_RESPONSE: string;
        BET_PARSED: string;
        BROKEN_BASE_GAME: string;
        BROKEN_FREE_GAME: string;
        FREE_GAME_ENDED: string;
        OPEN_GAME_PROCESSED: string;
        ERROR_RECEIVED_FROM_SERVER: string;
        SPIN_RESPONSE_PROCESSED: string;
        PARSE_EXTENDEDSPINSTYLES: string;
        SHOW_ERROR: string;
        PARSE_BONUS_RESPOSE: string;
        BONUS_PICK: string;
        FREE_BET: string;
        ERROR_IN_LOADING: string;
        GAME_CLOSE: string;
        FREE_GAME_STARTED: string;
    };
}
declare namespace ingenuity.platform.base {
    abstract class AbstractModel {
        private balance;
        private userBalance;
        private currentBetIndex;
        private defaultNumChips;
        private defaultChipSize;
        private currentWin;
        private totalWin;
        private currentBet;
        private minBet;
        private maxBet;
        private currentTotalBet;
        private currentGameState;
        private numChips;
        private chipSize;
        protected stakeArray: number[];
        private defaultBet;
        private numChipOptions;
        private currencyCode;
        private arrayNumChipUsed;
        private arrayNumChips;
        private isCredit;
        private playForFun;
        constructor();
        getBalance(): number;
        setBalance(value: number): void;
        getIsCredit(): boolean;
        setIsCredit(value: boolean): void;
        getUserBalance(): number;
        setUserBalance(value: number): void;
        getCurrentBetIndex(): number;
        setCurrentBetIndex(value: number): void;
        getDefaultNumChips(): number;
        setDefaultNumChips(value: number): void;
        getDefaultChipSize(): number;
        setDefaultChipSize(value: number): void;
        getCurrentWin(): number;
        setCurrentWin(value: number): void;
        getTotalWin(): number;
        setTotalWin(value: number): void;
        getCurrentBet(): number;
        setCurrentBet(value: number): void;
        getCurrentTotalBet(): number;
        setCurrentTotalBet(value: number): void;
        getCurrentGameState(): number;
        setCurrentGameState(value: number): void;
        getNumChips(): number;
        setNumChips(value: number): void;
        getChipSize(): number;
        setChipSize(value: number): void;
        getDefaultBet(): number;
        setDefaultBet(value: number): void;
        getNumChipOptions(): number[];
        setNumChipOptions(value: number[]): void;
        getCurrencyCode(): string;
        setCurrencyCode(value: string): void;
        getArrayNumChipUsed(): number[];
        setArrayNumChipUsed(value: number[]): void;
        getArrayNumChips(): number[];
        setArrayNumChips(value: number[]): void;
        resetForBet(): void;
        setPlayForFun(value: boolean): void;
        getPlayForFun(): boolean;
        setMaxBet(bet: number): void;
        getMaxBet(): number;
        setMinBet(bet: number): void;
        getMinBet(): number;
        getAllowBetOptions(): number[];
        setAllowBetOptions(stakeArray: number[]): void;
    }
}
declare namespace ingenuity.platform.base {
    abstract class AbstractParser {
        protected model: AbstractModel;
        constructor(model: AbstractModel);
        protected bindEvent(): void;
        protected abstract onInitResponseReceived(e?: IEvent): void;
        protected abstract parseInitResponse(response: IInitGameResponse): void;
        protected abstract parseBrokenResponse(response: IInitGameResponse): void;
        protected abstract onBetResponseReceived(e?: IEvent): void;
        protected abstract parseBetResponse(response: IBetResponse): void;
        protected onGameStartResponseReceived(e?: IEvent): void;
        protected onGameEndResponseReceived(e?: IEvent): void;
        protected onGameCloseResponseReceived(e?: IEvent): void;
        protected parseCloseResponse(response: IBetResponse): void;
    }
}
declare namespace ingenuity.platform.base {
    abstract class AbstractServerComm {
        protected model: AbstractModel;
        constructor(model: AbstractModel);
        protected bindEvent(): void;
        protected abstract sendInitRequest(evt?: IEvent): void;
        protected abstract sendBetRequest(evt?: IEvent): void;
        protected sendCloseGameRequest(evt?: IEvent): void;
    }
}
declare namespace ingenuity.platform.base {
    abstract class AbstractWrapper {
        constructor();
        protected bindEvent(): void;
        protected insufficientFund(evt?: IEvent): void;
        protected abstract environmentReady(evt?: IEvent): void;
        protected loadingStarted(evt?: IEvent): void;
        protected loadingInProgress(evt?: IEvent): void;
        protected loadingComplete(evt?: IEvent): void;
        protected soundStatusChanged(evt?: IEvent): void;
        protected enviormentError(evt?: IEvent): void;
        protected loadingError(evt?: IEvent): void;
        protected sendUpdateSignal(evt?: IEvent): void;
        protected gameCycleStarted(evt?: IEvent): void;
        protected gameCycleComplete(evt?: IEvent): void;
        protected balanceUpdated(evt?: IEvent): void;
        protected gameSuspended(evt?: IEvent): void;
        protected enviormentResize(evt?: IEvent): void;
    }
}
declare namespace ingenuity.core.constructors.platforms {
    let base: {
        Model: typeof platform.base.AbstractModel;
        Parser: typeof platform.base.AbstractParser;
        ServerComm: typeof platform.base.AbstractServerComm;
        Wrapper: typeof platform.base.AbstractWrapper;
    };
}
declare namespace ingenuity {
    interface IWinLineObject extends IObject {
        positions: number[][];
        no: number;
        winSymLen: number;
        win: number;
        id: number;
    }
}
declare namespace ingenuity.platform.baseslot {
    const EventConstants: {
        FREE_BET: string;
        PLACE_FREE_GAME_BET_RESPONSE: string;
    };
}
declare namespace ingenuity.platform.baseslot {
    class Model extends base.AbstractModel {
        private currentTriggeringWin;
        private currentNumPaylines;
        private maxPaylines;
        private paylineCost;
        private triggerNumPaylines;
        private numRows;
        private numCols;
        private reelGrid;
        private triggerScatterWinData;
        private hasWin;
        private waysWinUniquePositions;
        private winLinesData;
        private scatterWinData;
        private waysWinData;
        private triggerReelGrid;
        private reelStops;
        private restoreFreeGame;
        private restoreBaseGame;
        private hasScatterWins;
        private hasRespin;
        private hasFreeGamesWin;
        private hasReFreeSpinWin;
        private freshFreeSpins;
        private hasTriggeringWin;
        private waysGame;
        private hasWaysWins;
        private hasLineWins;
        private triggerReelStops;
        private triggerWaysWinData;
        private triggerWinLinesData;
        private defaultActivePaylines;
        private freeSpinWin;
        private freeSpinNum;
        private oldFreeSpinNum;
        private freeSpinsRemaining;
        private freeSpinGuaranteedWin;
        private freeSpinMultiplierStatus;
        private freeSpinMultiplyGuaranteedWin;
        private freeSpinMultiplier;
        private freeReelSet;
        private fiveOfAKind;
        private reelSetIndex;
        private multiplier;
        private recover;
        private triggerMultiplier;
        private triggerReelSetIndex;
        private isGameIdle;
        private selectedLines;
        private retriggerFreeSpins;
        private isFreeSpinRetrigger;
        private waysWinAllUniquePositions;
        constructor();
        setSelectedLines(value: number | number[]): void;
        getSelectedLines(): number | number[];
        setIsGameIdle(value: boolean): void;
        getIsGameIdle(): boolean;
        setTriggerReelSetIndex(value: number): void;
        getTriggerReelSetIndex(): number;
        setTriggerMultiplier(value: number): void;
        getTriggerMultiplier(): number;
        setReelSetIndex(value: number): void;
        getReelSetIndex(): number;
        setMultiplier(value: number): void;
        getMultiplier(): number;
        getRecover(): boolean;
        setRecover(value: boolean): void;
        getCurrentTriggeringWin(): number;
        setCurrentTriggeringWin(value: number): void;
        getCurrentNumPaylines(): number;
        setCurrentNumPaylines(value: number): void;
        getMaxPaylines(): number;
        setMaxPaylines(value: number): void;
        getPaylineCost(): number;
        setPaylineCost(value: number): void;
        getTriggerNumPaylines(): number;
        setTriggerNumPaylines(value: number): void;
        getNumRows(): number;
        setNumRows(value: number): void;
        getNumCols(): number;
        setNumCols(value: number): void;
        getReelGrid(): number[][];
        setReelGrid(value: number[][]): void;
        getTriggerScatterWinData(): IWinLineObject[];
        setTriggerScatterWinData(value: IWinLineObject[]): void;
        getHasWin(): boolean;
        setHasWin(value: boolean): void;
        getWaysWinUniquePositions(): IObject[];
        setWaysWinUniquePositions(value: IObject[]): void;
        getWaysWinAllUniquePositions(): number[][];
        setWaysWinAllUniquePositions(value: number[][]): void;
        getWinLinesData(): IWinLineObject[];
        setWinLinesData(value: IWinLineObject[]): void;
        getScatterWinData(): IWinLineObject[];
        setScatterWinData(value: IWinLineObject[]): void;
        getWaysWinData(): IWinLineObject[];
        setWaysWinData(value: IWinLineObject[]): void;
        getTriggerReelGrid(): number[][];
        setTriggerReelGrid(value: number[][]): void;
        getReelStops(): number[];
        setReelStops(value: number[]): void;
        getRestoreFreeGame(): boolean;
        setRestoreFreeGame(value: boolean): void;
        getRestoreBaseGame(): boolean;
        setRestoreBaseGame(value: boolean): void;
        getHasScatterWins(): boolean;
        setHasScatterWins(value: boolean): void;
        getHasRespin(): boolean;
        setHasRespin(value: boolean): void;
        getHasFreeGamesWin(): boolean;
        setHasFreeGamesWin(value: boolean): void;
        getHasReFreeSpinWin(): boolean;
        setHasReFreeSpinWin(value: boolean): void;
        getFreshFreeSpins(): boolean;
        setFreshFreeSpins(value: boolean): void;
        getHasTriggeringWin(): boolean;
        setHasTriggeringWin(value: boolean): void;
        getWaysGame(): boolean;
        setWaysGame(value: boolean): void;
        getHasWaysWins(): boolean;
        setHasWaysWins(value: boolean): void;
        getHasLineWins(): boolean;
        setHasLineWins(value: boolean): void;
        getTriggerReelStops(): number[];
        setTriggerReelStops(value: number[]): void;
        getTriggerWaysWinData(): IWinLineObject[];
        setTriggerWaysWinData(value: IWinLineObject[]): void;
        getTriggerWinLinesData(): IWinLineObject[];
        setTriggerWinLinesData(value: IWinLineObject[]): void;
        getDefaultActivePaylinesCout(): number;
        getDefaultActivePaylines(): number[];
        setDefaultActivePaylines(value: number[]): void;
        getFreeSpinWin(): number;
        setFreeSpinWin(value: number): void;
        getFreeSpinNum(): number;
        setFreeSpinNum(value: number): void;
        getOldFreeSpinNum(): number;
        setOldFreeSpinNum(value: number): void;
        getFreeSpinsRemaining(): number;
        setFreeSpinsRemaining(value: number): void;
        getFreeSpinGuaranteedWin(): number;
        setFreeSpinGuaranteedWin(value: number): void;
        getFreeSpinMultiplierStatus(): number;
        setFreeSpinMultiplierStatus(value: number): void;
        getFreeSpinMultiplyGuaranteedWin(): number;
        setFreeSpinMultiplyGuaranteedWin(value: number): void;
        getFreeSpinMultiplier(): number;
        setFreeSpinMultiplier(value: number): void;
        getFreeReelSet(): number;
        setFreeReelSet(value: number): void;
        clearFreeSpinData(): void;
        set5OfKind(value: boolean): void;
        get5OfKind(): boolean;
        setRetriggerFreeSpins(value: number): void;
        getRetriggerFreeSpins(): number;
        setIsFreeSpinRetriggered(value: boolean): void;
        getIsFreeSpinRetriggered(): boolean;
        resetForBet(): void;
    }
}
declare namespace ingenuity.platform.baseslot {
    abstract class Parser extends base.AbstractParser {
        protected bindEvent(): void;
        protected abstract onFreeBetResponseReceived(e?: IEvent): void;
        protected abstract parseFreeBetResponse(response: IBetResponse): void;
    }
}
declare namespace ingenuity.platform.baseslot {
    abstract class ServerComm extends base.AbstractServerComm {
        protected bindEvent(): void;
        protected abstract sendFreeBetRequest(e?: IEvent): void;
    }
}
declare namespace ingenuity.platform.baseslot {
    abstract class Wrapper extends base.AbstractWrapper {
        constructor();
    }
}
declare namespace ingenuity.core.constructors.platforms {
    let baseSlot: {
        Model: typeof platform.baseslot.Model;
        Parser: typeof platform.baseslot.Parser;
        ServerComm: typeof platform.baseslot.ServerComm;
        Wrapper: typeof platform.baseslot.Wrapper;
    };
}
declare namespace ingenuity.platform.generic {
    const EventConstants: {};
}
declare namespace ingenuity.platform.generic {
    class Model extends baseslot.Model {
        private stake;
        private currentReelSetIndex;
        private wildMultiplier;
        private nextAction;
        private currentAction;
        private status;
        private serverVersion;
        setGameStatus(data: string): void;
        getGameStatus(): string;
        setServerVersion(data: string): void;
        getServerVersion(): string;
        setNextAction(data: string): void;
        getNextAction(): string;
        setAction(data: string): void;
        getAction(): string;
        setStake(value: number[]): void;
        getStake(): number[];
        getCurrentBet(): number;
        getNextBet(): number;
        getPreviousBet(): number;
        setCurrentReelSetIndex(value: number): void;
        getCurrentReelSetIndex(): number;
        setWildMultiplier(value: number): void;
        getWildMultiplier(): number;
        constructor();
    }
}
declare namespace ingenuity.platform.generic {
    interface IResponseInit {
        game: IResponseStatus;
        config?: IResponseConfig;
        init?: IResponseSlot;
        currentResponse?: IResponseSlot;
        spinRequest?: IResponseBet;
        freespin?: IFreeSpinData;
        spinResponse?: IResponseSlot;
    }
    interface IResponseStatus {
        action: string;
        nextAction: string;
        status: string;
        balance: number;
        totalWin: number;
        recover: boolean;
        version: string;
    }
    interface IResponseSlot {
        reelSetIndex: number;
        stops?: number[];
        grid?: string[][];
        winnings: IResponseWin[];
        randomSymbol?: any;
        win?: number;
        triggeringWinnings?: number;
        multiplier: number;
        wildMultiplier: number;
    }
    interface IResponseConfig {
        minBet: number;
        maxBet: number;
        defaultStake: string | number;
        stakeValues: number[];
    }
    interface IResponseWin {
        count: number;
        offsets: number[];
        offsetsList: number[][];
        symbol: string;
        payline: number;
        payout: number;
    }
    interface IResponseBet {
        selectedLines: number;
        betPerLine: number;
        totalBet: number;
    }
    interface IFreeSpinData {
        spinsAwarded: number;
        spinsRemaining: number;
        spinsRetriggered: number;
        totalWin: number;
        offsets: number[];
    }
}
declare namespace ingenuity.platform.generic {
    class Parser extends baseslot.Parser {
        protected model: Model;
        constructor(model: Model);
        protected onInitResponseReceived(evt?: IEvent): void;
        protected parseInitResponse(response: IResponseInit): void;
        protected processGame(data: IResponseStatus): void;
        protected processConfig(data: IResponseConfig): void;
        protected processSlot(data: IResponseSlot): void;
        protected processTriggeringSpin(data: IResponseSlot): void;
        protected processView(data: string[][]): void;
        protected processTriggeringView(data: string[][]): void;
        protected processWinOffset(data: number[]): number[][];
        protected processWins(data: IResponseWin[]): void;
        protected processWaysWins(data: IResponseWin[]): void;
        protected processTriggeringWins(data: IResponseWin[]): void;
        protected parseBrokenResponse(response: IResponseInit): void;
        protected onBetResponseReceived(evt?: IEvent): void;
        protected processFreeSpinsData(freeSpindata: IFreeSpinData): void;
        protected parseBetResponse(response: IResponseInit): void;
        protected processBet(data: IResponseBet): void;
        protected onFreeBetResponseReceived(evt?: IEvent): void;
        protected parseFreeBetResponse(response: IResponseInit): void;
        protected parseBrokenFreeGameResponse(response: IResponseInit): void;
    }
}
declare namespace ingenuity.utils {
}
declare namespace ingenuity.platform.generic {
    class ServerComm extends baseslot.ServerComm {
        protected model: Model;
        protected cheatField: HTMLInputElement;
        protected readonly reqOptions: RequestInit;
        constructor(model: Model);
        protected createCheatField(): void;
        protected sendInitRequest(evt?: IEvent): void;
        protected sendBetRequest(evt?: IEvent): void;
        protected sendFreeBetRequest(evt?: IEvent): void;
        protected sendCloseGameRequest(evt?: IEvent): void;
    }
}
declare namespace ingenuity.core.constructors.platforms {
    let generic: {
        Model: typeof platform.generic.Model;
        Parser: typeof platform.generic.Parser;
        ServerComm: typeof platform.generic.ServerComm;
    };
}
declare namespace ingenuity.platform.generic {
}
declare namespace ingenuity.platform.generic {
    interface IRequestInit {
        action: string;
    }
    interface IRequestSpin {
        action: string;
        stakePerLine: number;
        selectedLines?: number;
        cheat?: string | number[];
    }
}
declare namespace ingenuity.platform.genericblackjack {
    const EventConstants: {};
}
declare namespace ingenuity.platform.genericblackjack {
    const GameConstants: {
        DEFAULT_CURRENCY: string;
        MIN_STAKE: number;
        MAX_STAKE: number;
        CURRENT_BET: number;
        CURRENT_SELECTED_BET: number;
        MAX_WINNING: number;
        MAX_ANIM_TIME: number;
        HAND_STATUS: string[];
        DEALER_HIDE_CARD: string[];
    };
}
declare namespace ingenuity {
    interface IMultiPlayerStateData {
        id: string;
        seatId: string;
        currentHand: string;
        totalHands: string;
        playerStateInsurance: string;
        originalStake: string;
        stake: string | number;
        winnings: string;
        handInfo: Array<IPlayerStateHand>;
    }
    interface IPlayerStateHand {
        handId: string;
        handTotalType: string;
        handTotal: string;
        handStatus: string;
        handDoubled: string;
        handDoubleCard: string;
        handStake: string | number;
        handWinnings: string;
        handBurntCards: string;
        handPlayerCards: string;
        handSplitted?: boolean;
        handIndex?: number;
    }
    interface IBet {
        name?: string;
        betValue?: number;
        seln?: number;
        totalBet?: number;
    }
    interface IAccountInfo {
        currencyCode: string;
        balance: number;
    }
}
declare namespace ingenuity.platform.basetable {
    const EventConstants: {
        HIT_REQUEST: string;
        HIT_RESPONSE: string;
        HIT_RESPONSE_PROCESSED: string;
        SPLIT_REQUEST: string;
        SPLIT_RESPONSE: string;
        SPLIT_RESPONSE_PROCESSED: string;
        STAND_REQUEST: string;
        STAND_RESPONSE: string;
        STAND_RESPONSE_PROCESSED: string;
        DOUBLE_REQUEST: string;
        DOUBLE_RESPONSE: string;
        DOUBLE_RESPONSE_PROCESSED: string;
        INSURANCE_REQUEST: string;
        INSURANCE_RESPONSE: string;
        INSURANCE_RESPONSE_PROCESSED: string;
        CONFIG_DATA: string;
        CONFIG_DATA_RESPONSE: string;
        CONFIG_DATA_RESPONSE_PROCESSED: string;
        CLOSE_GAME: string;
        CLOSE_GAME_RESPONSE: string;
        CLOSE_GAME_RESPONSE_PROCESSED: string;
        RESET_UI: string;
        CARD_ANIMATION_COMPLETED: string;
        NEW_GAME_BTN_PRESSED: string;
        UPDATE_BETTING_AREA: string;
        INSURE_BTN_PRESSED: string;
        DONOT_INSURE_BTN_PRESSED: string;
        UNDO_BTN_PRESSED: string;
    };
}
declare namespace ingenuity.platform.basetable {
    class Model extends base.AbstractModel {
        private gameId;
        private version;
        private channel;
        private currencyDecimalSep;
        private currencyThousandSep;
        private balanceChange;
        private heldFunds;
        private allowedBetSet;
        private currentSelectedBet;
        private gameError;
        private maxStake;
        private minStake;
        private maxAnimTime;
        private maxWinning;
        private totalStake;
        private currentPlayerSeat;
        private hasWin;
        private isGameIdle;
        private dealerCardsArray;
        private dealerCardsArrayForRequestString;
        private playerCardsArray;
        private playerNewCardsArray;
        private currentPlayerStake;
        private playerStakeHandArray;
        private playerStateArray;
        private delaerState;
        private playeCardsString;
        private cookieString;
        private playerInsurance;
        private wrapperTurboMode;
        private playerFinalStatus;
        private dealerFinalStatus;
        private dealerStatusString;
        private currentActionType;
        private btnNameForRequest;
        private options;
        private newGame;
        private currentPlayerId;
        private adjFreeBalance;
        private currentPlayer;
        private seatId;
        private accountInfo;
        private insuranceOffered;
        private totalPlayers;
        constructor();
        setInsuranceOffered(value: string): void;
        getInsuranceOffered(): string;
        setTotalPlayers(value: number): void;
        getTotalPlayers(): number;
        getHeldFunds(): number;
        setHeldFunds(value: number): void;
        getChannel(): string;
        setChannel(value: string): void;
        getGameId(): string;
        setGameId(value: string): void;
        getVersion(): string;
        setVersion(value: string): void;
        setAccountInfoArray(value: IAccountInfo): void;
        getAccountInfoArray(): IAccountInfo;
        getAdjFreeBalance(): number;
        setAdjFreeBalance(value: number): void;
        getCurrentPlayerId(): string;
        setCurrentPlayerId(value: string): void;
        setCurrentPlayer(value: string): void;
        getCurrentPlayer(): string;
        setSeatId(value: string): void;
        getSeatId(): string;
        setNewGame(value: string): void;
        getNewGame(): string;
        setOptions(value: string): void;
        getOptions(): string;
        getCurrencyDecimalSep(): string;
        setCurrencyDecimalSep(value: string): void;
        getCurrencyThousandSep(): string;
        setCurrencyThousandSep(value: string): void;
        setAllowedBetConfiguration(allowedBets: number[]): void;
        getAllowedBetConfiguration(): number[];
        setBalanceChange(value: number): void;
        getBalanceChange(): number;
        setCurrentSelectedBet(value: number): void;
        getCurrentSelectedBet(): number;
        getCurrentBet(): number;
        setDefaultBet(value: number): void;
        isEnableInc(): boolean;
        isEnableDec(): boolean;
        getNextAvailableBet(): boolean;
        getPrevAvailableBet(): boolean;
        setCurrentPlayerStake(value: number): void;
        getCurrentPlayerStake(): number;
        getPlayerFinalStatus(): string;
        setPlayerFinalStatus(value: string): void;
        getCurrentActionType(): string;
        setCurrentActionType(value: string): void;
        getDealerFinalStatus(): string;
        setDealerFinalStatus(value: string): void;
        getStakePlayerHandTally(): IBet[];
        setStakePlayerHandTally(value: IBet[]): void;
        setMaxAllowedBet(): void;
        setMaxStake(value: number): void;
        getMaxStake(): number;
        setMinStake(value: number): void;
        getMinStake(): number;
        setMaxAnimTime(value: number): void;
        getMaxAnimTime(): number;
        setMaxWinning(value: number): void;
        getMaxWinning(): number;
        setCurrentPlayerSeat(value: string[]): void;
        getCurrentPlayerSeat(): string[];
        setHasWin(value: boolean): void;
        getHasWin(): boolean;
        setGameIdle(value: boolean): void;
        getGameIdle(): boolean;
        setTotalStake(value: number): void;
        getTotalStake(): number;
        getCurrentStake(): number;
        setPlayerInformationArray(value: Array<IMultiPlayerStateData>): void;
        getPlayerInformationArray(): Array<IMultiPlayerStateData>;
        setDealerInformationArray(value: Object[]): void;
        getDealerInformationArray(): Object[];
        dealerStatus: string;
        setInuranceInformationArray(value: string): void;
        getIsuranceInformationArray(): string[];
        setTurbomode(value: boolean): void;
        getTurbomode(): boolean;
        getCardInfoBySeatAndHandID(seat: string, hand: number): string;
        getInsuranceInfoBySeatID(player: number): string;
        getPlayerInfoBySeatID(seat: string, handIndex?: string): IMultiPlayerStateData | null;
        getHandTotalTypeBySeatAndHandID(seat: string, hand: number): string;
        getCardTotalBySeatAndHandID(seat: string, hand: number): string;
        setAllowedBetsDefaultBetAndCurrentBetIndex(value: string, betValue: number): void;
        PlayerCards: string[];
        setDealerCards(value: string[]): void;
        getDealerCards(): string[];
        getCookies(): string;
        setCookies(value: string): void;
        setCurrentBalance(value: number): void;
        getCurrentBalance(): number;
        resetForBet(): void;
    }
}
declare namespace ingenuity.platform.basetable {
    abstract class Parser extends base.AbstractParser {
        protected bindEvent(): void;
        protected onHitResponseReceived(e?: IEvent): void;
        protected onSplitResponseReceived(e?: IEvent): void;
        protected onDoubleResponseReceived(e?: IEvent): void;
        protected onStandResponseReceived(e?: IEvent): void;
        protected onInsuranceResponseReceived(e?: IEvent): void;
        protected onCloseResponseReceived(e?: IEvent): void;
    }
}
declare namespace ingenuity.platform.basetable {
    abstract class ServerComm extends base.AbstractServerComm {
        protected bindEvent(): void;
        protected DoubleRequest(evt: IEvent): void;
        protected InsuranceRequest(evt: IEvent): void;
        protected SplitRequest(evt: IEvent): void;
        protected CloseGame(evt: IEvent): void;
        protected StandRequest(evt: IEvent): void;
        protected HitRequest(evt: IEvent): void;
    }
}
declare namespace ingenuity.platform.basetable {
    abstract class Wrapper extends base.AbstractWrapper {
        constructor();
    }
}
declare namespace ingenuity.core.constructors.platforms {
    let basetable: {
        Model: typeof platform.basetable.Model;
        Parser: typeof platform.basetable.Parser;
        ServerComm: typeof platform.basetable.ServerComm;
        Wrapper: typeof platform.basetable.Wrapper;
    };
}
declare namespace ingenuity.platform.genericblackjack {
}
declare namespace ingenuity.platform.genericblackjack {
    class Model extends ingenuity.platform.basetable.Model {
        private dealerTotalType;
        private dealerTotal;
        constructor();
        setDealerTotal(value: number): void;
        getDealerTotal(): number;
        setDealerTotalType(value: string): void;
        getDealerTotalType(): string;
    }
}
declare namespace ingenuity.platform.genericblackjack {
    interface IResponseInit {
        config?: IResponseConfig;
        game?: IResponseGame;
        player?: IResponsePlayer[];
        request?: IResponseRequest;
        drawnNumber?: number;
        response?: IResponse;
        Error?: any;
    }
    interface IResponse {
        blackjackState?: IBlackjackState;
        dealer?: IDealer;
        players?: IPlayer[];
    }
    interface IDealer {
        cards?: string[];
        points?: number;
        total_type?: string;
    }
    interface IDealerStateData {
        dealerTotalType: string;
        dealertotal: number;
        dealerCards: string[];
        dealerStatus: string;
    }
    interface IPlayer {
        actions?: string[];
        bet?: number;
        burnt_cards?: string;
        cards?: string;
        current_hand?: string;
        double_card?: string;
        doubled?: string;
        id?: string;
        insurance?: string;
        originalBet?: string;
        player_status?: string;
        points?: string;
        seat?: string;
        status?: string;
        total?: string;
        total_hands?: string;
        total_type?: string;
        win?: string;
    }
    interface IBlackjackState {
        current_player?: string;
        insurance_offered?: string;
        options?: string;
        total_players?: number;
    }
    interface IResponseRequest {
        totalBet?: number;
    }
    interface IResponsePlayer {
        id?: string;
        bet?: number;
        win?: number;
    }
    interface IResponseGame {
        ccy_code?: string;
        action?: string;
        balance?: number;
        max_winnings?: number;
        max_anim_time?: number;
        nextAction?: string;
        status?: string;
        totalWin?: number;
        stake?: number;
        new?: string;
        version?: string;
    }
    interface IResponseConfig {
        bets?: IResponseConfigBets;
        chipsize?: number[];
        currency?: string;
        defaultStake?: number;
        maxStake?: number;
        maxTableLimit?: number;
        minStake?: number;
        minTableLimit?: number;
    }
    interface IResponseConfigBets {
        id?: string;
        minStake?: number;
        multiplier?: number;
        mxnStake?: number;
        type?: string;
    }
    interface IResponseHeader {
        GameId: any;
        Customer: any;
    }
    interface IAccountInfo {
        currencyCode: string;
        balance: number;
    }
    interface IResponseInitInfo {
        BetDef: any;
        BetPayout: any;
        FreebetSummary: any;
        BonusPromotion: any;
        GameConfig: any;
        BlackjackState: any;
        Play: any;
    }
    interface IMultiPlayerStateData {
        id: string;
        seatId: string;
        currentHand: string;
        totalHands: string;
        playerStateInsurance: string;
        originalStake: string;
        stake: string | number;
        winnings: string;
        handInfo: Array<IPlayerStateHand>;
    }
    interface IPlayerStateHand {
        handId: string;
        handTotalType: string;
        handTotal: string;
        handStatus: string;
        handDoubled: string;
        handDoubleCard: string;
        handStake: string | number;
        handWinnings: string;
        handBurntCards: string;
        handPlayerCards: string;
        handSplitted?: boolean;
        handIndex?: number;
    }
    interface IResponseStatus {
        action: string;
        nextAction: string;
        status: string;
        balance: number;
        totalWin: number;
        recover: boolean;
        version: string;
    }
    interface IPlayersResponse {
        actions: string[];
        bet: number;
        burnt_cards: string;
        cards: string[];
        current_hand: number;
        double_card: number;
        doubled: string;
        id: number;
        insurance: string;
        originalBet: number;
        player_status: string;
        points: number;
        seat: number;
        status: string;
        total: number;
        total_hands: number;
        total_type: string;
    }
    interface IError {
        Error: any;
    }
}
declare namespace ingenuity.platform.genericblackjack {
    class Parser extends basetable.Parser {
        protected model: Model;
        private requestType;
        constructor(model: Model);
        protected findAndDisplayErrorMsg(resObj: IResponseInit): void;
        protected onInitResponseReceived(evt?: IEvent): void;
        private parseHeaderObjects(data);
        protected parseInitResponse(data: IResponseInit): void;
        protected parseBrokenResponse(data?: IResponseInit): void;
        private getPlayerIndexFromArray(currentId, players);
        private titleCase(str);
        private getDealerStatus(dealerTotal, cards);
        protected onBetResponseReceived(evt?: IEvent): void;
        protected parseBetResponse(data: IResponseInit): void;
        private ParsePlayObjects(data);
        protected onHitResponseReceived(evt: IEvent): void;
        private setPlayerStatus();
        protected onSplitResponseReceived(evt: IEvent): void;
        protected onDoubleResponseReceived(evt: IEvent): void;
        protected onStandResponseReceived(evt: IEvent): void;
        protected onInsuranceResponseReceived(evt: IEvent): void;
        protected onCloseResponseReceived(evt: IEvent): void;
    }
}
declare namespace ingenuity.platform.genericblackjack {
    class ServerComm extends basetable.ServerComm {
        protected model: Model;
        protected cheatField: HTMLInputElement;
        private action;
        private totalPlayer;
        constructor(model: Model);
        protected createCheatField(): void;
        protected sendRequest(requestData: IRequestInit | IRequestBet): void;
        protected sendInitRequest(evt: IEvent): void;
        protected getInitGameRequest(): IRequestInit;
        protected sendBetRequest(evt: IEvent): void;
        protected getDealRequestString(): IRequestBet;
        protected HitRequest(evt: IEvent): void;
        protected getRequestAfterDeal(actionValue: string): IRequestBet;
        protected StandRequest(evt: IEvent): void;
        protected CloseGame(evt: IEvent): void;
        protected getCloseGameRequest(): IRequestInit;
        protected SplitRequest(evt: IEvent): void;
        protected DoubleRequest(evt: IEvent): void;
        protected InsuranceRequest(evt: IEvent): void;
        protected getRequestAfterInsurance(): IRequestBet;
        protected parseServerResponse(data: IResponse): void;
        protected handleServerError(data: any): void;
    }
}
declare namespace ingenuity.core.constructors.platforms {
    let genericblackjack: {
        Model: typeof platform.genericblackjack.Model;
        Parser: typeof platform.genericblackjack.Parser;
        ServerComm: typeof platform.genericblackjack.ServerComm;
    };
}
declare namespace ingenuity.platform.genericblackjack {
    interface IRequestInit {
        action: string;
    }
    interface IRequestBet {
        action: string;
        bets: IPlayerBet[];
        cheat?: string | number[];
    }
    interface IPlayerBet {
        id?: number;
        bet?: number;
        seat?: number;
    }
    interface IPlayerInsurance {
        id?: number;
        insured?: string;
        seat?: number;
    }
}
declare namespace ingenuity.platform.genericroulette {
    const EventConstants: {
        ROULETTE_ANIMATION_FINISH: string;
        ROULETTE_PRESENTATION_COMPLETE: string;
    };
}
declare namespace ingenuity.platform.genericroulette {
}
declare namespace ingenuity.platform.genericroulette {
    class Model extends basetable.Model {
        private betSelnArray;
        private betArrayForRequestString;
        private betStateArray;
        private drawn;
        private totalBetsPoint;
        constructor();
        setTotalBetsPoint(value: number): void;
        getTotalBetsPoint(): number;
        setDrawn(value: number): void;
        getDrawn(): number;
        setBetSelnArray(valueArray: IBetPayOut[]): void;
        getBetSelnArray(): IBetPayOut[];
        setBetArrayForRequestString(arr: IBet[]): void;
        getBetArrayForRequestString(): IBet[];
        getIsPreviousGameOpen(): boolean;
        setBetStateArray(valueArray: IMultiPlayerStateData[]): void;
        getBetStateArray(): IMultiPlayerStateData[];
    }
}
declare namespace ingenuity.platform.genericroulette {
    interface IResponse {
        config?: IResponseConfig;
        game?: IResponseGame;
        player?: IResponsePlayer[];
        request?: IResponseRequest;
        drawnNumber?: number;
        Error?: any;
    }
    interface IResponseRequest {
        totalBet?: number;
    }
    interface IResponsePlayer {
        id?: string;
        bet?: number;
        win?: number;
    }
    interface IResponseGame {
        action?: string;
        balance?: number;
        nextAction?: string;
        status?: string;
        totalWin?: number;
        stake?: number;
        new?: string;
        version?: string;
    }
    interface IResponseConfig {
        bets?: IResponseConfigBets[];
        chipsize?: number[];
        currency?: string;
        defaultStake?: number;
        maxNumber?: number;
        maxTableLimit?: number;
        minNumber?: number;
        minTableLimit?: number;
    }
    interface IResponseConfigBets {
        id?: string;
        minStake?: number;
        multiplier?: number;
        mxnStake?: number;
        type?: string;
    }
    interface IAccountInfo {
        currencyCode: string;
        balance: number;
    }
    interface IMultiPlayerStateData {
        seln?: string;
        stake?: number;
        winnings?: number;
        name?: string;
    }
    interface IBetPayOut {
        id?: string;
        type?: string;
        payout?: number;
        min_stake?: number;
        max_stake?: number;
    }
    interface IBet {
        name: string;
        betValue: number;
        seln: number;
    }
    interface IPlayObject {
        stake: number;
        totalWin: number;
        id: string;
    }
    interface IPlayerBet {
        id: number;
        bet: number;
    }
    interface IError {
        Error: any;
    }
}
declare namespace ingenuity.platform.genericroulette {
    class Parser extends basetable.Parser {
        protected model: Model;
        private requestType;
        constructor(model: Model);
        findAndDisplayErrorMsg(resObj: IResponse): void;
        protected onInitResponseReceived(evt?: IEvent): void;
        private ParseHeaderObjects(data);
        protected parseInitResponse(data: IResponse): void;
        protected parseBrokenResponse(data?: IResponse): void;
        protected onBetResponseReceived(evt?: IEvent): void;
        protected parseBetResponse(data: IResponse): void;
        private ParsePlayObjects(data);
        protected onCloseResponseReceived(evt: IEvent): void;
    }
}
declare namespace ingenuity.platform.genericroulette {
    class ServerComm extends basetable.ServerComm {
        protected model: Model;
        protected cheatField: HTMLInputElement;
        private action;
        private totalPlayer;
        constructor(model: Model);
        protected sendRequest(requestData: IRequestInit | IRequestBet): void;
        protected sendInitRequest(evt: IEvent): void;
        protected getInitGameRequest(): IRequestInit;
        protected sendBetRequest(evt: IEvent): void;
        protected getPlayRequest(): IRequestBet;
        protected CloseGame(evt: IEvent): void;
        protected getCloseGameRequest(): IRequestInit;
        protected parseServerResponse(data: IResponse): void;
        protected handleServerError(data: any): void;
    }
}
declare namespace ingenuity.core.constructors.platforms {
    let genericroulette: {
        Model: typeof platform.genericroulette.Model;
        Parser: typeof platform.genericroulette.Parser;
        ServerComm: typeof platform.genericroulette.ServerComm;
    };
}
declare namespace ingenuity.platform.genericroulette {
    interface IRequestInit {
        action: string;
    }
    interface IRequestBet {
        action: string;
        bets: IPlayerBet[];
    }
}
