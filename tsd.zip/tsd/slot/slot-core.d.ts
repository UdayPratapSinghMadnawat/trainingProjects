/** 
	Slot Core v1.4.3 
	©Ingenuity Gaming Pvt. Ltd.
	Published: Tue Sep 11 2018 12:32:19 GMT+0530 (India Standard Time) 
**/
/* tslint:disable */
/// <reference path="../platform/platform-core.d.ts" />
declare namespace ingenuity.slot.BaseGame {
    class BaseController {
        protected view: BaseGame.View;
        protected model: BaseGame.Model;
        protected json: IObject;
        protected assets: any;
        protected slotLogic: Logic.SlotGameLogic;
        protected buttonController: ButtonController;
        protected meterController: MetersController;
        protected playerMsgController: any;
        protected reelPanelController: ReelPanelController;
        protected winPresentationController: WinPresentationController;
        constructor(view: BaseGame.View, model: Model, json: IObject, assetManager: any);
        protected subscribeEvents(): void;
        protected onFreeGamereturning(evt: IEvent): void;
        protected onHideBaseGame(evt: IEvent): void;
        protected onShowBaseGame(evt: IEvent): void;
        protected onInitializeSlotLogic(evt: IEvent): void;
        protected onInitializeAllControllers(evt: IEvent): void;
        protected initializeButtonController(): void;
        protected initializeMeterController(): void;
        protected initializePlayerMsgController(): void;
        protected initializeReelPanelController(): void;
        protected initializeWinPresentationController(): void;
        protected onFokTweenComplete(): void;
    }
}
declare namespace ingenuity.slot.slotConstants {
    let SlotEventConstants: {
        SPIN_CLICKED: string;
        SKIP_CLICKED: string;
        SPIN_CLICKED_IN_FREE_GAME: string;
        UPDATE_AUTOPLAY_BUTTONS: string;
        UPDATE_AUTOPLAY_METERS: string;
        CLEAR_SPIN_TIMER: string;
        REMOVE_ALL_LISTNERS_FROM_STAGE: string;
        DISABLED_ALL_BUTTONS: string;
        ENABLED_ALL_BUTTONS: string;
        ENABLE_BUTTON: string;
        DISABLE_BUTTON: string;
        SUSPEND_WINPRESENTATION: string;
        DO_NEXT_SPIN: string;
        CLEAR_DATA: string;
        SUBSCRIBE_BASEGAME_REELPANEL_EVENTS: string;
        UNSUBSCRIBE_BASEGAME_REELPANEL_EVENTS: string;
        SUBSCRIBE_FREEGAME_REELPANEL_EVENTS: string;
        UNSUBSCRIBE_FREEGAME_REELPANEL_EVENTS: string;
        SUBSCRIBE_BASEGAME_WIN_PRESENTATION_EVENTS: string;
        UNSUBSCRIBE_BASEGAME_WIN_PRESENTATION_EVENTS: string;
        SUBSCRIBE_FREEGAME_WIN_PRESENTATION_EVENTS: string;
        UNSUBSCRIBE_FREEGAME_WIN_PRESENTATION_EVENTS: string;
        VALIDATE_BET: string;
        VALIDATE_BET_IN_FREEGAME: string;
        RESET_METERS: string;
        UPDATE_BET_METER: string;
        UPDATE_PAID_METER: string;
        UPDATE_TOTAL_WIN_METER: string;
        UPDATE_FREEGAME_LEFT_METER: string;
        ON_SET_FREEGAME_LEFT: string;
        UPDATE_TOTAL_BET_METER: string;
        UPDATE_BALANCE_METER_AFTER: string;
        UPDATE_BALANCE_METER_AFTER_SPIN_CLICK: string;
        STOP_METER_TICKUP: string;
        UPDATE_BALANCE_METER_BEFORE: string;
        UPDATE_BALANCE_METER: string;
        UPDATE_STAKE_METER: string;
        SUBSCRIBE_EVENTS_ON_REEL_START: string;
        SUBSCRIBE_EVENTS_ON_REEL_START_BG: string;
        SUBSCRIBE_EVENTS_ON_REEL_START_FG: string;
        STOP_REEL_NOW: string;
        CHECK_FOR_ANTICIPATION_ON_REELS: string;
        UPDATE_SYMBOLS_ON_GRID: string;
        NULL_SPIN_BTN: string;
        UPDATE_REELVIEW_MODEL_FOR_QUICKSPIN: string;
        ENABLE_STOP_BTN: string;
        HIDE_CONTAINERS: string;
        NOW_SPIN_REEL: string;
        SHOW_CONTAINERS: string;
        ENABLE_BUTTON_INTERACTION: string;
        DISABLED_BUTTON_INTERACTION: string;
        SHOW_SPIN_BTN_HIDE_STOP_BTN: string;
        SHOW_SKIP_BTN_DISABLED_HIDE_STOP_BTN: string;
        CHECK_FOR_WIN_AFTER_REEL_STOP: string;
        CHECK_FOR_AUTOPLAY_CONDITION: string;
        DISABLED_AUTOPLAY_BTN: string;
        AUTOPLAY_RESET: string;
        AUTOPLAY_RESET_ENABLE_BUTTONS: string;
        AUTOPLAY_COUNT: string;
        ENABLE_AUTOPLAY_STOP_BTN: string;
        RESET_PALYER_MSG_LABELS: string;
        SHOW_NEXT_WIN_PRESENTATION: string;
        SHOW_5OAK: string;
        HIDE_5OAK: string;
        SET_WINLINE_AND_WAYS_DATA: string;
        SHOW_SPAGHTTI: string;
        SHOW_ALL_WIN_FRAMES: string;
        START_WIN_TICK_UP: string;
        STOP_WIN_TICK_UP: string;
        ON_RETURNING_FG_UPDATE_METER: string;
        FORCE_STOP: string;
        START_SCATTER_PRESENTATION: string;
        START_BIG_WIN_PRESENTATION: string;
        START_FIRST_TOGGLE_CYCLE: string;
        START_SECOND_TOGGLE_CYCLE: string;
        START_FIRST_TOGGLE_CYCLE_WAYS: string;
        START_SECOND_TOGGLE_CYCLE_WAYS: string;
        UNSCBSCRIBE_ALL_EVENTS_ON_REEL_PANEL_CONTROLLER: string;
        STOP_ALL_WIN_ANIMATION_ON_REEL: string;
        SCBSCRIBE_BUTTON_CONTROLLERS_BG: string;
        UNSCBSCRIBE_BUTTON_CONTROLLERS_BG: string;
        SCBSCRIBE_BUTTON_CONTROLLERS_FG: string;
        UNSCBSCRIBE_BUTTON_CONTROLLERS_FG: string;
        SCBSCRIBE_METER_CONTROLLERS_BG: string;
        UNSCBSCRIBE_METER_CONTROLLERS_BG: string;
        SCBSCRIBE_METER_CONTROLLERS_FG: string;
        UNSCBSCRIBE_METER_CONTROLLERS_FG: string;
        ALL_REEL_SPINING: string;
        INITIALIZE_ALL_CONTROLLERS_BG: string;
        INITIALIZE_ALL_CONTROLLERS_FG: string;
        INITIALIZE_SLOT_LOGIC: string;
        WRAPPER_READY: string;
        INITIALIZE_BASE_CLASSES: string;
        INITIALIZE_BASE_CLASSES_COMPLETE: string;
        GAME_RESIZE: string;
        INTRO_HIDE_COMPLETE: string;
        OUTRO_HIDE_COMPLETE: string;
        INTRO_SHOW: string;
        INTRO_HIDE: string;
        OUTRO_SHOW: string;
        OUTRO_HIDE: string;
        INITIALIZE_BG_MODEL: string;
        INITIALIZE_FG_MODEL: string;
        SETUP_FG: string;
        ON_FREEGAME_RETURNING: string;
        SUBSCRIBE_WINPRESENTATION_PANEL_BG: string;
        UNSUBSCRIBE_WINPRESENTATION_PANEL_BG: string;
        SUBSCRIBE_WINPRESENTATION_PANEL_FG: string;
        UNSUBSCRIBE_WINPRESENTATION_PANEL_FG: string;
        HIDE_BASEGAME_VIEW: string;
        SHOW_BASEGAME_VIEW: string;
        HIDE_FREEGAME_VIEW: string;
        SHOW_FREEGAME_VIEW: string;
        SHOW_WIN_PAYLINE: string;
        SHOW_SCATTER_FRAMES: string;
        HIDE_WIN_PAYLINE: string;
        SHOW_ALL_WIN_PAYLINE: string;
        HIDE_ALL_WIN_PAYLINE: string;
        HIDE_ALL_PAYLINE: string;
        HIDE_ALL_SPAGETTI: string;
        FLASH_SPAGETTI: string;
        SHOW_SPAGETTI: string;
        SHOW_ALL_FRAMES: string;
        HIDE_ALL_FRAMES: string;
        SHOW_PAYLINE: string;
        HIDE_PAYLINE: string;
        HIDE_PAYLINE_WINBOX: string;
        HIDE_ALL_PAYLINE_WINBOX: string;
        PLAY_LANDING_ANIMATION_SOUND: string;
        CREATE_WINBOX: string;
        CREATE_PAYLINE_SPAGGITTE: string;
        SUMUP_BIGWIN: string;
        CLEAR_STICKY_WILD_DATA: string;
        PLAY_STICKY_WILD_SYMBOL_ANIM: string;
        START_RETRIGGER_IN_FREEGAME: string;
        SHOW_FREEGAME_RETRIGGER_POPUP: string;
        CLEAR_RANDOM_WILD_DATA: string;
        START_RANDOM_WILD: string;
        RANDOM_WILD_APPEARED: string;
        UNSUBSCRIBE_RANDOM_WILD_EVENTS: string;
        STOP_WILD_ON_EXPWILD: string;
        STOP_SCATTER_ON_EXPWILD: string;
        INIT_EXPANDING_WILD: string;
        ON_ALL_REELS_STOPPED: string;
        CLEAR_EXP_WILD: string;
        SPIN_EXP_WILD_WITH_REEL: string;
        HIDE_EXP_WILD: string;
        HIDE_STICKY_CONTAINER: string;
        PLAY_STICKY_WILD_LANDING_ANIM: string;
        UNSUBSCRIBE_STICKY_EVENTS: string;
        PLAY_STICKY_SYMBOLS_ANIMATIONS: string;
        ADD_ANIM_OVERLAY_LAYER: string;
        ADD_ALL_OVERLAY_SYMBOLS_TO_ANIM_OVERLAY_LAYER: string;
        ADD_SYMBOL_TO_ANIM_OVERLAY_LAYER: string;
        CLEAR_ANIM_LAYER: string;
        PLACE_OVER_PAYLINES: string;
        SHOW_STICKY_VIEW: string;
        STICKY_ANIM_STARTED: string;
        REMOVE_STICKY_ICONS: string;
        FG_DISABLED_ALL_BUTTONS: string;
        FG_ENABLED_ALL_BUTTONS: string;
        FG_ENABLE_BUTTON: string;
        FG_DISABLE_BUTTON: string;
        FG_SUSPEND_WINPRESENTATION: string;
        FG_CLEAR_DATA: string;
        FG_RESET_METERS: string;
        FG_UPDATE_PAID_METER: string;
        FG_UPDATE_TOTAL_WIN_METER: string;
        FG_UPDATE_BALANCE_METER_AFTER: string;
        FG_UPDATE_BALANCE_METER_AFTER_SPIN_CLICK: string;
        FG_UPDATE_BALANCE_METER: string;
        FG_STOP_REEL_NOW: string;
        FG_CHECK_FOR_ANTICIPATION_ON_REELS: string;
        FG_UPDATE_SYMBOLS_ON_GRID: string;
        FG_NULL_SPIN_BTN: string;
        FG_UPDATE_REELVIEW_MODEL_FOR_QUICKSPIN: string;
        FG_ENABLE_STOP_BTN: string;
        FG_HIDE_CONTAINERS: string;
        FG_NOW_SPIN_REEL: string;
        FG_SHOW_CONTAINERS: string;
        FG_ENABLE_BUTTON_INTERACTION: string;
        FG_DISABLED_BUTTON_INTERACTION: string;
        FG_SHOW_SPIN_BTN_HIDE_STOP_BTN: string;
        FG_SHOW_SKIP_BTN_DISABLED_HIDE_STOP_BTN: string;
        FG_CHECK_FOR_WIN_AFTER_REEL_STOP: string;
        FG_SHOW_NEXT_WIN_PRESENTATION: string;
        FG_SHOW_5OAK: string;
        FG_HIDE_5OAK: string;
        FG_SET_WINLINE_AND_WAYS_DATA: string;
        FG_SHOW_SPAGHTTI: string;
        FG_SHOW_ALL_WIN_FRAMES: string;
        FG_START_WIN_TICK_UP: string;
        FG_FORCE_STOP: string;
        FG_START_SCATTER_PRESENTATION: string;
        FG_START_BIG_WIN_PRESENTATION: string;
        FG_START_FIRST_TOGGLE_CYCLE: string;
        FG_START_SECOND_TOGGLE_CYCLE: string;
        FG_START_FIRST_TOGGLE_CYCLE_WAYS: string;
        FG_START_SECOND_TOGGLE_CYCLE_WAYS: string;
        FG_UNSCBSCRIBE_ALL_EVENTS_ON_REEL_PANEL_CONTROLLER: string;
        FG_STOP_ALL_WIN_ANIMATION_ON_REEL: string;
        FG_ALL_REEL_SPINING: string;
        FG_SHOW_WIN_PAYLINE: string;
        FG_SHOW_SCATTER_FRAMES: string;
        FG_SHOW_ALL_WIN_PAYLINE: string;
        FG_HIDE_ALL_WIN_PAYLINE: string;
        FG_HIDE_ALL_PAYLINE: string;
        FG_HIDE_ALL_SPAGETTI: string;
        FG_FLASH_SPAGETTI: string;
        FG_SHOW_SPAGETTI: string;
        FG_SHOW_ALL_FRAMES: string;
        FG_HIDE_ALL_FRAMES: string;
        FG_SHOW_PAYLINE: string;
        FG_HIDE_PAYLINE: string;
        FG_HIDE_PAYLINE_WINBOX: string;
        FG_HIDE_ALL_PAYLINE_WINBOX: string;
        FG_CREATE_WINBOX: string;
        FG_CREATE_PAYLINE_SPAGGITTE: string;
        INITIATE_REELPANEL: string;
        SPIN: string;
        STOP_SPIN: string;
        SPIN_COMPLETE: string;
        REEL_STOPPED: string;
        REEL_STOPPING: string;
        LINE_ANIMATION_STARTED: string;
        START_SCATTER_WIN_ANIM: string;
        SCATTER_ANIMATION_STARTED: string;
        SCATTER_ANIMATION_ENDED: string;
        LINE_ANIMATION_ENDED: string;
        SYMBOL_ANIM_STARTED: string;
        SYMBOL_ANIM_ENDED: string;
        START_All_WIN_ANIM: string;
        START_WIN_ANIM: string;
        START_WAYS_ANIM: string;
        WIN_CYCLE_COMPLETED: string;
        WAY_ANIMATION_STARTED: string;
        WAY_ANIMATION_ENDED: string;
        START_EXPANDING_WILD: string;
        PLAY_EXPANDING_WILD: string;
        CLEAR_EXPANDING_WILD: string;
        SHOW_STICKY_WILD: string;
        PLAY_STICKY_WILD_ANIMATION: string;
        CLEAR_STICKY_WILD: string;
        RESET_SHIFTING_WILD: string;
        CHANGE_SYMBOL: string;
        PLAY_CHANGE_SYMBOL_SOUND: string;
        SHOW_SHIFTING_WILD: string;
        MOVE_SHIFTING_WILD: string;
        CLEAR_SHIFTING_WILD: string;
        TWEEN_SHIFTING_WILD: string;
        WILD_SHIFTED: string;
        INTRO_OUTRO_HIDDEN: string;
        STOP_ALL_WIN_ANIMATIONS: string;
        SPIN_STARTED: string;
        SHOW_ANTICIPATION: string;
        SHOW_LANDINGANIMATION: string;
        SHOW_BIG_WIN: string;
        BIG_WIN_HIDDEN: string;
        REEL_MASK_ON: string;
        REEL_MASK_OFF: string;
        FG_INITIATE_REELPANEL: string;
        FG_SPIN: string;
        FG_STOP_SPIN: string;
        FG_SPIN_COMPLETE: string;
        FG_REEL_STOPPED: string;
        FG_REEL_STOPPING: string;
        FG_LINE_ANIMATION_STARTED: string;
        FG_START_SCATTER_WIN_ANIM: string;
        FG_SCATTER_ANIMATION_STARTED: string;
        FG_SCATTER_ANIMATION_ENDED: string;
        FG_LINE_ANIMATION_ENDED: string;
        FG_START_All_WIN_ANIM: string;
        FG_START_WIN_ANIM: string;
        FG_START_All_WAYS_ANIM: string;
        FG_START_WAYS_ANIM: string;
        FG_WIN_CYCLE_COMPLETED: string;
        FG_WAY_ANIMATION_STARTED: string;
        FG_WAY_ANIMATION_ENDED: string;
        FG_START_EXPANDING_WILD: string;
        FG_STOP_ALL_WIN_ANIMATIONS: string;
        FG_SHOW_ANTICIPATION: string;
        FG_SHOW_LANDINGANIMATION: string;
        FORCE_HIDE_REEL_SYMBOLS: string;
        ON_FIVE_OF_A_KIND_TWEEN_COMPLETE: string;
        WIN_ON_REELS: string;
        GAME_MSG_SHOW: string;
        GAME_MSG_HIDE: string;
        LOGIC_ONSTAKE_CHANGE: string;
        LOGIC_ONINFO_PRESSED: string;
        LOGIC_SHOW_GAME_MESSAGE: string;
        LOGIC_HIDE_GAME_MESSAGE: string;
        LOGIC_ON_UNSUBSCRIBE_REEL_PANEL_EVENTS: string;
        UPDATE_REEL_CONFIG: string;
        DOMMOUSESCROLL: string;
        MOUSEWHEEL: string;
        KEYDOWN: string;
        DISABLE_SPACEBAR_EVENTS: string;
        ENABLE_SPACEBAR_EVENTS: string;
        KEY_DOWN_FG: string;
    };
}
declare namespace ingenuity.slot.slotConstants {
    class SlotConstants {
        static MainData: string;
        static SpinBtnId: string;
        static SkipBtnId: string;
        static reSpinBtnId: string;
        static SpinStopBtnId: string;
        static BetMinusBtnId: string;
        static BetPlusBtnId: string;
        static AutoPlayBtnId: string;
        static AutoPlayOffBtnId: string;
        static StopAutoPlayBtnId: string;
        static InfoBtnId: string;
        static SettingBtnId: string;
        static ButtonsContainerId: string;
        static AutoPlayOnBtnContainer: string;
        static AutoPlayOffBtnContainer: string;
        static MenuContainerId: string;
        static WinBoxContainerId: string;
        static PayLineContainerId: string;
        static SpaggitteContainerId: string;
        static SettingCloseBtnId: string;
        static FreegameLeftMtrId: string;
        static BetMeterId: string;
        static TotalBetMeterId: string;
        static StakeMeterId: string;
        static BalanceMeterId: string;
        static WinMeterId: string;
        static AutoPlayMeterId: string;
        static BalanceMeterIdFG: string;
        static WinMeterIdFG: string;
        static totalWinMeterIdFG: string;
        static IntroContinueBtn: string;
        static OutroContinueBtn: string;
        static IntroOutroContainer: string;
        static IntroContainer: string;
        static OutroContainer: string;
        static LogicScopeBG: string;
        static LogicScopeFG: string;
        static TimerForDisplayOutro: string;
        static TimerForNextFreeSpin: string;
        static TimerHidePayline: string;
        static TimerForFiveOfKind: string;
        static TimerScatterAnimationEnded: string;
        static TimerAnimateNextWinLine: string;
        static TimerAllAnimateWin: string;
        static TimerDelayInWinBox: string;
        static TimerSendBetWithDelay: string;
        static StopSpinTimer: string;
        static StartSpinTimer: string;
        static StopTimerStopNow: string;
        static AnticipationDelayTimer: string;
        static StopReelId: string;
        static SpaghettiDisplayTimer: string;
        static ButtonDisplayDelayTimer: string;
        static DelayFinalAmount: string;
        static BaseGameReelSetIndex: number;
        static FreeGameReelSetIndex: number;
        static baseGameState: string;
        static freeGameState: string;
        static stopBtnContainer: string;
        static settingAutoPlayContainer: string;
        static settingContainer: string;
        static autoPlayContainer: string;
        static FiveOKContainer: string;
        static KeyCodeSpaceBar: number;
        static KeyCodeEqualPlus: number;
        static KeyCodePlus: number;
        static KeyCodeSubtract: number;
        static KeyCodeNumbSubtract: number;
        static KeyCodeNumbEqualPlus: number;
        static KeyCodeSubtractUnderscore: number;
        static ResetAutoplayCount: number;
        static BetIncrement: number;
        static BetDecrement: number;
        static WinLineAnimTimeOutFirstToggle: number;
        static WinLineAnimTimeOutSecondToggle: number;
        static BigWinMultiplier: number;
        static MegaWinMultiplier: number;
        static SuperWinMultiplier: number;
        static BigWinMultiplierFG: number;
        static MegaWinMultiplierFG: number;
        static SuperWinMultiplierFG: number;
        static soundWinMeterTickup: string;
        static sound5OFKind: string;
        static soundFreeGameBGMusic: string;
        static soundFreeGameWinMeterTickup: string;
        static soundFreeGameWinMeterTickupComplete: string;
        static AnimOverlayReel: string;
        static AnimOverlayLayer: string;
        static AnticipationConatiner: string;
        static AnticipationIdPrefix: string;
        static LandingAnimName: string;
        static WinBoxPrefix: string;
        static WinBoxContainerPrefix: string;
        static WinBoxScatterPrefix: string;
        static WinBoxScatterContainerPrefix: string;
        static LinePrefix: string;
        static SpinePrefix: string;
        static SpaghettiPrefix: string;
        static StaticSymbolPrefix: string;
        static MultiSymbolPrefix: string;
        static AnimationPrefix: string;
        static LayeredPrefix: string;
        static NextAnimation: string;
        static LayerAnimation: string;
        static LayerSpine: string;
        static LayerStatic: string;
        static Frames: string;
        static MIN_SPIN_DELAY: string;
    }
}
declare namespace ingenuity.slot.BaseGame {
    class View extends ui.BaseView {
        protected anticipationContainer: ui.Container;
        protected fiveOfKindContainer: ui.Container;
        protected bigWinPresent: ui.Container;
        protected reelView: reelPanel.ReelPanel;
        protected winView: reelPanel.WinPresentationPanel;
        protected winOverlayView: reelPanel.WinPresentationOverlayPanel;
        protected paylineView: reelPanel.Paylines;
        protected fiveOfKindTween: ITween;
        constructor(viewJson: IContainer);
        setReelView(reelView: reelPanel.ReelPanel, pos?: number, parentId?: string): void;
        getReelView(): reelPanel.ReelPanel;
        setPaylineView(value: reelPanel.Paylines, pos?: number, parentId?: string): void;
        getPaylineView(): reelPanel.Paylines;
        setWinReelView(value: reelPanel.WinPresentationPanel, pos?: number, parentId?: string): void;
        getWinReelView(): reelPanel.WinPresentationPanel;
        setWinReelOverlayView(value: reelPanel.WinPresentationOverlayPanel, pos?: number, parentId?: string): void;
        getWinOverlayReelView(): reelPanel.WinPresentationOverlayPanel;
        clearAnticipation(): void;
        show5OfKind(fiveOfkindTimer: number): void;
        hide5OfKind(): void;
        hide(): void;
        show(): void;
        landingAnimation(data: any, callback?: () => void, callbackScope?: any): void;
        showAnticipation(reel: number, callback?: () => void, callbackScope?: any): void;
    }
}
declare namespace ingenuity {
    interface IBigWinFountainOptions {
        w: number;
        h: number;
        fromBottomOut: boolean;
        allAtOnce: boolean;
        offsetHeight: number;
        offsetX: number;
        speed: number;
        numParticles: number;
        deltaX: number;
        deltaY: number;
    }
    interface OverlapSymbolData extends IObject {
        symbolId: {
            scaleX: number;
            scaleY: number;
            regX: number;
            regY: number;
            rotate: number;
            skewX: number;
            skewY: number;
        };
    }
    interface IWinLineObject extends IObject {
        positions: number[][];
        no: number;
        winSymLen: number;
        win: number;
        id: number;
    }
}
declare namespace ingenuity.slot.BaseGame {
    class Model {
        protected fadeOutTimeWinBox: number;
        protected reelsets: number[][][] | string[][][];
        protected animationSequence: string[];
        protected animationSequenceCounter: number;
        protected serverModel: platform.baseslot.Model;
        protected gameConfig: IObject;
        protected isTurboMode: boolean;
        protected totalAutoSpins: number;
        protected currentAutoSpinIndex: number;
        protected stopReel: boolean;
        protected delayForSpaghttiDisplay: number;
        protected fiveOAKDispalyTimer: number;
        protected tickUpDuration: number;
        protected allReelSpinning: boolean;
        protected reelSpinning: boolean;
        protected serverResponseReceived: boolean;
        protected reSpinIdentifier: boolean;
        protected reSpinCounter: number;
        constructor(serverModel: platform.baseslot.Model);
        setAllReelSpinning(value: boolean): void;
        getAllReelSpinning(): boolean;
        setReelSpinning(value: boolean): void;
        isReelSpinning(): boolean;
        setServerResponseReceived(value: boolean): void;
        getServerResponseReceived(): boolean;
        setFadeOutTimeWinBox(value: number): void;
        getFadeOutTimeWinBox(): number;
        setAnimationSequence(value: string[]): void;
        getAnimationSequence(): string[];
        setReelSet(value: number[][][] | string[][][]): void;
        getReelSets(): number[][][] | string[][][];
        getReelSet(id: number): number[][] | string[][];
        reSetAnimationSequenceCounter(value: number): void;
        updateAnimationSequenceCounter(): void;
        getAnimationSequenceCounter(): number;
        setGameConfig(value: IObject): void;
        getGameConfig(): IObject;
        getIsTurboModeOn(): boolean;
        setIsTurboModeOn(value: boolean): void;
        getTotalAutoSpins(): number;
        setTotalAutoSpins(value: number): void;
        getDelayForSpaghttiDispaly(): number;
        setDelayForSpaghttiDispaly(value: number): void;
        getFiveOfAKindDisplayTime(): number;
        setFiveOfAKindDisplayTime(value: number): void;
        getTickUpDuration(): number;
        setTickUpDuration(value: number): void;
        setUpdateCurrentAutoSpinIndex(): void;
        reSetCurrentAutoSpinIndex(): void;
        getCurrentAutoSpinIndex(): number;
        setIsStopReel(value: boolean): void;
        getIsStopReel(): boolean;
        getReelStops(): number[];
        setReelStops(value: number[]): void;
        getReelGrid(): Array<Array<number>>;
        getTriggeringReelGrid(): number[][];
        resetForSpin(): void;
        getIsCredits(): boolean;
        clearFreeSpinData(): void;
        getIsWin(): boolean;
        getIsTriggeringWin(): boolean;
        getIsLineWins(): boolean;
        getIsScatterWins(): boolean;
        getIsWonFreeSpin(): boolean;
        getTotalFreeSpin(): boolean;
        getIsTriggeringGrid(): boolean;
        getIsWonBonus(): boolean;
        getIs5OfKindAvailable(): boolean;
        getWinLinesData(): IWinLineObject[];
        setWinLinesData(value: IWinLineObject[]): void;
        getWaysWinData(): IWinLineObject[];
        getWaysWinAllUniquePositions(): number[][];
        getIsWaysWins(): boolean;
        getTriggeringWinLinesData(): IWinLineObject[];
        readonly scatterWinData: IWinLineObject[];
        getTriggerScatterWinData(): IWinLineObject[];
        getNextAvailableBet(): number;
        getPrevAvailableBet(): number;
        getIsBigWin(): number;
        getIsBrokenFreeGame(): boolean;
        getIsBrokenBaseGame(): boolean;
        getBalance(): number;
        getCurrentBet(): number;
        getTotalBet(): number;
        getCurrentWinAmt(): number;
        getTotalWinAmt(): number;
        getHasEnoughBalance(): boolean;
        setUpdatedBalanceForSpin(): void;
        setUpdatedBalanceAfterWin(): void;
        getFreeSpinWin(): number;
        resetAutoPlay(): void;
        getIsAutoPlayLeft(): boolean;
        getGameState(): number;
        setReSpinData(reSpin: boolean, reSpinCounter: number): void;
        getReSpinIdentifier(): boolean;
        getReSpinCounter(): number;
    }
}
declare namespace ingenuity.slot.BaseGame {
    class ButtonController {
        protected spinBtn: ui.ButtonBase;
        protected spinStopBtn: ui.ButtonBase;
        protected betMinusBtn: ui.ButtonBase;
        protected betPlusBtn: ui.ButtonBase;
        protected autoPlayBtn: ui.ButtonBase;
        protected autoPlayOffBtn: ui.ButtonBase;
        protected infoBtn: ui.ButtonBase;
        protected settingBtn: ui.ButtonBase;
        protected settingCloseBtn: ui.ButtonBase;
        protected view: View;
        protected reelView: slot.reelPanel.ReelPanel;
        protected model: Model;
        protected isRemoveKeyListeners: boolean;
        constructor(view: BaseGame.View, model: BaseGame.Model);
        protected initializeButtons(view: BaseGame.View): void;
        protected bindHandlers(): void;
        protected unBindHandlers(): void;
        protected spaceKeyBoardEvent(): void;
        protected removeSpaceBarEvent(e: IEvent): void;
        protected addSpaceBarEvent(e: IEvent): void;
        protected keyboardKeyDown(event: KeyboardEvent): void;
        protected onSpinPressUp(button?: ui.ButtonBase): void;
        protected setAutoPlayCounting(evt: IEvent): void;
        protected onAutoPlayPressUp(): void;
        protected resetAutoPlay(evt: IEvent): void;
        protected onAutoPlayOffPressUp(): void;
        protected onUpdateAutoPlayBtns(evt: IEvent): void;
        protected onSpinStopPressUp(): void;
        protected onBetPlusPressUp(): void;
        protected onChangeStake(value: number): void;
        protected onBetMinusPressUp(): void;
        protected onInfoPressUp(): void;
        protected onSettingPressUp(): void;
        protected onSettings(): void;
        protected onSettingClose(): void;
        protected onSettingClosePressUp(): void;
        protected onShowSpinBtnHideStopBtn(evt: IEvent): void;
        protected subscribeEvents(): void;
        protected unsubscribeEvents(): void;
        protected onEnableAutoStopBtn(evt: IEvent): void;
        protected onDisabledAutoPlayBtn(evt: IEvent): void;
        protected nullSpinButton(evt: IEvent): void;
        protected onEnableStopBtn(evt: IEvent): void;
        protected onClearData(evt: IEvent): void;
        protected onHideContainers(evt: IEvent): void;
        protected showContainers(evt: IEvent): void;
        protected onDisabledAllButtons(evt: IEvent): void;
        protected onEnableAllButtons(evt: IEvent): void;
        protected enableMenuBtn(): void;
        protected onEnabledButton(evt: IEvent): void;
        protected onDisabledButton(evt: IEvent): void;
        protected onShowContainers(evt: IEvent): void;
        protected onRemoveAllListnersFromStage(evt: IEvent): void;
        protected onDisableButtonInteraction(evt: IEvent): void;
        protected onEnableButtonInteraction(evt: IEvent): void;
    }
}
declare namespace ingenuity.slot.BaseGame {
    class MetersController {
        protected betMeter: ui.Meter;
        protected totalBetMeter: ui.Meter;
        protected stakeMeter: ui.Meter;
        protected balanceMeter: ui.Meter;
        protected winMeter: ui.Meter;
        protected autoPlayMeter: ui.Meter;
        protected view: View;
        protected model: Model;
        constructor(view: View, model: Model);
        protected bindHandlers(): void;
        protected subscribeEvents(): void;
        protected unsubscribeEvents(): void;
        protected onStartWinTickUp(evt: IEvent): void;
        protected onStopWinTickUp(evt: IEvent): void;
        protected onReturningFreegameUpdateMeter(evt: IEvent): void;
        protected updateBalance(): void;
        protected updateBalanceafterFG(): void;
        protected onUpdateBalanceMeterAfter(evt: IEvent): void;
        protected onUpdateBalanceMeterAfterSpinClick(evt: IEvent): void;
        protected updateMeterForCreditCoin(meter: ui.Meter, value: string): void;
        protected onUpdateBalanceMeter(evt: IEvent): void;
        protected onUpdateStakeMeter(evt: IEvent): void;
        protected onResetMeters(evt: IEvent): void;
        protected onUpdateBetMeter(evt: IEvent): void;
        protected updateValueForCreditCoin(evt: IEvent): void;
        protected onUpdatePaidMeter(evt: IEvent): void;
        protected onUpdateTotalBetMeter(evt: IEvent): void;
        protected onUpdateAutoPlayMeter(evt: IEvent): void;
        protected onStopMeterTickup(evt: IEvent): void;
    }
}
declare namespace ingenuity.slot.BaseGame {
    abstract class PlayerMsgController {
        protected view: View;
        protected model: Model;
        protected messageDiv: HTMLDivElement;
        protected json: IObject;
        protected assets: IObject;
        protected locale: IObject;
        protected baseContainer: HTMLElement;
        constructor(view: View, model: Model, json: IObject, assets: IObject);
        protected bindHandlers(): void;
        protected abstract subscribeEvents: void;
        protected abstract showMessages(evt: IEvent): void;
        protected abstract showPromoMessages(evt: IEvent): void;
        protected abstract showWinLineMessage(evt: IEvent): void;
        protected abstract showGoodLuckMessage(evt: IEvent): void;
        protected abstract clearMessage(evt: IEvent): void;
    }
}
declare namespace ingenuity.slot.BaseGame {
    class ReelPanelController {
        protected view: View;
        protected model: Model;
        protected reelView: reelPanel.ReelPanel;
        protected winReelView: reelPanel.WinPresentationPanel;
        protected paylineView: reelPanel.Paylines;
        protected anticipationList: Array<Array<number>>;
        constructor(view: View, model: Model);
        protected init(): void;
        protected unsubscribeEvents(): void;
        protected bindHandlers(): void;
        protected subscribeEvents(): void;
        addAnimOverlayLayer(layer: any): void;
        protected onUnScribeAllReelPanelEvents(evt: IEvent): void;
        protected onReelsForceStop(): void;
        protected onStopReelNow(evt: IEvent): void;
        protected onSpinReel(evt: IEvent): void;
        protected onUpdateSymbolsOnGrid(): void;
        protected onCheckingAnticipationOnReels(): void;
        protected updateModelForQuickSpin(): void;
        protected showAnticipation(e?: IEvent): void;
        protected showLanding(e?: IEvent): void;
        protected onReelStartSubscribeEvents(evt: IEvent): void;
        protected onReelStopped(evt?: IEvent): void;
        protected onSpinComplete(evt?: IEvent): void;
        protected onReelStoping(evt?: IEvent): void;
        protected checkForAnticipation(symbolObj: any, listLength: number): void;
        protected checkForlandingAnim(symbolObj: any, listLength: number): void;
        protected onClearData(evt: IEvent): void;
        addAllOverlaySymobolsToAnimOverlayLayer(): void;
        addSymobolToAnimOverlayLayer(reelNum: number, rowNum: number): void;
        clearSymbAnimLayer(): void;
        protected placeOverPayline(data: any): void;
    }
}
declare namespace ingenuity.slot.BaseGame {
    class WinPresentationController {
        protected paylineView: slot.reelPanel.Paylines;
        protected reelView: slot.reelPanel.WinPresentationPanel;
        protected view: View;
        protected model: Model;
        protected fiveOfKindDuration: number;
        protected togglingCycle: number;
        constructor(view: View, model: Model);
        protected subscribeEvents(): void;
        protected unsubscribeEvents(): void;
        protected onSymbolAnimStarted(evt: IEvent): void;
        protected onSymbolAnimEnded(evt: IEvent): void;
        protected onWinCycleCompleted(evt: IEvent): void;
        protected onLineAnimStarted(evt: IEvent): void;
        protected onWayAnimStarted(evt: IEvent): void;
        protected onLineAnimEnded(evt: IEvent): void;
        protected onWayAnimEnded(evt: IEvent): void;
        protected onStartBigWinPresentation(evt: IEvent): void;
        protected updateReelViewForFirstToggle(): void;
        protected onStartFirstToggleCycle(evt: IEvent): void;
        protected onStartFirstToggleCycleWays(evt: IEvent): void;
        protected onScatterAnimationEnd(evt: IEvent): void;
        protected onStartScatterPresentation(evt: IEvent): void;
        protected updateReelViewForSecondToggle(evt: IEvent): void;
        protected onStartSecondToggleCycle(evt: IEvent): void;
        protected onStartSecondToggleCycleWays(evt: IEvent): void;
        protected cofigureEventOnBigWinHide(): void;
        protected onShowSpaghtti(evt: IEvent): void;
        protected onShowAllFrames(evt: IEvent): void;
        protected onShow5OAK(evt: IEvent): void;
        protected onHide5OAK(evt: IEvent): void;
        protected onSetWinLineAndWaysUniqueData(evt: IEvent): void;
        protected onReelStartSubscribeEvents(evt: IEvent): void;
        protected onClearData(): void;
        protected onStopAllWinAnimation(): void;
        protected onSuspendWinPresentation(): void;
    }
}
declare namespace ingenuity.slot.symbol {
    interface ISymbolData {
        x?: number;
        y?: number;
        width?: number;
        height?: number;
        symNum: number;
        symName?: string;
        symType?: string | string[];
        zIndex?: number;
        enableEvents?: boolean;
        animation?: string;
        defaultAnimType: string;
        iconSpacingX?: number;
        iconSpacingY?: number;
        overlay?: OverlapSymbolData;
        blurYValue?: number;
        alwaysAnimate?: boolean;
        staticSym: IStaticSymbolData;
        blurSym: IStaticSymbolData | boolean;
        animSym: string | IAnimationSymbolData | ISpineSymbolData | ILayeredSymbolData;
        container: string;
    }
    interface IStaticSymbolData extends IStaticAnimation {
        width?: number;
        height?: number;
        animType: string;
        image?: string;
        posterFrame?: string;
        frame?: number;
        anchorX?: number;
        anchorY?: number;
        regX?: number;
        regY?: number;
        scaleX?: number;
        scaleY?: number;
        scale?: number;
        enableEvents?: boolean;
    }
    interface IStaticAnimation extends IObject {
        wait?: number;
        time?: number;
        scaleto?: number;
        loop?: number | boolean;
        override?: boolean;
        callback?: () => void;
        sym2Flash?: number;
        sym2Wait?: number;
        brightness?: number;
        contrast?: number;
    }
    interface IAnimationSymbolData extends IStaticSymbolData {
        animType: string;
        alwaysAnimate?: boolean;
        animations: {
            [key: string]: IAnimationProperties | string;
        };
    }
    interface IAnimationProperties extends IObject {
        generateNames?: boolean;
        prefix?: string;
        suffix?: string;
        zeroPad?: number;
        frames: number[] | string[];
        frameRate: number;
        loop: boolean;
    }
    interface ISymbol {
        num: number;
        gridPosition: number;
        animType: string | string[];
        playAnim(opts?: any): any;
        stopAnim(): void;
        on(type: string, handler: (evt?: IEvent | any, data?: IObject) => void, scope?: any, once?: boolean, data?: any, priority?: number): void;
        off(type: string, handler?: (evt: IEvent | any, data?: IObject) => void, scope?: any): void;
        hasEvent(type: string): boolean;
        fireEvent(type: string, data?: any): void;
        toString(): string;
    }
    interface ISpineSymbolData extends ISpineData, IAnimationSymbolData {
        animations: {
            [key: string]: string;
        };
    }
    interface ILayeredSymbolData extends IContainer, IAnimationSymbolData {
        layers: IStaticSymbolData[] | IAnimationSymbolData[] | ISpineSymbolData[];
    }
}
declare namespace ingenuity.slot.symbol {
    abstract class AbstractSymbol extends ui.Sprite implements ISymbol {
        skew: ui.Point;
        animType: string | string[];
        protected json: IStaticSymbolData;
        protected oldX: number;
        protected oldY: number;
        num: number;
        protected animating: boolean;
        protected animObj: {
            [key: string]: ui.Animation;
        } | ui.Animation | ITween;
        gridPosition: number;
        zIndex: number;
        private signals;
        constructor(id: number, json: IStaticSymbolData, frame?: number | string, name?: string, zIndex?: number);
        protected setPosterFrame(json: IStaticSymbolData): void;
        protected abstract init(json: IStaticSymbolData, name?: string): void;
        abstract playAnim(opts: any): void;
        abstract stopAnim(): void;
        abstract stopSymbolAllAnim(): void;
        on(type: string, handler: (evt?: IEvent | any, data?: IObject) => void, scope?: any, once?: boolean, data?: any, priority?: number): void;
        off(type: string, handler?: (evt: IEvent | any, data?: IObject) => void, scope?: any): void;
        hasEvent(type: string): boolean;
        fireEvent(type: string, data?: any): void;
        toString(): string;
    }
}
declare namespace ingenuity.slot.symbol {
    class StaticSymbol extends AbstractSymbol {
        protected animObj: ITween;
        protected animDefaults: IStaticAnimation;
        constructor(id: number, json: IStaticSymbolData, name: string, zIndex: number);
        protected init(json: IStaticSymbolData, name?: string): void;
        updateData(json: ISymbolData): void;
        playAnim(animName?: any): void;
        resetScaleAnim(): void;
        stopAnim(): void;
        stopSymbolAllAnim(): void;
    }
}
declare namespace ingenuity.slot.symbol {
    class AnimationSymbol extends AbstractSymbol {
        protected animObj: {
            [key: string]: ui.Animation;
        };
        protected json: IAnimationSymbolData;
        constructor(id: number, json: IAnimationSymbolData, name?: string, zIndex?: number);
        protected init(json: IAnimationSymbolData, name?: string): void;
        hasAnimation(key: string): boolean;
        playAnim(animName?: any, stopFrame?: string, callback?: () => void, cbScope?: any): void;
        stopAnim(opts?: string): void;
        stopSymbolAllAnim(): AnimationSymbol;
        resetTriggeringIcon(): AnimationSymbol;
        protected setPosterFrame(json: IAnimationSymbolData): void;
    }
}
declare namespace ingenuity.slot.symbol {
    class SpineSymbol extends ui.SpineBase implements ISymbol {
        num: number;
        gridPosition: number;
        animType: string | string[];
        zIndex: number;
        skew: ui.Point;
        json: ISpineSymbolData;
        constructor(id: number, json: ISpineSymbolData, name?: string, zIndex?: number);
        protected init(json: ISpineSymbolData, name?: string): void;
        stopAnim(offset?: string): SpineSymbol;
        playAnim(animName?: any, loop?: boolean, trackIndex?: number): spine.TrackEntry;
        stopSymbolAllAnim(opts?: string): SpineSymbol;
        resetTriggeringIcon(offset?: string): SpineSymbol;
        x: number;
        y: number;
    }
}
declare namespace ingenuity.slot.symbol {
    class LayeredAnimationSymbol extends ui.Container implements ISymbol {
        protected symbolList: Array<AnimationSymbol | StaticSymbol | SpineSymbol>;
        json: IStaticSymbolData;
        num: number;
        gridPosition: number;
        animType: string;
        zIndex: number;
        skew: ui.Point;
        anchor: ui.Point;
        constructor(id: number, json: ILayeredSymbolData, name?: string, zIndex?: number);
        protected init(json: ILayeredSymbolData, name?: string): void;
        resetTriggeringIcon(offset?: number): void;
        playAnim(opts?: any): void;
        stopAnim(): void;
        stopSymbolAllAnim(): void;
        protected setPosterFrame(json: IAnimationSymbolData): void;
    }
}
declare namespace ingenuity.slot.symbol {
    class SymbolBase {
        json: ISymbolData;
        symType: string | Array<string>;
        symNum: number;
        gridPosition: number;
        zIndex: number;
        x: number;
        y: number;
        width: number;
        height: number;
        name: string;
        parent: IDisplayObject;
        animation: string;
        protected staticSym: StaticSymbol;
        protected blurSym: StaticSymbol;
        forceHide: boolean;
        protected animationSym: AnimationSymbol | SpineSymbol | LayeredAnimationSymbol;
        constructor(json: ISymbolData, id?: number);
        protected init(json: ISymbolData): void;
        protected createStatic(json: ISymbolData): void;
        protected createBlur(json: ISymbolData): void;
        protected createAnimation(json: ISymbolData): void;
        toString(): string;
        setPosition(x: number, y: number): void;
        setXPosition(x: number): void;
        setYPosition(y: number): void;
        returnToPool(): void;
        getStatic(): StaticSymbol | AnimationSymbol;
        getBlur(): StaticSymbol;
        getAnimation(): AnimationSymbol | SpineSymbol | StaticSymbol | LayeredAnimationSymbol;
    }
}
declare namespace ingenuity.slot.symbol {
    class SymbolFactory {
        private iconPos;
        private iconArray;
        private model;
        constructor(model: reelPanel.Model);
        private createIcons(model);
        getSymbol(id: number): SymbolBase;
        getIconBySymType(type: String): SymbolBase[][];
    }
}
declare namespace ingenuity.slot.symbol {
    class SymbolBase2 extends SymbolBase {
        json: ISymbolData;
        symType: string | Array<string>;
        symNum: number;
        gridPosition: number;
        zIndex: number;
        x: number;
        y: number;
        width: number;
        height: number;
        name: string;
        parent: IDisplayObject;
        animation: string;
        protected staticSym: StaticSymbol;
        protected blurSym: StaticSymbol;
        forceHide: boolean;
        protected animationSym: AnimationSymbol | SpineSymbol | LayeredAnimationSymbol;
        protected isInit: boolean;
        constructor(json: ISymbolData, id?: number);
        protected init(json: ISymbolData): void;
        protected createBlur(json: ISymbolData): void;
        updateData(json: ISymbolData, id?: number): void;
        protected createAnimation(json: ISymbolData): void;
        getStatic(frameName?: string): StaticSymbol | AnimationSymbol;
        getBlur(): StaticSymbol;
        getAnimation(): AnimationSymbol | SpineSymbol | StaticSymbol | LayeredAnimationSymbol;
    }
}
declare namespace ingenuity.slot.symbol {
    class SymbolFactory2 {
        private iconPos;
        private iconArray;
        private model;
        constructor(model: reelPanel.Model);
        getSymbol(id: number): SymbolBase2;
        getIconBySymType(type: String): SymbolBase2[][];
    }
}
declare namespace ingenuity.slot.reelPanel {
    class Model {
        reelJson: IReel[];
        protected reelset: number[][];
        protected reelsets: number[][][];
        protected JSON: IReelPanel;
        totalSymbols: number;
        protected lockdReelArray: Array<boolean>;
        protected winLinData: Array<any>;
        protected currWinAnimationIndex: number;
        protected reelIndx: number[];
        winAnimCycleCount: number;
        playLineWinAnim: boolean;
        playWayWinAnim: boolean;
        protected reelGrd: Array<Array<number>>;
        protected stopPosition: Array<any>;
        protected paylinData: any;
        protected winboxData: any;
        protected mxPaylines: number;
        winningLines: any;
        protected paylinePositionData: Array<any>;
        defaultConfig: any;
        anticipationSpin: Array<number>;
        landingOnReel: Array<number>;
        spagettiVisible: boolean;
        winWayData: Array<any>;
        winWaySymbolData: any;
        wayUniqueWinData: Array<number[]>;
        protected isQuickSpin: boolean;
        stopHidden: boolean;
        fadeOutTimeWinBox: number;
        animOverlaySymOnToggle: boolean;
        constructor();
        noStopDelay: boolean;
        noStartDelay: boolean;
        spinDirection: number | number[];
        noStopBounce: boolean;
        noStartBounce: boolean;
        quickSpinSpeed: number;
        spinSpeed: number;
        stopDelay: number[];
        startDelay: number[];
        stopBounceTimeout: number[];
        stopBounceTime: number[];
        startBounceAmt: number[];
        startBounceTime: number[];
        startBounceTimeout: number[];
        stopBounceAmt: number[];
        protected updateReelConfig(): void;
        json: IReelPanel;
        readonly reelsJson: IReel[];
        paylineJson: any;
        readonly paylineData: any;
        readonly winBoxData: any;
        getReelJson(id: number): IReel;
        setReelsets(value: number[][][], startSet?: number): void;
        setReelset(set: number): void;
        getReelsets(): number[][][];
        getReelset(set: number): number[][];
        getCurrentReelset(): number[][];
        readonly symbolData: symbol.ISymbolData[];
        getSymbolBlurFrame(id: number): string;
        getSymbolStaticFrame(id: number): string;
        getSymbolData(id?: number): symbol.ISymbolData;
        getSymbolHeight(id?: number): number;
        getSymbolWidth(id?: number): number;
        getSymbolSpacingY(id?: number): number;
        readonly numReels: number;
        readonly reelLayering: number[];
        symbolLayeringType(): string;
        readonly anticipationSymbolCount: number;
        getAnticipationSymbolCount(reelId: number): number;
        getAniticipationLoops(id: number): number;
        getReelConfig(id: number): any;
        getAnticipationDelay(id: number): number;
        getAnticipationSpeed(id: number): number;
        getAnticipationRunAfterDelay(id: number): number;
        numDisplaySymbols(id: number): number;
        isReelLocked(id: number): boolean;
        lockReel: number | boolean[];
        reelStopIndex: number[];
        getReelStopIndex(id: number): number;
        readonly lockedReels: boolean[];
        readonly numReelsLocked: number;
        resetLockedReels(): void;
        reelStops: Array<any>;
        getReelGridElement(reel: number, row: number): number;
        reelGrid: Array<Array<number>>;
        setReelGrid(id: number, value: Array<number>): void;
        winLineData: Array<any>;
        readonly winLineDataLength: number;
        waysWinData: Array<any>;
        readonly waysWinDataLength: number;
        resetCurrentWinAnimIndex(): void;
        readonly nextWinAnimIndex: number;
        currentWinAnimIndex: number;
        paylinesPosData: Array<any>;
        readonly maxPaylines: number;
        quickSpin: boolean;
    }
}
declare namespace ingenuity.slot.reelPanel {
    import SymbolBase = symbol.SymbolBase;
    import StaticSymbol = symbol.StaticSymbol;
    import AnimationSymbol = symbol.AnimationSymbol;
    import LayeredAnimIcon = symbol.LayeredAnimationSymbol;
    import SpineSymbol = symbol.SpineSymbol;
    class Reel extends ui.Container {
        protected reelSet: Array<number>;
        reelId: number;
        rows: number;
        protected indx: number;
        protected initScroll: number;
        protected intLoopCounter: number;
        protected stopSpinNow: boolean;
        protected stopIndex: number;
        protected blurSpin: boolean;
        spinNow: boolean;
        protected intMaxLoops: number;
        protected anticipationSpeed: number;
        protected initSpinSpeed: number;
        protected stops: Array<number | number[]>;
        protected model: Model;
        protected isSpinning: boolean;
        protected isSymAim: boolean;
        protected animatingIcons: Array<any>;
        protected AllIcons: Array<any>;
        protected hiddenIcons: Array<any>;
        protected scatterIcons: Array<any>;
        protected iconsPool: slot.symbol.SymbolFactory;
        protected spinDirection: number;
        protected quickSpinSpeed: number;
        anticipationAvailable: boolean;
        protected symCollection: SymbolBase[];
        protected desiredFPSTime: number;
        constructor(reelId: number, rows: number, model: Model, pool?: slot.symbol.SymbolFactory);
        reelMaskOn(): void;
        reelMaskOff(): void;
        protected reelSubset(stopPos: number): Array<number>;
        getSymbol(id: number): SymbolBase;
        getSymbolStatic(id: number): StaticSymbol | AnimationSymbol;
        getSymbolBlur(id: number): StaticSymbol;
        getSymbolAnimation(id: number): StaticSymbol | AnimationSymbol | SpineSymbol | LayeredAnimIcon;
        getIconBySymType(type: string): SymbolBase[][];
        protected setStaticReel(reelGrid: Array<number>): void;
        forceHideSyms(num: number): void;
        protected onSymbolAnimationEvent(evt?: any): void;
        protected getStopIndex(symbolId: number): number;
        init(stopPos: number | number[]): void;
        protected readonly index: number;
        protected readonly upindex: number;
        spin(isBlur: boolean): void;
        protected _startLoop(): void;
        sortIconsOnType(): void;
        updateSpin(deltaTime: number): void;
        protected handleReelStop(): void;
        protected spinDone(): void;
        setStops(stopsArray: number | number[] | IObject): void;
        forceStopReel(stopsArray: number | number[]): void;
        playAnimByPos(pos: number, symReel?: ui.Container, opts?: SymAnimReel): void;
        playAnimByID(id: number, pos: number, symReel?: ui.Container, opts?: any): SymbolBase;
        playTriggerAnimByID(id: number, pos: number, symReel?: ui.Container, opts?: any): SymbolBase;
        stopAnimByPos(pos: number): void;
        stopAllAnim(): void;
        getStaticByPos(pos: number): StaticSymbol | AnimationSymbol;
        getAnimationByPos(pos: number): AnimationSymbol | SpineSymbol | StaticSymbol | LayeredAnimIcon;
        getSymbolByPos(pos: number): SymbolBase;
        getNumSymbols(): number;
        getSymbolsOnReel(): SymbolBase[];
        getTotalNumSymbols(): number;
        getStops(): (number | number[])[];
        getIsSpining(): boolean;
        readonly isSpinNow: boolean;
        setMaxLoops(value: number): void;
        setAnticipationSpeed(value: number): void;
        toString(): string;
    }
}
declare namespace ingenuity.slot.reelPanel {
    import SymbolBase2 = symbol.SymbolBase2;
    import StaticSymbol = symbol.StaticSymbol;
    import AnimationSymbol = symbol.AnimationSymbol;
    import LayeredAnimIcon = symbol.LayeredAnimationSymbol;
    import SpineSymbol = symbol.SpineSymbol;
    class Reel2 extends ui.Container {
        protected reelSet: Array<number>;
        reelId: number;
        rows: number;
        protected indx: number;
        protected initScroll: number;
        protected intLoopCounter: number;
        protected stopSpinNow: boolean;
        protected stopIndex: number;
        protected blurSpin: boolean;
        spinNow: boolean;
        protected intMaxLoops: number;
        protected anticipationSpeed: number;
        protected initSpinSpeed: number;
        protected stops: Array<number | number[]>;
        protected model: Model;
        protected isSpinning: boolean;
        protected isSymAim: boolean;
        protected animatingIcons: Array<any>;
        protected AllIcons: Array<any>;
        protected hiddenIcons: Array<any>;
        protected scatterIcons: Array<any>;
        protected iconsPool: slot.symbol.SymbolFactory2;
        protected spinDirection: number;
        protected quickSpinSpeed: number;
        anticipationAvailable: boolean;
        protected symCollection: SymbolBase2[];
        protected desiredFPSTime: number;
        protected removedSymbol: any;
        protected strip1: ui.Container;
        protected strip2: ui.Container;
        protected visibleReel: ui.Container;
        protected hiddenReel: ui.Container;
        protected speed: number;
        protected maxSpeed: number;
        protected acceleration: number;
        protected deceleration: number;
        protected minSpeed: number;
        protected jerkDistance: number;
        protected symCollection2: SymbolBase2[];
        protected stopUpdateReel: boolean;
        protected counter: number;
        static isStoppingReel: boolean;
        static isForcedStop: boolean;
        protected bounced: boolean;
        constructor(reelId: number, rows: number, model: Model, pool?: slot.symbol.SymbolFactory2);
        reelMaskOn(): void;
        reelMaskOff(): void;
        protected reelSubset(stopPos: number): Array<number>;
        getSymbol(id: number): SymbolBase2;
        getSymbolStatic(id: number): StaticSymbol | AnimationSymbol;
        getSymbolBlur(id: number): StaticSymbol;
        getSymbolAnimation(id: number): StaticSymbol | AnimationSymbol | SpineSymbol | LayeredAnimIcon;
        getIconBySymType(type: string): SymbolBase2[][];
        protected setStaticReel(reelGrid: Array<number>, reelObj?: ui.Container): void;
        protected setStaticReelTexture(reelGrid: Array<number>, reelObj?: ui.Container): void;
        forceHideSyms(num: number): void;
        protected onSymbolAnimationEvent(evt?: any): void;
        protected getStopIndex(symbolId: number): number;
        init(stopPos: number | number[]): void;
        protected readonly index: number;
        protected readonly upindex: number;
        spin(isBlur: boolean): void;
        protected _startLoop(): void;
        sortIconsOnType(): void;
        updateSpin(deltaTime: number): void;
        protected updateSpinTopDown(deltaTime: number): void;
        protected updateSpinBottomUp(deltaTime: number): void;
        protected updateStopReelTopDown(deltaTime: number): void;
        protected updateStopReelBottomUp(deltaTime: number): void;
        protected stopReelsFinally(): void;
        protected checkToStopTopDown(reelStripId: number): void;
        protected checkToStopBottomUp(reelStripId: number): void;
        private handleReelStop();
        protected spinDone(): void;
        setStops(stopsArray: number | number[] | IObject): void;
        forceStopReel(stopsArray: number | number[]): void;
        playAnimByPos(pos: number, symReel?: ui.Container, opts?: SymAnimReel): void;
        playAnimByID(id: number, pos: number, symReel?: ui.Container, opts?: any): symbol.SymbolBase;
        playTriggerAnimByID(id: number, pos: number, symReel?: ui.Container, opts?: any): SymbolBase2;
        stopAnimByPos(pos: number): void;
        stopAllAnim(): void;
        getStaticByPos(pos: number): StaticSymbol | AnimationSymbol;
        getAnimationByPos(pos: number): AnimationSymbol | SpineSymbol | StaticSymbol | LayeredAnimIcon;
        getSymbolByPos(pos: number): SymbolBase2;
        getNumSymbols(): number;
        getSymbolsOnReel(): SymbolBase2[];
        getTotalNumSymbols(): number;
        getStops(): (number | number[])[];
        getIsSpining(): boolean;
        readonly isSpinNow: boolean;
        symbolCollectionArray(): SymbolBase2[];
        setMaxLoops(value: number): void;
        setAnticipationSpeed(value: number): void;
        toString(): string;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class SymAnimReel extends ui.Container {
        protected reelId: number;
        protected rows: number;
        model: Model;
        protected isSymAim: boolean;
        constructor(game: Phaser.Game, reelId: number, rows: number, model: Model);
        sortIconsOnType(): void;
        addChild(child: PIXI.DisplayObject): ui.Container;
        stopSymbolAnimation(): void;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class WinPresentationPanel extends ui.Container {
        protected animMode: number;
        protected isStopSymAnim: boolean;
        protected toggleingContinue: boolean;
        protected animateSymbol: boolean;
        SHORT_ANIM_MODE: number;
        LONG_ANIM_MODE: number;
        FREE_SPIN_ANIM_MODE: number;
        WIN_LINE_ANIM_TIMEOUT: number;
        WIN_LINE_ANIM_START_AFTER: number;
        ALL_WIN_ANIM_TIMEOUT: number;
        WIN_SCATTER_ANIM_TIMEOUT: number;
        WAY_ANIM_COUNT: number;
        BLINK_ANIM_CYCLES: number;
        LINE_ANIM_CYCLES: number;
        FS_LINE_ANIM_CYCLES: number;
        protected animModeArray: string[];
        protected numCycleCount: number;
        protected reelPanel: ReelPanel;
        protected model: Model;
        constructor(game: Phaser.Game, reelPanel: ReelPanel);
        protected reelLayering(game: Phaser.Game, reelPanel: ReelPanel): void;
        subscribeEvents(): void;
        unsubscribeEvents(): void;
        protected playSymbolAnimation(reel: number, row: number, animationOnCurrentWinLine?: boolean): void;
        protected playSymbolAnimationByID(symbolID: number, reel: number, row: number, opts?: any): ui.Container | symbol.SymbolBase;
        protected playSymbolTriggerAnimationByID(symbolID: number, reel: number, row: number, opts?: any): ui.Container | symbol.SymbolBase;
        protected playScatterWinAnimations(evt: any): void;
        startWinLineAnimation(evt: any): void;
        protected playLineWinAnimations(numCycles: number): void;
        protected animateWinLineSymbol(winLineData: IWinLineObject): void;
        protected animateNextWinLine(): void;
        protected winCycleCompleted(): void;
        protected showWinLine(winLineData: any, currentWinLine: any): void;
        protected animateAllWin(winLineData: any): void;
        startWayWinAnimation(evt: any): void;
        protected playWaysWinAnimations(numCycles: number): void;
        protected animateWayWin(winWayData: IWinLineObject, uniquePosition?: Array<any>): void;
        protected animateNextWayWin(): void;
        protected showWayWin(wayWinData: any, currentWinLine: any): void;
        protected stopAllWinAnimations(): void;
        protected clearSymReels(): void;
        setAnimMode(value: number): void;
        getAnimMode(): number;
        getAnimModeLongName(): string;
        setStopSymAnimOnWinCycle(value: boolean): void;
        getModel(): Model;
        setAnimateSymbol(value: boolean): void;
        getAnimateSymbol(): boolean;
        setToggleingContinue(value: boolean): void;
        getToggleingContinue(): boolean;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class SymAnimOverlayReel extends ui.Container {
        protected reelId: number;
        protected rows: number;
        model: Model;
        protected isSymAim: boolean;
        constructor(game: Phaser.Game, reelId: number, rows: number, model: Model, contName: string);
        sortIconsOnType(): void;
        addChild(child: PIXI.DisplayObject): ui.Container;
        stopSymbolAnimation(): void;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class WinPresentationOverlayPanel extends ui.Container {
        protected toggleingContinue: boolean;
        protected animateSymbol: boolean;
        protected reelPanel: ReelPanel;
        protected model: Model;
        protected symOverlayReels: Array<SymAnimOverlayReel>;
        constructor(game: Phaser.Game, reelPanel: ReelPanel, contName: string);
        protected reelLayering(game: Phaser.Game, reelPanel: ReelPanel): void;
        getModel(): Model;
        setAnimateSymbol(value: boolean): void;
        getAnimateSymbol(): boolean;
        setToggleingContinue(value: boolean): void;
        getToggleingContinue(): boolean;
        getAnimReels(): Array<SymAnimOverlayReel>;
        removeChildren(beginIndex?: number, endIndex?: number): PIXI.DisplayObject[];
        stopSymbolAnimation(): void;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class ReelPanel extends ui.Container {
        protected model: Model;
        json: IReelPanel;
        protected reels: Array<Reel>;
        protected symAnimReels: Array<SymAnimReel>;
        protected symAnimOverlayContainers: Array<WinPresentationOverlayPanel>;
        protected stopIds: Array<number>;
        protected stopSpinAll: boolean;
        protected reelsStopped: boolean[];
        protected paused: boolean;
        isSpining: boolean;
        protected animMode: number;
        protected initiated: boolean;
        protected stopNow: boolean;
        protected anticipationDelayAmt: number;
        constructor(game: Phaser.Game, model: Model);
        protected reelLayering(): void;
        showStaticGrid(grid: any): void;
        init(stopPos: any): void;
        private updateReelConfig(evt);
        showAllSymbols(): void;
        protected forceHideReelSymbols(evt: IEvent): void;
        protected reelpanelMaskOn(): void;
        reelpanelMaskOff(): void;
        protected onSymAnimEventFired(evt: any): void;
        protected onReelStopping(evt: any): void;
        protected reelStopped(evt: any): void;
        setAnticipation(id: number): void;
        protected spinAll: boolean;
        spin(isBlur?: any): void;
        protected spinReel(id: number, isBlur: boolean): void;
        update(): void;
        setReelStopGrid(value: any): void;
        setWinningLines(value: any): void;
        stop(stops: any): void;
        protected stopReel(id: number, allReelSpining: boolean): void;
        stopReelsNow(stops: any): void;
        setStopNow(value: boolean): void;
        forceStopReels(stops: any): void;
        setPause(value: boolean): void;
        getIsSpining(): boolean;
        getPause(): boolean;
        getModel(): Model;
        getReels(): Array<Reel>;
        getAnimReels(): Array<SymAnimReel>;
        getAnimationContainers(): Array<WinPresentationOverlayPanel>;
        getAnimationContainerByName(name: string): WinPresentationOverlayPanel;
        getSymbolByPos(reel: number, pos: number): symbol.SymbolBase;
        stopSymbolAnim(reel: number, row: number): void;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class ReelPanel2 extends ui.Container {
        protected model: Model;
        json: IReelPanel;
        protected reels: Array<Reel2>;
        protected symAnimReels: Array<SymAnimReel>;
        protected symAnimOverlayContainers: Array<WinPresentationOverlayPanel>;
        protected stopIds: Array<number>;
        protected stopSpinAll: boolean;
        protected reelsStopped: boolean[];
        protected paused: boolean;
        isSpining: boolean;
        protected animMode: number;
        protected initiated: boolean;
        protected stopNow: boolean;
        protected anticipationDelayAmt: number;
        protected resetElapsedMS: boolean;
        constructor(game: Phaser.Game, model: Model);
        protected reelLayering(): void;
        showStaticGrid(grid: any): void;
        init(stopPos: any): void;
        private updateReelConfig(evt);
        showAllSymbols(): void;
        protected forceHideReelSymbols(evt: IEvent): void;
        protected reelpanelMaskOn(): void;
        reelpanelMaskOff(): void;
        protected onSymAnimEventFired(evt: any): void;
        protected onReelStopping(evt: any): void;
        protected reelStopped(evt: any): void;
        setAnticipation(id: number): void;
        protected spinAll: boolean;
        spin(isBlur?: any): void;
        protected spinReel(id: number, isBlur: boolean): void;
        update(): void;
        setReelStopGrid(value: any): void;
        setWinningLines(value: any): void;
        stop(stops: any): void;
        protected stopReel(id: number, allReelSpining: boolean): void;
        stopReelsNow(stops: any): void;
        setStopNow(value: boolean): void;
        forceStopReels(stops: any): void;
        setPause(value: boolean): void;
        getIsSpining(): boolean;
        getPause(): boolean;
        getModel(): Model;
        getReels(): Array<Reel2>;
        getAnimReels(): Array<SymAnimReel>;
        getAnimationContainers(): Array<WinPresentationOverlayPanel>;
        getAnimationContainerByName(name: string): WinPresentationOverlayPanel;
        getSymbolByPos(reel: number, pos: number): symbol.SymbolBase2;
        stopSymbolAnim(reel: number, row: number): void;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class Paylines extends ui.Container {
        protected spaghettiContainer: ui.Container;
        protected winboxContainer: ui.Container;
        protected paylineContainer: ui.Container;
        protected paylineMaskBMP: ui.BitmapData;
        protected model: Model;
        protected startIndex: number;
        protected lines: Array<ui.Sprite>;
        protected winboxes: Array<ui.Container>;
        protected spaghettiLines: Array<ui.Sprite>;
        static winCycleComplete: number;
        protected isWinbox: boolean;
        protected isSpaghetti: boolean;
        protected isPayline: boolean;
        protected animType: string;
        protected secondToggleStart: boolean;
        private maskIsDirty;
        constructor(json: IContainer, model: Model, parent?: ui.Container);
        subscribeEvents(): void;
        unsubscribeEvents(): void;
        protected secodToggleEanble(): void;
        protected createWinBox(): void;
        protected createAnimatedWinBoxInstance(winBoxData: IContainer, i: number, pickFrameCount: number): void;
        protected createAnimatedWinBox(): void;
        protected drawWinBoxInstance(i: number, lineColor: string, shadowColor: string): void;
        protected drawWinBoxes(): void;
        protected drawLine(pyArr: Array<number>, i: number): ui.BitmapData;
        protected drawPaylines(): void;
        protected animatedPaylines(): void;
        protected createAnimatedPaylineInstance(paylineData: IObject, pickFrameCount: number, i: number): void;
        protected createPaylinesAndSpaggitte(): void;
        protected hidePayline(evt: number | IEvent): void;
        protected showPayline(evt: number | IEvent): void;
        protected hideAllPaylines(): void;
        protected resetLineMask(): void;
        protected getWinbox(id: number): ui.Container;
        protected stopWinBoxAnimation(winBox: ui.Sprite): void;
        protected hidePaylineWinbox(evt: number | IEvent): void;
        protected hideAllPaylineWinboxes(): void;
        protected hideAllSpagetti(): void;
        protected drawLineMask(boxElement: ui.Sprite): void;
        protected showPaylineWinbox(id: number, numSymWin: number | Array<Array<number>>): void;
        protected showScatterFrames(evt: IEvent): void;
        protected showWinBoxOnly(line: number, numSymWin: number[][]): void;
        protected showWinPayline(evt: IEvent, numSymWin?: IObject | number): void;
        protected showAllPaylineWins(evt: IEvent): void;
        protected showSpagetti(evt: IEvent): void;
        protected flashSpagetti(evt: IEvent): void;
        protected showAllFrames(evt: IEvent): void;
        protected hideAllFrames(evt: IEvent): void;
        protected hideWinPayline(evt: IEvent): void;
        readonly isSpagettiVisible: boolean;
        protected hideAllWinPaylines(): void;
        getSpagettiContainer(): ui.Container;
        getPaylineContainer(): ui.Container;
        getWinboxContainer(): ui.Container;
        setSpagettiContainer(value: ui.Container): void;
        setPaylineContainer(value: ui.Container): void;
        setWinboxContainer(value: ui.Container): void;
    }
}
declare namespace ingenuity.core.constructors {
    let reelPanel: {
        SymbolBase: typeof ingenuity.slot.symbol.SymbolBase;
        SymbolBase2: typeof ingenuity.slot.symbol.SymbolBase2;
        StaticSymbol: typeof ingenuity.slot.symbol.StaticSymbol;
        AnimationSymbol: typeof ingenuity.slot.symbol.AnimationSymbol;
        SpineSymbol: typeof ingenuity.slot.symbol.SpineSymbol;
        LayeredAnimationSymbol: typeof ingenuity.slot.symbol.LayeredAnimationSymbol;
        SymbolFactory: typeof ingenuity.slot.symbol.SymbolFactory;
        SymbolFactory2: typeof ingenuity.slot.symbol.SymbolFactory2;
        ReelModel: typeof ingenuity.slot.reelPanel.Model;
        Reel: typeof ingenuity.slot.reelPanel.Reel;
        Reel2: typeof ingenuity.slot.reelPanel.Reel2;
        SymAnimReel: typeof ingenuity.slot.reelPanel.SymAnimReel;
        SymAnimOverlayReel: typeof ingenuity.slot.reelPanel.SymAnimOverlayReel;
        WinReelPanel: typeof ingenuity.slot.reelPanel.WinPresentationPanel;
        WinReelOverlayPanel: typeof ingenuity.slot.reelPanel.WinPresentationOverlayPanel;
        ReelPanel: typeof ingenuity.slot.reelPanel.ReelPanel;
        ReelPanel2: typeof ingenuity.slot.reelPanel.ReelPanel2;
        PaylineView: typeof ingenuity.slot.reelPanel.Paylines;
    };
}
declare namespace ingenuity.slot.IntroOutro {
    class View extends ui.BaseView {
        constructor(viewJson: IContainer);
    }
}
declare namespace ingenuity.slot.IntroOutro {
    class Model {
    }
}
declare namespace ingenuity.slot.IntroOutro {
    class Controller {
        protected view: slot.IntroOutro.View;
        protected IntroContainer: ui.Container;
        protected IntroOutroContainer: ui.Container;
        protected OutroContainer: ui.Container;
        protected IntroContinueBtn: ui.ButtonBase;
        protected OutroContinueBtn: ui.ButtonBase;
        constructor(view: View);
        protected onInitializeIntroOutro(): void;
        protected subscribeEvents(): void;
        protected bindHandlers(): void;
        protected unSubscribeEvents(): void;
        protected unBindHandlers(): void;
        protected onIntroShow(): void;
        protected onIntroHide(): void;
        protected onOutroShow(): void;
        protected onOutroHide(): void;
        protected onIntroContinuePressUp(): void;
        protected onOutroContinuePressUp(): void;
    }
}
declare namespace ingenuity.slot.FreeGame {
    class Model extends BaseGame.Model {
        protected animationSequence: string[];
        freeGameInitiated: boolean;
        protected reTriggerSpins: number;
        constructor(serverModel: platform.baseslot.Model);
        getIsBigWin(): number;
        getFreeSpinsRemaining(): number;
        getIsWin(): boolean;
        getIsScatterWins(): boolean;
        getIsWonFreeSpin(): boolean;
        getUserBalance(): number;
        getHasEnoughBalance(): boolean;
        setUpdatedBalanceForSpin(): void;
        getIsAutoPlayLeft(): boolean;
        getReTriggerSpins(): number;
        setRetriggerSpins(retriggerSpinCount: number): void;
    }
}
declare namespace ingenuity.slot.FreeGame {
    class View extends BaseGame.View {
        constructor(viewJson: IContainer);
    }
}
declare namespace ingenuity.slot.FreeGame {
    class ButtonController {
        protected skipBtn: ingenuity.ui.ButtonBase;
        protected spinStopBtn: ingenuity.ui.ButtonBase;
        protected view: View;
        protected reelView: slot.reelPanel.ReelPanel;
        protected model: FreeGame.Model;
        constructor(view: FreeGame.View, model: FreeGame.Model);
        protected initializeButtons(view: FreeGame.View): void;
        protected bindHandlers(): void;
        protected unBindHandlers(): void;
        protected onSkipPressUp(btn?: ui.ButtonBase): void;
        protected onSpinStopPressUp(): void;
        protected onShowSkipBtnHideStopBtn(evt: IEvent): void;
        protected onShowSkipDisabledBtnHideStopBtn(evt: IEvent): void;
        protected subscribeEvents(): void;
        protected unsubscribeEvents(): void;
        protected nullSpinButton(evt: IEvent): void;
        protected onEnableStopBtn(evt: IEvent): void;
        protected onClearData(evt: IEvent): void;
        protected onHideContainers(evt: IEvent): void;
        protected showContainers(evt: IEvent): void;
        protected onDisabledAllButtons(evt: IEvent): void;
        protected onEnableAllButtons(evt: IEvent): void;
        protected enableMenuBtn(): void;
        protected onEnabledButton(evt: IEvent): void;
        protected onDisabledButton(evt: IEvent): void;
        protected onShowContainers(evt: IEvent): void;
        protected onRemoveAllListnersFromStage(evt: IEvent): void;
        protected onDisableButtonInteraction(evt: IEvent): void;
        protected onEnableButtonInteraction(evt: IEvent): void;
    }
}
declare namespace ingenuity.slot.FreeGame {
    class MetersController {
        protected balanceMeter: ui.Meter;
        protected winMeter: ui.Meter;
        protected totalWinMeter: ui.Meter;
        protected freegameLeftMeter: ui.Meter;
        protected view: View;
        protected model: Model;
        constructor(view: View, model: Model);
        protected bindHandlers(): void;
        protected subscribeEvents(): void;
        protected unsubscribeEvents(): void;
        protected onStartWinTickUp(evt: IEvent): void;
        protected tickUpComplete(): void;
        protected updateBalance(): void;
        protected onUpdateBalanceMeterAfter(evt: IEvent): void;
        protected onUpdateBalanceMeterAfterSpinClick(evt: IEvent): void;
        protected updateMeterForCreditCoin(meter: ui.Meter, value: string): void;
        protected onUpdateBalanceMeter(evt: IEvent): void;
        protected onUpdateFreegameLeftMeter(evt: IEvent): void;
        protected onSetFreeGameLeftMeter(evt: IEvent): void;
        protected onUpdateTotalWinMeter(evt: IEvent): void;
        protected onResetMeters(evt: IEvent): void;
        protected onUpdatePaidMeter(evt: IEvent): void;
        protected onStopMeterTickup(evt: IEvent): void;
    }
}
declare namespace ingenuity.slot.FreeGame {
    abstract class PlayerMsgController extends BaseGame.PlayerMsgController {
    }
}
declare namespace ingenuity.slot.FreeGame {
    class ReelPanelController {
        protected view: View;
        protected model: Model;
        protected reelView: reelPanel.ReelPanel;
        protected winReelView: reelPanel.WinPresentationPanel;
        protected paylineView: reelPanel.Paylines;
        protected anticipationList: Array<Array<number>>;
        constructor(view: View, model: Model);
        protected init(): void;
        protected bindHandlers(): void;
        protected subscribeEvents(): void;
        protected unsubscribeEvents(): void;
        protected onUnScribeAllReelPanelEvents(evt: IEvent): void;
        protected onReelsForceStop(): void;
        protected onStopReelNow(evt: IEvent): void;
        protected onSpinReel(evt: IEvent): void;
        protected onUpdateSymbolsOnGrid(): void;
        protected onCheckingAnticipationOnReels(evt: IEvent): void;
        protected updateModelForQuickSpin(evt: IEvent): void;
        protected showAnticipation(e?: IEvent): void;
        protected showLanding(e?: IEvent): void;
        protected onReelStartSubscribeEvents(evt: IEvent): void;
        protected onReelStopped(evt: IEvent): void;
        protected onSpinComplete(evt: ingenuity.events.EventDispatcher): void;
        protected onReelStopping(evt: IEvent): void;
        protected checkForAnticipation(symbolObj: any, listLength: number): void;
        protected checkForlandingAnim(symbolObj: any, listLength: number): void;
        protected onClearData(evt: IEvent): void;
    }
}
declare namespace ingenuity.slot.FreeGame {
    class WinPresentationController {
        protected paylineView: slot.reelPanel.Paylines;
        protected reelView: slot.reelPanel.WinPresentationPanel;
        protected view: View;
        protected model: Model;
        protected fiveOfKindDuration: number;
        protected togglingCycle: number;
        constructor(view: View, model: Model);
        protected onStartBigWinPresentation(evt: IEvent): void;
        protected subscribeEvents(): void;
        protected onClearData(): void;
        protected onSuspendWinPresentation(): void;
        protected unsubscribeEvents(): void;
        protected onWinCycleCompleted(evt: IEvent): void;
        protected onStartFirstToggleCycle(evt: IEvent): void;
        protected onStartFirstToggleCycleWays(evt: IEvent): void;
        protected onStartSecondToggleCycle(evt: IEvent): void;
        protected onStartSecondToggleCycleWays(evt: IEvent): void;
        protected cofigureEventOnBigWinHide(): void;
        protected onShowSpaghtti(evt: IEvent): void;
        protected onShowAllFrames(evt: IEvent): void;
        protected onShow5OAK(evt: IEvent): void;
        protected onHide5OAK(evt: IEvent): void;
        protected onSetWinLineAndWaysUniqueData(evt: IEvent): void;
        protected onReelStartSubscribeEvents(evt: IEvent): void;
        protected onStopAllWinAnimation(): void;
    }
}
declare namespace ingenuity.slot.FreeGame {
    class FreeGameController {
        protected view: View;
        protected model: FreeGame.Model;
        protected json: IObject;
        protected assets: any;
        protected buttonController: ButtonController;
        protected meterController: MetersController;
        protected playerMsgController: any;
        protected reelPanelController: ReelPanelController;
        protected winPresentationController: WinPresentationController;
        constructor(view: FreeGame.View, model: Model, json: IObject, assetManager: any);
        protected subscribeEvents(): void;
        protected onHideFreeGame(evt: IEvent): void;
        protected onShowFreeGame(evt: IEvent): void;
        protected onInitializeSlotLogic(evt: IEvent): void;
        protected onInitializeAllControllers(evt: IEvent): void;
        protected initializeButtonController(): void;
        protected initializeMeterController(): void;
        protected initializePlayerMsgController(): void;
        protected initializeReelPanelController(): void;
        protected initializeWinPresentationController(): void;
    }
}
declare namespace ingenuity.slot.Logic {
    class SlotGameLogic {
        protected model: any;
        protected logicRunningFor: string;
        constructor();
        protected initializeBaseGameModel(): void;
        protected initializeFreeGameModel(): void;
        protected subscribeEvents(): void;
        protected unsubscribeEvents(): void;
        protected onCheckForWinAfterReelStop(evt: IEvent): void;
        protected setWinlineAndWaysData(): void;
        protected checkForAutoPlay(): void;
        protected autoplayReset(): void;
        protected checkForAutoPlayCondition(): void;
        protected onShowNextWinPresentation(evt: IEvent): void;
        protected updateAnimationSequenceCounter(): void;
        protected startWinMeterTickUP(): void;
        protected onShow5OAK(): void;
        protected showFiveOfAkind(): void;
        protected showNextWinPresentation(): void;
        protected onShowSpaghtti(): void;
        protected onShowAllFrames(): void;
        protected onShowBigWin(): void;
        protected startTheBigWinPresentation(): void;
        protected onFirstToggle(): void;
        protected onFirstToggleWays(): void;
        protected onSecondToggle(): void;
        protected onSecondToggleWays(): void;
        protected startSecondToggleOnState(breakToggleing: boolean): void;
        protected startSecondToggleOnStateWays(breakToggleing: boolean): void;
        protected IntroHideComplete(): void;
        protected OutroHideComplete(): void;
        protected doNextSpin(evt: IEvent): void;
        protected unSubscribeReelPanelControllerEvents(): void;
        protected onTriggeringAnimation(): void;
        protected startScatterPresentation(): void;
        protected onBonusPresentation(): void;
        protected onFreeSpinPresentation(): void;
        protected onCheckForAutoPlay(): void;
        protected onValidateBetInFreeGame(evt: IEvent): void;
        protected onValidateBet(evt: IEvent): void;
        protected onSpinClickedInFreeGame(evt: IEvent): void;
        protected onSpinClicked(evt: IEvent): void;
        protected onSkipClicked(evt: IEvent): void;
        protected onReelStartSubscribeEvents(): void;
        protected onSpinResponseReceived(evt: IEvent): void;
        protected onAllReelSpinning(evt: IEvent): void;
        protected OnreelSpiningAndServerResponseReceived(): void;
        protected onClearSpinTimer(evt: ingenuity.events.EventDispatcher): void;
        protected onStakeChange(): void;
        protected onInfoPressed(): void;
        protected hideGameMessage(): void;
        protected showGameMessage(): void;
        protected onUnScribeAllReelPanelEvents(): void;
    }
}
declare namespace ingenuity.slot {
    abstract class BasegameState extends states.State {
        protected view: BaseGame.View;
        protected model: BaseGame.Model;
        protected reelModel: reelPanel.Model;
        protected reelPanel: reelPanel.ReelPanel;
        protected winReelpanel: reelPanel.WinPresentationPanel;
        protected winReelOverlaypanel: Array<any>;
        protected paylineView: reelPanel.Paylines;
        protected basecontroller: BaseGame.BaseController;
        init(): void;
        shutdown(): void;
        protected initializeModel(): void;
        protected initializeView(): void;
        protected initializeController(): void;
        protected initializeReelPanel(): void;
        protected initializeWinReelPresentation(): void;
        protected initializeOverlayWinReelPresentation(): void;
        protected subscribeEvents(): void;
        protected unsubscribeEvents(): void;
        protected initializePayline(): void;
        protected setReelPanelLayering(): void;
        protected initializeBigWinPresentation(): void;
        protected initializePaytable(): void;
        protected initializeIntroOutro(): void;
        protected initializeSound(): void;
    }
}
declare namespace ingenuity.slot {
    abstract class FreegameState extends states.State {
        protected view: FreeGame.View;
        protected model: FreeGame.Model;
        protected reelModel: reelPanel.Model;
        protected reelPanel: reelPanel.ReelPanel;
        protected winReelpanel: reelPanel.WinPresentationPanel;
        protected winReelOverlaypanel: Array<any>;
        protected paylineView: reelPanel.Paylines;
        protected freeGameController: FreeGame.FreeGameController;
        init(): void;
        shutdown(): void;
        protected initializeModel(): void;
        protected initializeView(): void;
        protected initializeController(): void;
        protected initializeReelPanel(): void;
        protected initializeWinReelPresentation(): void;
        protected initializeOverlayWinReelPresentation(): void;
        protected subscribeEvents(): void;
        protected unsubscribeEvents(): void;
        protected initializePayline(): void;
        protected setReelPanelLayering(): void;
        protected initializeBigWinPresentation(): void;
        protected initializePaytable(): void;
        protected initializeIntroOutro(): void;
        protected initializeSound(): void;
    }
}
declare namespace ingenuity.core.constructors {
    let slot: {
        IntroView: typeof ingenuity.slot.IntroOutro.View;
        IntroModel: typeof ingenuity.slot.IntroOutro.Model;
        IntroController: typeof ingenuity.slot.IntroOutro.Controller;
        BaseButtonController: typeof ingenuity.slot.BaseGame.ButtonController;
        BaseMetersController: typeof ingenuity.slot.BaseGame.MetersController;
        BasePlayerMsgController: typeof ingenuity.slot.BaseGame.PlayerMsgController;
        BaseReelPanelController: typeof ingenuity.slot.BaseGame.ReelPanelController;
        BaseWinPresentationController: typeof ingenuity.slot.BaseGame.WinPresentationController;
        BaseController: typeof ingenuity.slot.BaseGame.BaseController;
        BaseModel: typeof ingenuity.slot.BaseGame.Model;
        BaseView: typeof ingenuity.slot.BaseGame.View;
        FreeButtonController: typeof ingenuity.slot.FreeGame.ButtonController;
        FreeMetersController: typeof ingenuity.slot.FreeGame.MetersController;
        FreePlayerMsgController: typeof ingenuity.slot.FreeGame.PlayerMsgController;
        FreeReelPanelController: typeof ingenuity.slot.FreeGame.ReelPanelController;
        FreeWinPresentationController: typeof ingenuity.slot.FreeGame.WinPresentationController;
        FreeController: typeof ingenuity.slot.FreeGame.FreeGameController;
        FreeModel: typeof ingenuity.slot.FreeGame.Model;
        FreeView: typeof ingenuity.slot.FreeGame.View;
        SlotLogic: typeof ingenuity.slot.Logic.SlotGameLogic;
        SlotConstants: typeof ingenuity.slot.slotConstants.SlotConstants;
        SlotEventConstants: {
            SPIN_CLICKED: string;
            SKIP_CLICKED: string;
            SPIN_CLICKED_IN_FREE_GAME: string;
            UPDATE_AUTOPLAY_BUTTONS: string;
            UPDATE_AUTOPLAY_METERS: string;
            CLEAR_SPIN_TIMER: string;
            REMOVE_ALL_LISTNERS_FROM_STAGE: string;
            DISABLED_ALL_BUTTONS: string;
            ENABLED_ALL_BUTTONS: string;
            ENABLE_BUTTON: string;
            DISABLE_BUTTON: string;
            SUSPEND_WINPRESENTATION: string;
            DO_NEXT_SPIN: string;
            CLEAR_DATA: string;
            SUBSCRIBE_BASEGAME_REELPANEL_EVENTS: string;
            UNSUBSCRIBE_BASEGAME_REELPANEL_EVENTS: string;
            SUBSCRIBE_FREEGAME_REELPANEL_EVENTS: string;
            UNSUBSCRIBE_FREEGAME_REELPANEL_EVENTS: string;
            SUBSCRIBE_BASEGAME_WIN_PRESENTATION_EVENTS: string;
            UNSUBSCRIBE_BASEGAME_WIN_PRESENTATION_EVENTS: string;
            SUBSCRIBE_FREEGAME_WIN_PRESENTATION_EVENTS: string;
            UNSUBSCRIBE_FREEGAME_WIN_PRESENTATION_EVENTS: string;
            VALIDATE_BET: string;
            VALIDATE_BET_IN_FREEGAME: string;
            RESET_METERS: string;
            UPDATE_BET_METER: string;
            UPDATE_PAID_METER: string;
            UPDATE_TOTAL_WIN_METER: string;
            UPDATE_FREEGAME_LEFT_METER: string;
            ON_SET_FREEGAME_LEFT: string;
            UPDATE_TOTAL_BET_METER: string;
            UPDATE_BALANCE_METER_AFTER: string;
            UPDATE_BALANCE_METER_AFTER_SPIN_CLICK: string;
            STOP_METER_TICKUP: string;
            UPDATE_BALANCE_METER_BEFORE: string;
            UPDATE_BALANCE_METER: string;
            UPDATE_STAKE_METER: string;
            SUBSCRIBE_EVENTS_ON_REEL_START: string;
            SUBSCRIBE_EVENTS_ON_REEL_START_BG: string;
            SUBSCRIBE_EVENTS_ON_REEL_START_FG: string;
            STOP_REEL_NOW: string;
            CHECK_FOR_ANTICIPATION_ON_REELS: string;
            UPDATE_SYMBOLS_ON_GRID: string;
            NULL_SPIN_BTN: string;
            UPDATE_REELVIEW_MODEL_FOR_QUICKSPIN: string;
            ENABLE_STOP_BTN: string;
            HIDE_CONTAINERS: string;
            NOW_SPIN_REEL: string;
            SHOW_CONTAINERS: string;
            ENABLE_BUTTON_INTERACTION: string;
            DISABLED_BUTTON_INTERACTION: string;
            SHOW_SPIN_BTN_HIDE_STOP_BTN: string;
            SHOW_SKIP_BTN_DISABLED_HIDE_STOP_BTN: string;
            CHECK_FOR_WIN_AFTER_REEL_STOP: string;
            CHECK_FOR_AUTOPLAY_CONDITION: string;
            DISABLED_AUTOPLAY_BTN: string;
            AUTOPLAY_RESET: string;
            AUTOPLAY_RESET_ENABLE_BUTTONS: string;
            AUTOPLAY_COUNT: string;
            ENABLE_AUTOPLAY_STOP_BTN: string;
            RESET_PALYER_MSG_LABELS: string;
            SHOW_NEXT_WIN_PRESENTATION: string;
            SHOW_5OAK: string;
            HIDE_5OAK: string;
            SET_WINLINE_AND_WAYS_DATA: string;
            SHOW_SPAGHTTI: string;
            SHOW_ALL_WIN_FRAMES: string;
            START_WIN_TICK_UP: string;
            STOP_WIN_TICK_UP: string;
            ON_RETURNING_FG_UPDATE_METER: string;
            FORCE_STOP: string;
            START_SCATTER_PRESENTATION: string;
            START_BIG_WIN_PRESENTATION: string;
            START_FIRST_TOGGLE_CYCLE: string;
            START_SECOND_TOGGLE_CYCLE: string;
            START_FIRST_TOGGLE_CYCLE_WAYS: string;
            START_SECOND_TOGGLE_CYCLE_WAYS: string;
            UNSCBSCRIBE_ALL_EVENTS_ON_REEL_PANEL_CONTROLLER: string;
            STOP_ALL_WIN_ANIMATION_ON_REEL: string;
            SCBSCRIBE_BUTTON_CONTROLLERS_BG: string;
            UNSCBSCRIBE_BUTTON_CONTROLLERS_BG: string;
            SCBSCRIBE_BUTTON_CONTROLLERS_FG: string;
            UNSCBSCRIBE_BUTTON_CONTROLLERS_FG: string;
            SCBSCRIBE_METER_CONTROLLERS_BG: string;
            UNSCBSCRIBE_METER_CONTROLLERS_BG: string;
            SCBSCRIBE_METER_CONTROLLERS_FG: string;
            UNSCBSCRIBE_METER_CONTROLLERS_FG: string;
            ALL_REEL_SPINING: string;
            INITIALIZE_ALL_CONTROLLERS_BG: string;
            INITIALIZE_ALL_CONTROLLERS_FG: string;
            INITIALIZE_SLOT_LOGIC: string;
            WRAPPER_READY: string;
            INITIALIZE_BASE_CLASSES: string;
            INITIALIZE_BASE_CLASSES_COMPLETE: string;
            GAME_RESIZE: string;
            INTRO_HIDE_COMPLETE: string;
            OUTRO_HIDE_COMPLETE: string;
            INTRO_SHOW: string;
            INTRO_HIDE: string;
            OUTRO_SHOW: string;
            OUTRO_HIDE: string;
            INITIALIZE_BG_MODEL: string;
            INITIALIZE_FG_MODEL: string;
            SETUP_FG: string;
            ON_FREEGAME_RETURNING: string;
            SUBSCRIBE_WINPRESENTATION_PANEL_BG: string;
            UNSUBSCRIBE_WINPRESENTATION_PANEL_BG: string;
            SUBSCRIBE_WINPRESENTATION_PANEL_FG: string;
            UNSUBSCRIBE_WINPRESENTATION_PANEL_FG: string;
            HIDE_BASEGAME_VIEW: string;
            SHOW_BASEGAME_VIEW: string;
            HIDE_FREEGAME_VIEW: string;
            SHOW_FREEGAME_VIEW: string;
            SHOW_WIN_PAYLINE: string;
            SHOW_SCATTER_FRAMES: string;
            HIDE_WIN_PAYLINE: string;
            SHOW_ALL_WIN_PAYLINE: string;
            HIDE_ALL_WIN_PAYLINE: string;
            HIDE_ALL_PAYLINE: string;
            HIDE_ALL_SPAGETTI: string;
            FLASH_SPAGETTI: string;
            SHOW_SPAGETTI: string;
            SHOW_ALL_FRAMES: string;
            HIDE_ALL_FRAMES: string;
            SHOW_PAYLINE: string;
            HIDE_PAYLINE: string;
            HIDE_PAYLINE_WINBOX: string;
            HIDE_ALL_PAYLINE_WINBOX: string;
            PLAY_LANDING_ANIMATION_SOUND: string;
            CREATE_WINBOX: string;
            CREATE_PAYLINE_SPAGGITTE: string;
            SUMUP_BIGWIN: string;
            CLEAR_STICKY_WILD_DATA: string;
            PLAY_STICKY_WILD_SYMBOL_ANIM: string;
            START_RETRIGGER_IN_FREEGAME: string;
            SHOW_FREEGAME_RETRIGGER_POPUP: string;
            CLEAR_RANDOM_WILD_DATA: string;
            START_RANDOM_WILD: string;
            RANDOM_WILD_APPEARED: string;
            UNSUBSCRIBE_RANDOM_WILD_EVENTS: string;
            STOP_WILD_ON_EXPWILD: string;
            STOP_SCATTER_ON_EXPWILD: string;
            INIT_EXPANDING_WILD: string;
            ON_ALL_REELS_STOPPED: string;
            CLEAR_EXP_WILD: string;
            SPIN_EXP_WILD_WITH_REEL: string;
            HIDE_EXP_WILD: string;
            HIDE_STICKY_CONTAINER: string;
            PLAY_STICKY_WILD_LANDING_ANIM: string;
            UNSUBSCRIBE_STICKY_EVENTS: string;
            PLAY_STICKY_SYMBOLS_ANIMATIONS: string;
            ADD_ANIM_OVERLAY_LAYER: string;
            ADD_ALL_OVERLAY_SYMBOLS_TO_ANIM_OVERLAY_LAYER: string;
            ADD_SYMBOL_TO_ANIM_OVERLAY_LAYER: string;
            CLEAR_ANIM_LAYER: string;
            PLACE_OVER_PAYLINES: string;
            SHOW_STICKY_VIEW: string;
            STICKY_ANIM_STARTED: string;
            REMOVE_STICKY_ICONS: string;
            FG_DISABLED_ALL_BUTTONS: string;
            FG_ENABLED_ALL_BUTTONS: string;
            FG_ENABLE_BUTTON: string;
            FG_DISABLE_BUTTON: string;
            FG_SUSPEND_WINPRESENTATION: string;
            FG_CLEAR_DATA: string;
            FG_RESET_METERS: string;
            FG_UPDATE_PAID_METER: string;
            FG_UPDATE_TOTAL_WIN_METER: string;
            FG_UPDATE_BALANCE_METER_AFTER: string;
            FG_UPDATE_BALANCE_METER_AFTER_SPIN_CLICK: string;
            FG_UPDATE_BALANCE_METER: string;
            FG_STOP_REEL_NOW: string;
            FG_CHECK_FOR_ANTICIPATION_ON_REELS: string;
            FG_UPDATE_SYMBOLS_ON_GRID: string;
            FG_NULL_SPIN_BTN: string;
            FG_UPDATE_REELVIEW_MODEL_FOR_QUICKSPIN: string;
            FG_ENABLE_STOP_BTN: string;
            FG_HIDE_CONTAINERS: string;
            FG_NOW_SPIN_REEL: string;
            FG_SHOW_CONTAINERS: string;
            FG_ENABLE_BUTTON_INTERACTION: string;
            FG_DISABLED_BUTTON_INTERACTION: string;
            FG_SHOW_SPIN_BTN_HIDE_STOP_BTN: string;
            FG_SHOW_SKIP_BTN_DISABLED_HIDE_STOP_BTN: string;
            FG_CHECK_FOR_WIN_AFTER_REEL_STOP: string;
            FG_SHOW_NEXT_WIN_PRESENTATION: string;
            FG_SHOW_5OAK: string;
            FG_HIDE_5OAK: string;
            FG_SET_WINLINE_AND_WAYS_DATA: string;
            FG_SHOW_SPAGHTTI: string;
            FG_SHOW_ALL_WIN_FRAMES: string;
            FG_START_WIN_TICK_UP: string;
            FG_FORCE_STOP: string;
            FG_START_SCATTER_PRESENTATION: string;
            FG_START_BIG_WIN_PRESENTATION: string;
            FG_START_FIRST_TOGGLE_CYCLE: string;
            FG_START_SECOND_TOGGLE_CYCLE: string;
            FG_START_FIRST_TOGGLE_CYCLE_WAYS: string;
            FG_START_SECOND_TOGGLE_CYCLE_WAYS: string;
            FG_UNSCBSCRIBE_ALL_EVENTS_ON_REEL_PANEL_CONTROLLER: string;
            FG_STOP_ALL_WIN_ANIMATION_ON_REEL: string;
            FG_ALL_REEL_SPINING: string;
            FG_SHOW_WIN_PAYLINE: string;
            FG_SHOW_SCATTER_FRAMES: string;
            FG_SHOW_ALL_WIN_PAYLINE: string;
            FG_HIDE_ALL_WIN_PAYLINE: string;
            FG_HIDE_ALL_PAYLINE: string;
            FG_HIDE_ALL_SPAGETTI: string;
            FG_FLASH_SPAGETTI: string;
            FG_SHOW_SPAGETTI: string;
            FG_SHOW_ALL_FRAMES: string;
            FG_HIDE_ALL_FRAMES: string;
            FG_SHOW_PAYLINE: string;
            FG_HIDE_PAYLINE: string;
            FG_HIDE_PAYLINE_WINBOX: string;
            FG_HIDE_ALL_PAYLINE_WINBOX: string;
            FG_CREATE_WINBOX: string;
            FG_CREATE_PAYLINE_SPAGGITTE: string;
            INITIATE_REELPANEL: string;
            SPIN: string;
            STOP_SPIN: string;
            SPIN_COMPLETE: string;
            REEL_STOPPED: string;
            REEL_STOPPING: string;
            LINE_ANIMATION_STARTED: string;
            START_SCATTER_WIN_ANIM: string;
            SCATTER_ANIMATION_STARTED: string;
            SCATTER_ANIMATION_ENDED: string;
            LINE_ANIMATION_ENDED: string;
            SYMBOL_ANIM_STARTED: string;
            SYMBOL_ANIM_ENDED: string;
            START_All_WIN_ANIM: string;
            START_WIN_ANIM: string;
            START_WAYS_ANIM: string;
            WIN_CYCLE_COMPLETED: string;
            WAY_ANIMATION_STARTED: string;
            WAY_ANIMATION_ENDED: string;
            START_EXPANDING_WILD: string;
            PLAY_EXPANDING_WILD: string;
            CLEAR_EXPANDING_WILD: string;
            SHOW_STICKY_WILD: string;
            PLAY_STICKY_WILD_ANIMATION: string;
            CLEAR_STICKY_WILD: string;
            RESET_SHIFTING_WILD: string;
            CHANGE_SYMBOL: string;
            PLAY_CHANGE_SYMBOL_SOUND: string;
            SHOW_SHIFTING_WILD: string;
            MOVE_SHIFTING_WILD: string;
            CLEAR_SHIFTING_WILD: string;
            TWEEN_SHIFTING_WILD: string;
            WILD_SHIFTED: string;
            INTRO_OUTRO_HIDDEN: string;
            STOP_ALL_WIN_ANIMATIONS: string;
            SPIN_STARTED: string;
            SHOW_ANTICIPATION: string;
            SHOW_LANDINGANIMATION: string;
            SHOW_BIG_WIN: string;
            BIG_WIN_HIDDEN: string;
            REEL_MASK_ON: string;
            REEL_MASK_OFF: string;
            FG_INITIATE_REELPANEL: string;
            FG_SPIN: string;
            FG_STOP_SPIN: string;
            FG_SPIN_COMPLETE: string;
            FG_REEL_STOPPED: string;
            FG_REEL_STOPPING: string;
            FG_LINE_ANIMATION_STARTED: string;
            FG_START_SCATTER_WIN_ANIM: string;
            FG_SCATTER_ANIMATION_STARTED: string;
            FG_SCATTER_ANIMATION_ENDED: string;
            FG_LINE_ANIMATION_ENDED: string;
            FG_START_All_WIN_ANIM: string;
            FG_START_WIN_ANIM: string;
            FG_START_All_WAYS_ANIM: string;
            FG_START_WAYS_ANIM: string;
            FG_WIN_CYCLE_COMPLETED: string;
            FG_WAY_ANIMATION_STARTED: string;
            FG_WAY_ANIMATION_ENDED: string;
            FG_START_EXPANDING_WILD: string;
            FG_STOP_ALL_WIN_ANIMATIONS: string;
            FG_SHOW_ANTICIPATION: string;
            FG_SHOW_LANDINGANIMATION: string;
            FORCE_HIDE_REEL_SYMBOLS: string;
            ON_FIVE_OF_A_KIND_TWEEN_COMPLETE: string;
            WIN_ON_REELS: string;
            GAME_MSG_SHOW: string;
            GAME_MSG_HIDE: string;
            LOGIC_ONSTAKE_CHANGE: string;
            LOGIC_ONINFO_PRESSED: string;
            LOGIC_SHOW_GAME_MESSAGE: string;
            LOGIC_HIDE_GAME_MESSAGE: string;
            LOGIC_ON_UNSUBSCRIBE_REEL_PANEL_EVENTS: string;
            UPDATE_REEL_CONFIG: string;
            DOMMOUSESCROLL: string;
            MOUSEWHEEL: string;
            KEYDOWN: string;
            DISABLE_SPACEBAR_EVENTS: string;
            ENABLE_SPACEBAR_EVENTS: string;
            KEY_DOWN_FG: string;
        };
        GameStateBG: typeof ingenuity.slot.BasegameState;
        GameStateFG: typeof ingenuity.slot.FreegameState;
    };
}
declare namespace ingenuity.slot.Logic {
    class SlotGameLogic2 extends SlotGameLogic {
        protected minSpinTimeDone: boolean;
        protected minSpinDuration: any;
        protected onValidateBet(evt: IEvent): void;
        protected onValidateBetInFreeGame(evt: IEvent): void;
        protected minSpinDone(): void;
        protected onSpinResponseReceived(evt: IEvent): void;
        protected onAllReelSpinning(evt: IEvent): void;
        protected OnreelSpiningAndServerResponseReceived(): void;
    }
}
declare namespace ingenuity.slot.reelPanel {
    interface IReelPanel extends IContainer {
        x: number;
        y: number;
        w: number;
        h: number;
        symbolCount: number;
        startId: number;
        symPerReel: number | number[];
        mask: string | string[];
        spinSpeed: number | number[];
        minSpeed: number;
        decSpinSpeed: number;
        quickSpinSpeed: number | number[];
        type: string;
        image: Array<string>;
        noStartDelay: boolean;
        noStartBounce?: boolean;
        noStopDelay: boolean;
        noStopBounce?: boolean;
        stickyWildLayering: boolean;
        RandomWildlayering: boolean;
        anticipationLoops: number;
        anticipationSpeed: number;
        anticipationDelay: number;
        anticipation: IAnticipationConfig | IAnticipationConfig[];
        reels: IReel[];
        symbolData: slot.symbol.ISymbolData[];
        isBlur: boolean;
    }
    interface IReel extends IContainer {
        border: boolean;
        noDelay: boolean;
        maxLoops: number;
        config: IReelConfig;
    }
    interface IAnticipationConfig extends IObject {
        symbolId: number;
        symbolCount: number;
        aniticipationRunOnReel: number[];
    }
    interface IReelConfig extends IObject {
        startBounceAmt: number;
        startBounceTime: number;
        startBounceTimeout: number;
        stopBounceAmt: number;
        stopBounceTime: number;
        stopBounceTimeout: number;
        startDelay: number;
        stopDelay: number;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class MultiAnimIcon extends ui.Container {
        symType: string | Array<string>;
        iconNum: number;
        gridPosition: number;
        blurred: boolean;
        animType: string | string[];
        protected allreadyAnimating: boolean;
        protected animObj: any;
        constructor(symbolId: number, json: IContainer);
        protected init(): void;
        playAnim(animName?: string, stopFrame?: string, callback?: () => void, cbScope?: any): void;
        stopAnim(): void;
        blurIcons(): this;
        resetBlurIcon(): MultiAnimIcon;
        resetTriggeringIcon(): MultiAnimIcon;
    }
}
declare namespace ingenuity.slot.symbol {
    class SymbolConstants {
        static readonly ANIMATION_SPRITE: string;
        static readonly ANIMATION_SPINE: string;
        static readonly ANIMATION_LAYERED: string;
        static readonly ANIMATION_SCALE: string;
        static readonly ANIMATION_BLINK: string;
        static readonly ANIMATION_FLASH: string;
        static readonly ANIMATION_NONE: string;
        static readonly TYPE_NORMAL: string;
        static readonly TYPE_OVERLAY: string;
        static readonly TYPE_UNDERLAY: string;
        static readonly TYPE_HIGH: string;
        static readonly TYPE_MID: string;
        static readonly TYPE_LOW: string;
        static readonly TYPE_WILD: string;
        static readonly TYPE_SCATTER: string;
        static readonly DEFAULT_ANIMATION_KEY: string;
        static readonly DEFAULT_ALWAYS_ANIMATION_KEY: string;
    }
}
