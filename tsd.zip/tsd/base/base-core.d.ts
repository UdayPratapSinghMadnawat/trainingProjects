/** 
	Base Core v1.4.4 
	©Ingenuity Gaming Pvt. Ltd.
	Published: Tue Sep 11 2018 15:42:49 GMT+0530 (India Standard Time) 
**/
/* tslint:disable */
/* tslint:disable */
/// <reference path="../../../node_modules/typescript/lib/lib.d.ts" />
/// <reference path="../../../node_modules/typescript/lib/lib.es2015.symbol.d.ts" />
/// <reference path="../../../node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts" />
/// <reference path="../phaser.d.ts" />
/// <reference path="../phaser-spine.d.ts" />
declare namespace ingenuity {
    interface IObject extends Object {
        [key: string]: any;
        [key: number]: any;
    }
    interface IEventDispatcher {
        on(type: string, handler: (e?: IEvent) => void, scope: any, once: boolean, data: any, priority: number): () => void;
        off(type: string, handler?: (e?: IEvent) => void): void;
        hasEvent(type: string): void;
        fireEvent(type: string, data: any): void;
    }
    interface IEvent {
        type: string;
        timeStamp: number;
        data: any;
        removed: boolean;
        remove(): void;
    }
    interface ISubEventObj {
        [key: string]: IEventObject[];
    }
    interface IEventObject extends IObject {
        func: () => void;
        scope: any;
        once: boolean;
        data: any;
        priority: number;
    }
    interface IBigWinFountainOptions {
        w: number;
        h: number;
        fromBottomOut: boolean;
        allAtOnce: boolean;
        offsetHeight: number;
        offsetX: number;
        speed: number;
        numParticles: number;
        deltaX: number;
        deltaY: number;
    }
    interface IAnimatedMeter {
        startTick(value: number, showCurrency: boolean, showNumOnly: boolean, duration: number, onlyNumber?: boolean, callback?: () => void): number;
        stopTick(showCurrency: boolean, showNumOnly: boolean): void;
    }
    interface IAjaxOptions {
        url: string;
        method: string;
        withCredentials: boolean;
        receiveType: string;
        success(data: any): void;
        error(status: any): void;
        header?: any;
        data?: any;
        timeout?: number;
    }
    interface ISoundManifest {
        data: {
            audioSprite: ISoundProperties;
        };
        src: string;
        id: string;
    }
    interface ISoundProperties {
        id: string;
        loop: number;
        volume: number;
        minVolume: number;
        singleInstance: boolean;
    }
    interface IGameStates extends IObject {
        load?: loader.Loading;
        intro?: states.State;
        baseGame?: states.BaseGameState;
        freeGame?: states.State;
        bonus?: states.State;
    }
    interface IContainer extends IObject {
        x?: number;
        y?: number;
        w?: number;
        h?: number;
        id?: string;
        visible?: boolean;
        parent?: string;
        regX?: number;
        regY?: number;
        rotation?: number;
        showBounds?: boolean;
        bounds?: boolean;
    }
    interface ILabelStyles extends Phaser.PhaserTextStyle {
        font: string;
        fontSize: number;
        fontStyle: string;
        fill?: any;
        align?: string;
        stroke?: string;
        strokeThickness?: number;
        wordWrap?: boolean;
        wordWrapWidth?: number;
        maxLines?: number;
        shadowOffsetX?: number;
        shadowOffsetY?: number;
        shadowColor?: string;
        shadowBlur?: number;
        valign?: string;
        tab?: number;
        tabs?: number;
        fontVariant?: string;
        fontWeight?: string | number;
        backgroundColor?: string;
        boundsAlignH?: string;
        boundsAlignV?: string;
        lineSpacing: number;
        disableColor?: number;
        disableTint?: number;
        opacity?: number;
    }
    interface ILabelShadow extends IObject {
        color: string;
        blurX: number;
        blurY: number;
        quality: number;
    }
    interface ILabel extends IObject {
        x: number;
        y: number;
        w: number;
        h: number;
        id: string;
        i18nId?: string;
        parent?: string;
        text?: string;
        replaceText?: string;
        bounds?: boolean;
        showBounds?: boolean;
        boundsColor?: number;
        boundsStroke?: number;
        regX?: number;
        regY?: number;
        rotation?: number;
        visible?: boolean;
        style?: ILabelStyles;
        shadow?: ILabelShadow;
        autoFitHeight?: boolean;
        doInitialFit?: boolean;
    }
    interface IButtonLableStates extends IObject {
        over: ILabel;
        out: ILabel;
        down: ILabel;
        up: ILabel;
        disable: ILabel;
    }
    interface IButton extends IObject {
        x: number;
        y: number;
        w: number;
        h: number;
        id: string;
        parent?: string;
        enabled?: boolean;
        visible?: boolean;
        showBounds?: boolean;
        anchorX: number;
        anchorY: number;
        angle?: number;
        image: any;
        images: any;
        label: ILabel | IButtonLableStates;
        priorityID?: number;
        frames: {
            up: string;
            over: string;
            down: string;
            out: string;
            disable?: string;
        };
        hitarea?: {
            x: number;
            y: number;
            type: string;
            w?: number;
            h?: number;
            radius?: number;
            diameter?: number;
            shape?: string;
            commandArray?: Array<any>;
            visible?: boolean;
            strokeSize?: number;
            strokeColor?: string;
            strokeAlpha?: number;
            fillColor?: string | number;
            fillAlpha?: number;
            images?: any;
            image?: any;
            frames?: string | number;
            rotation?: number;
        };
    }
    interface IImage extends IObject {
        x: number;
        y: number;
        id: string;
        parent?: string;
        w?: number;
        h?: number;
        images?: any;
        image?: any;
        frames?: string | number;
        rotation?: number;
        visible?: boolean;
    }
    interface IAnimation extends IContainer {
        image?: string;
        images?: string[];
        frame?: string | number;
        frames?: string[] | number[];
        frameRate?: number;
        loop?: boolean;
        scale?: number;
        scaleX?: number;
        scaleY?: number;
        animations: {
            [key: string]: {
                frames: string[] | number[];
                generateNames?: boolean;
                prefix?: string;
                suffix?: string;
                zeroPad?: boolean;
                frameRate: number;
                loop: boolean;
            };
        };
    }
    interface ISlider extends IContainer {
        x: number;
        y: number;
        w: number;
        h: number;
        visible: boolean;
        bounds: boolean;
        min: number;
        max: number;
        sliderMaskFill: boolean;
        orientation: string;
        betArray: any;
        steps: boolean;
        id: string;
        sliderBg: {
            x: number;
            y: number;
            w: number;
            h: number;
            type: any;
            image: any;
        };
        blob: {
            x: number;
            y: number;
            w: number;
            h: number;
            type: any;
            image: any;
        };
        parent: string;
    }
    interface IShape extends IObject {
        x: number;
        y: number;
        id: string;
        parent?: string;
        w?: number;
        h?: number;
        strokeSize: number;
        strokeColor: number;
        strokeAlpha: number;
        fillColor: number;
        fillAlpha: number;
        shape: string;
        radius: number;
        diameter: number;
        commandArray: Array<any>;
        visible: boolean;
        priorityID: number;
    }
    interface IShapeButton extends IShape {
        label: ILabel;
    }
    interface IShapeToggleButton extends IContainer {
        fillColor: number;
        fillColorOff: number;
        circleFillColor: number;
        circleFillAlpha: number;
        isOn: boolean;
        baseStroke: number;
        knobStroke: number;
        baseStrokeColourOn: number;
        baseStrokeColourOff: number;
        knobStrokeColour: number;
        baseStrokeAlpha: number;
        baseCornerRadius: number;
        knobDiameter: number;
        knobOffsetX: number;
        knobOffsetY: number;
    }
    interface IToggleButton extends IObject {
        x: number;
        y: number;
        w: number;
        h: number;
        id: string;
        parent?: string;
        enable?: boolean;
        enabled?: boolean;
        visible?: boolean;
        showBounds?: boolean;
        image: any;
        images: any;
        label: ILabel;
        priorityID?: number;
        hitarea?: {
            x: number;
            y: number;
            type: string;
            w?: number;
            h?: number;
            radius?: number;
            diameter?: number;
            shape?: string;
            commandArray?: Array<any>;
            strokeSize?: number;
            strokeColor?: string;
            strokeAlpha?: number;
            fillColor?: string | number;
            fillAlpha?: number;
            visible?: boolean;
            images?: any;
            image?: any;
            frames?: string | number;
            rotation?: number;
        };
        alpha: number;
        frames: {
            on: {
                up: string;
                over: string;
                down: string;
                out: string;
                disable?: string;
            };
            off: {
                up: string;
                over: string;
                down: string;
                out: string;
                disable?: string;
            };
        };
    }
    interface ITabButton extends IButton {
        totalTabs: number;
    }
    interface ILabelBitmap extends ILabel {
        image?: any;
        images?: any;
    }
    interface ITween extends Phaser.Tween {
        timeStamp?: number;
    }
    interface IVideo extends Phaser.Video {
        key: string;
    }
    interface IGraphics extends Phaser.Graphics {
        x: number;
    }
    interface IEmitter extends Phaser.Particles.Arcade.Emitter {
        x: number;
    }
    interface IDisplayObject extends PIXI.DisplayObject {
        x: number;
    }
    interface IDeviceConfig {
        [key: string]: {
            width: number;
            height: number;
        };
    }
    interface IText extends Phaser.Text {
        name: string;
    }
    interface ISignal extends Phaser.Signal {
        dispatch(...params: any[]): void;
    }
    interface IPointer extends Phaser.Pointer {
        x: number;
    }
    interface IKey extends Phaser.Key {
        game: Phaser.Game;
    }
    interface IAdvancedButton extends IObject {
        x: number;
        y: number;
        w: number;
        h: number;
        id: string;
        parent?: string;
        enabled?: boolean;
        visible?: boolean;
        showBounds?: boolean;
        states: {
            "over": {
                "btnAnimation"?: {};
                "btnSprite"?: {};
                "btnLabelBitmap"?: {};
                "btnLabel"?: {};
            };
            "disable": {};
            "out": {};
            "up": {};
            "down": {};
        };
        hitarea: {
            x: number;
            y: number;
            type: string;
            w?: number;
            h?: number;
            visible?: boolean;
            images?: any;
            image?: any;
            frames?: string | number;
            rotation?: number;
            alpha?: number;
        };
    }
}
declare namespace ingenuity.events {
    class Event implements IEvent {
        type: string;
        data: any;
        timeStamp: number;
        target: any;
        removed: boolean;
        constructor(type: string, data?: any);
        remove(): void;
        toString(): string;
    }
}
declare namespace ingenuity.events {
    class EventDispatcher implements IEventDispatcher {
        private subscribedEvents;
        constructor();
        on(type: string, handler: (evt?: IEvent, data?: IObject) => void, scope?: any, once?: boolean, data?: any, priority?: number): any;
        off(type: string, handler?: (evt?: IEvent, data?: IObject) => void, scope?: any): void;
        offForScope(type: string, scope: any, handler?: (evt?: IEvent, data?: IObject) => void): void;
        hasEvent(type: string): boolean;
        fireEvent(type: string | Event, data?: any): void;
    }
}
declare namespace ingenuity.base {
    class AudioController extends Phaser.SoundManager {
        protected objAudio: any;
        protected isAudioPlaying: boolean;
        protected sndPlayingInstance: any;
        private defaultKey;
        constructor(key?: string | string[]);
        postLoadSound(key: string | string[]): void;
        setEnabled(value: boolean): void;
        getEnabled(): boolean;
        play(soundId: string, vol?: number, loop?: boolean, key?: string): Phaser.Sound;
        isSoundPlaying(soundId: string, key?: string): boolean;
        getSoundInstance(soundId: string, key?: string): Phaser.Sound;
        fadeVolume(soundId: string, duration: number, volume: number, key?: string, callback?: () => void): void;
        pause(soundId: string, key?: string): void;
        muteSound(soundId: string, key?: string): void;
        unmuteSound(soundId: string, key?: string): void;
        isSoundMuted(soundId: string, key?: string): void;
        pauseAll(): void;
        resumeAll(): void;
        stop(soundId: string, key?: string): void;
        stopAll(): void;
        setMute(value: boolean): void;
        getMute(): boolean;
        destroySound(key: string): void;
    }
}
declare namespace ingenuity.core.base {
    let constants: {
        BASE_CORE_RESIZE_DELAY_STRING: string;
        BASE_CORE_RESIZE_DELAY_TIME: number;
        MILLISECOND_CONVERT_VALUE: number;
        RESIZE_EVENT_STRING: string;
        DEFAULT_FONT_SIZE: number;
        DEFAULT_POSITION: number;
        ANCHOR_LEFT: number;
        ANCHOR_CENTER: number;
        ANCHOR_RIGHT: number;
        MINIMUM_SAFE_FONT: number;
        CANVAS_RENDERER: number;
        AUTO_RENDERER: number;
        WEBGL_RENDERER: number;
        CANVAS_CONTAINER: string;
        loader: {
            IMAGE: string;
            JSON: string;
            AUDIO_SPRITE: string;
            PACK: string;
            ATLAS: string;
            ATLAS_ARRAY: string;
            BITMAP_FONT: string;
            VIDEO: string;
            SPINE: string;
            VIDEO_EVENT: string;
            VIDEO_AS_BLOB: boolean;
            STAGE_MANIFEST: string;
            STAGE_BASE_GAME: string;
            STAGE_BASE_GAME_POSTLOAD: string;
            STAGE_FREE_GAME: string;
            STAGE_INFO: string;
            STAGE_BONUS: string;
            LANGUAGE_FILE_KEY: string;
            MAIN_DATA_FILE_KEY: string;
            SOUND_LIST_FILE_KEY: string;
            CURRENCY_FILE_KEY: string;
        };
        delayKeys: {
            CHECK_AND_LOAD_NEXT_STAGE: string;
            SPINE_CREATION_DELAY: string;
        };
        meter: {
            TICKUP_ROUNDUP_TO_VALUE: number;
        };
        BUTTON_LABEL_TINT_DISABLE: number;
        BUTTON_LABEL_TINT_ENABLE: number;
        states: {
            PRELOADING_STATE: string;
            BASE_GAME_STATE: string;
            INTRO_STATE: string;
            FREE_GAME_STATE: string;
            BONUS_STATE: string;
        };
    };
}
declare namespace ingenuity.core.base {
    const EventConstants: {
        BASEGAME_ASSETS_LOADED: string;
        PRIORITIZE_LOADING_STAGE: string;
        FREEGAME_ASSETS_LOADED: string;
        INFO_ASSETS_LOADED: string;
        BONUS_ASSETS_LOADED: string;
        ALL_ASSETS_LOADED: string;
        UPDATE_LOADING_PROGRESS: string;
        FILE_LOAD_ERROR: string;
        FILE_LOADED: string;
        UPDATE_LABELS_TEXT: string;
        UPDATE_METER_TEXT: string;
        UPDATE_BUTTON_LABEL_TEXT: string;
    };
}
declare namespace ingenuity.ui {
    class Container extends Phaser.Group {
        json: IContainer;
        protected signals: {
            [key: string]: ISignal;
        };
        constructor(json: IContainer, game: Phaser.Game, parent?: PIXI.DisplayObjectContainer, name?: string, addToStage?: boolean, enableBody?: boolean, physicsBodyType?: number);
        on(type: string, handler: (evt?: IEvent | any, data?: IObject) => void, scope?: any, once?: boolean, data?: any, priority?: number): void;
        off(type: string, handler?: (evt: IEvent | any, data?: IObject) => void, scope?: any): void;
        hasEvent(type: string): boolean;
        fireEvent(type: string, data?: any): void;
        showBounds(targetCoordinateSpace?: PIXI.DisplayObject | PIXI.Matrix): void;
        toString(): string;
    }
}
declare namespace ingenuity.ui {
    class Bitmap extends Phaser.Image {
        json: IImage;
        skew: Point;
        private currentBounds;
        private transformCallback;
        private transformCallbackContext;
        constructor(json: IImage);
        updateTransform(parent: PIXI.DisplayObjectContainer): this;
    }
}
declare namespace ingenuity.ui {
    class Sprite extends Phaser.Sprite {
        skew: Point;
        private currentBounds;
        constructor(x: number, y: number, key?: string | Phaser.RenderTexture | ui.BitmapData | PIXI.Texture, frame?: string | number);
        updateTransform(parent?: PIXI.DisplayObjectContainer): this;
    }
}
declare namespace ingenuity.ui {
    class ButtonBase extends Phaser.Button {
        protected currentState: string;
        protected hitarea: any;
        label: Label;
        json: IButton;
        static UP: string;
        static DOWN: string;
        static OVER: string;
        static OUT: string;
        static DISABLED: string;
        constructor(json: IButton, game: Phaser.Game, x?: number, y?: number, key?: string, callback?: any, callbackContext?: any, overFrame?: string, outFrame?: string, downFrame?: string, upFrame?: string, disabledFrame?: string);
        protected setLabelForStates(over: ILabel, down: ILabel, out: ILabel, up: ILabel): void;
        protected changeStateLabel(btn: ButtonBase, pointer: IPointer, labelState: ILabel): void;
        toggleStates(state1?: string, state2?: string, toggleTime?: number): ButtonBase;
        clearToggleState(): ButtonBase;
        protected createImageHitarea(json: any): Phaser.Image;
        protected createShapeHitarea(json: any): Phaser.Rectangle | Phaser.Circle | Phaser.RoundedRectangle | Phaser.Polygon;
        toString(): string;
        setIsInputEnabled(value: boolean): void;
        getIsInputEnabled(): boolean;
        visible: boolean;
        disableAndTint(): void;
        enableAndTint(): void;
        on(type: string, handler: (e?: any, data?: IObject) => void, scope?: any, once?: boolean, data?: any, priority?: number): (but?: ButtonBase, evt?: Phaser.Pointer, isOver?: boolean) => void;
        off(type: string, handler?: (e?: any, data?: IObject) => void): void;
        setLabel(text?: string): void;
        protected showBounds(json?: IButton): void;
    }
}
declare namespace ingenuity.ui {
    class Label extends Container {
        protected label: IText;
        private boundsGraphics;
        constructor(json: ILabel);
        showBounds(targetCoordinateSpace?: PIXI.DisplayObject | PIXI.Matrix): void;
        protected fitText(targetCoordinateSpace?: PIXI.DisplayObject | PIXI.Matrix): Label;
        reset(): Label;
        resetScale(): Label;
        resetSizing(): Label;
        text: string;
        setText(value: string, immediate?: boolean, updateBounds?: boolean): Label;
        tint: number;
        setStyle(style?: ILabelStyles, update?: boolean): Label;
        setShadow(x?: number, y?: number, color?: any, blur?: number, shadowStroke?: boolean, shadowFill?: boolean): Label;
        setAlignment(align?: string, vAlign?: string): Label;
        setColour(value: any[][] | any): Label;
        setOutlineColour(value: any[][] | any): Label;
        toString(): string;
        destroy(destroyChildren: boolean): void;
    }
}
declare namespace ingenuity.utils {
    function getParams(key: string): any;
    function checkIframe(): boolean;
    function checkLocalStorage(): boolean;
    function store(key: string, value: any): void;
    function retrieve(key: string): any;
    function isStored(key: string): boolean;
    function xmlToJSON(xml: XMLDocument, strRootNode: string): any;
    let isTouch: boolean;
    function ajax(ajaxOpts: IAjaxOptions | string, success?: (response?: any) => void, error?: (response?: any) => void, method?: string, wc?: boolean, receiveType?: string, data?: any, header?: any, timeout?: number): XMLHttpRequest;
    function clone(args: any): any;
    function cloneArray(array: Array<number>, target?: Array<number>): number[];
    function shuffle(array: Array<number>): Array<number>;
    function uniqueArray(array: Array<number | string>, target?: Array<number>): Array<number | string>;
    function hardShuffle(array: Array<any>): Array<any>;
    function hypotenuse(a: number, b: number): number;
    function radToDeg(radAngle: number, roundOpts?: number): number;
    function degToRad(degAngle: number, roundOpts?: number): number;
    function getClassString(object: any): string;
    function toXML(str: string): any;
    function compareArray(arr1: Array<any>, arr2: Array<any>): boolean;
    function compareObject(object1: any, object2: any): boolean;
    function toInt(str: string): number;
    function toFloat(str: string): number;
    function strToIntArray(str: string, separator?: string): number[];
    function strToNumArray(str: string, separator?: string): Array<number>;
    function padZero(num: number, size?: number): string;
    function round(num: number, size?: number): number;
    function roundUp(n: number): number;
    function ceil(n: number): number;
    function floor(n: number): number;
    function floatToInt(n: number): number;
    function extendObj(objA: IObject, objB: IObject, overwrite?: boolean): IObject;
    function setCSSPrefix(element: HTMLElement, prop: string, value: any): void;
    function setCSSStyle(element: HTMLElement, style: IObject): void;
    function getElement(str: string | string[]): any;
    function addClass(elm: Element, classList: string | IObject): void;
    function removeClass(elm: Element, CSSClass?: string): void;
    function delayedCall(key: string, time: number, callback: (data?: any) => void, callbackContext?: any, ...args: any[]): void;
    function delayedLoopCall(key: string, time: number, callback: (data?: any) => void, callbackContext?: any, ...args: any[]): void;
    function delayedRepeatCall(key: string, time: number, repeatCount: number, callback: (data?: any) => void, callbackContext?: any, ...args: any[]): void;
    function killDelayedCall(key: string): void;
    function LoadFonts(fonts: string[], basePath?: string): void;
}
declare namespace ingenuity.utils.Formatter {
    let prefixSymbol: boolean;
    function init(basePath: any, curr?: string, decimalSep?: string, thousandSep?: string, callback?: (data?: any) => void): void;
    function setCurrency(curr: string, decimalSep?: string, thousandSep?: string): void;
    function setCurrencySeparators(decimalSep: string, thousandSep?: string): void;
    function toLocaleNum(num: number | string, places?: number): string;
    function toLocaleMoney(num: number, places?: number): string;
    function toLocalePercent(num: string | number, places?: number): string;
}
declare namespace ingenuity.utils.Localization {
    let initiated: boolean;
    function init(basepath: string | string[], lang?: string, isFolder?: boolean, callback?: (data?: any) => void): void;
    function setLanguage(lang?: string): void;
    function getText(key: string, replaceArray?: any): string;
}
declare namespace ingenuity.ui {
    class Meter extends Label implements IAnimatedMeter {
        protected value: number;
        protected formatedValue: string;
        protected currencyFormattedValue: string;
        protected ticking: boolean;
        protected endValue: number;
        protected callback: () => void;
        protected tickupAnim: ITween;
        protected duration: number;
        onTickupStart: ISignal;
        onTickup: ISignal;
        onTickupComplete: ISignal;
        constructor(json: ILabel, game?: Phaser.Game);
        setValue(value: number): void;
        getValue(): number;
        setVisible(value: boolean): void;
        getVisible(): boolean;
        setFormattedValue(value: string): void;
        setFormattedString(str: string, value: string): void;
        getFormattedValue(): string;
        setCurrencyFormattedValue(value: string): void;
        setCurrencyFormattedString(str: string, value: string): void;
        getCurrencyFormattedValue(): string;
        resetMeter(): void;
        readonly isTicking: boolean;
        startTick(value: number, showCurrency?: boolean, noFormatting?: boolean, duration?: number, onlyNumber?: boolean, callback?: () => void): number;
        stopTick(showCurrency?: boolean, noFormatting?: boolean, onlyNumber?: boolean): void;
        toString(): string;
    }
}
declare namespace ingenuity.ui {
    class Slider extends Container {
        json: IContainer;
        blob: any;
        protected blobBg: Phaser.Image;
        private dragging;
        private min;
        private max;
        private orientation;
        private maxLabel;
        private minLabel;
        private currentValueLabel;
        private initialX;
        private initialY;
        private currentX;
        private currentY;
        private range;
        private currentValue;
        private maxWidth;
        private maskObj;
        protected betArray: Array<string>;
        protected currentBet: number;
        protected ratio: number;
        protected steps: boolean;
        protected previousX: number;
        protected previousY: number;
        static UP: string;
        static DOWN: string;
        static OVER: string;
        static OUT: string;
        static DISABLED: string;
        constructor(json: IContainer, parent?: PIXI.DisplayObjectContainer);
        protected init(json: IContainer): void;
        protected setMinMaxAndCurrentValue(): void;
        protected createSliderMask(): void;
        protected move(pointer: IObject, x: number, y: number): void;
        protected createSliderParametersLabel(): void;
        protected createSliderTrack(): void;
        protected createBlob(): void;
        on(type: string, handler: (evt?: any) => void, scope?: any, once?: boolean, data?: any, priority?: number): (evt?: any) => void;
        off(type: string, handler?: (evt?: any) => void, scope?: any): void;
        protected onBlobClicked(evt: IObject): void;
        protected onBlobDragEnd(evt: IEvent): void;
        protected calculateBlobsValue(): string | number;
        protected dragStarted(blob: IObject, pointer: IObject, dragX: any): void;
        protected initializeInitialXY(): void;
        protected addInputEvents(tabBtn: IObject): void;
        setBetArrayAndCurrentBet(betArray: Array<any>, currentBet: number): void;
        protected setBlobsInitialPosition(): void;
    }
}
declare namespace ingenuity.ui {
    class TabButton extends Container {
        protected selectedTab: number;
        protected tabArray: Array<any>;
        constructor(json: ITabButton, game: Phaser.Game);
        protected createTabGroupAndAddTabButtons(json: any, game: Phaser.Game): void;
        protected onTabDown(evt: any): void;
        protected addInputEvents(tabBtn: ButtonBase): void;
        protected createTabButtons(json: any, game: any): any;
        getSelectedTab(): number;
        on(type: string, handler: (e?: any) => void, scope?: any, once?: boolean, data?: any, priority?: number): () => void;
        off(type: string, handler?: (e?: any) => void): void;
        hasEvent(type: string): any;
        setEnabled(value: boolean): void;
        setTabEnabledByNo(tabNo: number, value: boolean): void;
        getIsTabEnabled(tabNo: number): any;
    }
}
declare namespace ingenuity.ui {
    class ShapeToggleButton extends Container {
        private objMyGame;
        private objBtnBGOn;
        private objBtnBGOff;
        private objBtnCircle;
        objBtnHit: Phaser.Graphics;
        isOn: boolean;
        constructor(json: IShapeToggleButton, objGame: Phaser.Game);
        private createToggleButtonShape(json);
        setButtonState(state: boolean): void;
        switchBtn(): void;
        on(type: string, handler: (e?: any) => void, scope?: any, once?: boolean, data?: any, priority?: number): () => void;
        off(type: string, handler?: (e?: any) => void): void;
    }
}
declare namespace ingenuity.ui {
    class ToggleButton extends Container {
        protected stateOnOff: boolean;
        protected enabled: boolean;
        protected btnOn: ButtonBase;
        protected btnOff: ButtonBase;
        constructor(json: IToggleButton, game: Phaser.Game);
        private createButtons(json, game);
        on(type: string, handler: (btn?: ToggleButton, ptr?: Phaser.Pointer, over?: boolean, ...args: any[]) => void, scope?: any, once?: boolean, data?: any, priority?: number): () => void;
        onBtnOnPressed(btn: ToggleButton, point: IPointer, isOver?: boolean): void;
        onBtnOffPressed(btn: ToggleButton, point: IPointer, isOver?: boolean): void;
        off(type: string, handler?: (btn?: ToggleButton, ptr?: Phaser.Pointer, over?: boolean, ...args: any[]) => void): void;
        setEnabled(value: boolean): void;
        setInteractive(value: boolean): void;
        getInteractive(): boolean;
        switchBtn(isOn?: boolean): void;
        isOn(): boolean;
    }
}
declare namespace ingenuity.ui {
    import BitmapText = Phaser.BitmapText;
    class LabelBitmap extends Container {
        protected label: BitmapText;
        constructor(json: ILabelBitmap);
        resetSizing(): LabelBitmap;
        text: string;
        setText(value: string, immediate?: boolean): LabelBitmap;
        setAlignment(align?: string, vAlign?: string): LabelBitmap;
        tint: number;
        showBounds(targetCoordinateSpace?: PIXI.DisplayObject | PIXI.Matrix): void;
        protected fitText(targetCoordinateSpace?: PIXI.DisplayObject | PIXI.Matrix): LabelBitmap;
        toString(): string;
    }
}
declare namespace ingenuity.ui {
    class MeterBitmap extends LabelBitmap {
        protected value: number;
        protected formatedValue: string;
        protected currencyFormattedValue: string;
        protected defaultColor: string;
        protected ticking: boolean;
        protected endValue: number;
        protected callback: () => void;
        protected tickupAnim: Phaser.Tween;
        protected duration: number;
        onTickupStart: Phaser.Signal;
        onTickupComplete: Phaser.Signal;
        constructor(json: ILabelBitmap);
        setValue(value: number): void;
        getValue(): number;
        setVisible(value: boolean): void;
        getVisible(): boolean;
        setFormattedValue(value: string): void;
        setFormattedString(str: string, value: string): void;
        readonly formattedValue: string;
        setCurrencyFormattedValue(value: string): void;
        setCurrencyFormattedString(str: string, value: string): void;
        getCurrencyFormattedValue(): string;
        resetMeter(): void;
        readonly isTicking: boolean;
        startTick(value: number, showCurrency?: boolean, showNumOnly?: boolean, duration?: number, onlyNumber?: boolean, callback?: () => void): number;
        stopTick(showCurrency?: boolean, showNumOnly?: boolean, onlyNumber?: boolean): void;
        toString(): string;
    }
}
declare namespace ingenuity.ui {
    function AssignProperties(obj: any, json: any): void;
    class BaseView extends Container {
        protected buttons: {
            [key: string]: ButtonBase | TabButton | IGraphics;
        };
        protected images: {
            [key: string]: Bitmap;
        };
        protected labels: {
            [key: string]: Label | LabelBitmap;
        };
        protected meters: {
            [key: string]: Meter | MeterBitmap;
        };
        protected animations: {
            [key: string]: AnimationBase;
        };
        protected shapes: {
            [key: string]: IGraphics;
        };
        protected containers: {
            [key: string]: Container;
        };
        protected videoContainers: {
            [key: string]: Container;
        };
        protected toggleButtons: {
            [key: string]: ToggleButton;
        };
        protected slider: {
            [key: string]: Slider;
        };
        protected spines: {
            [key: string]: SpineBase;
        };
        protected allComponents: {
            [key: string]: Container | any;
        };
        protected compTypes: Array<string>;
        constructor(viewJson: IContainer);
        createDisplayTree(json: any): void;
        protected createSpine(json: ISpineData): SpineBase;
        protected createVideo(json: IContainer): IVideo;
        createMeterBitmap(json: ILabelBitmap): LabelBitmap;
        createSlider(json: ISlider): Slider;
        createLabelBitmap(json: ILabelBitmap): LabelBitmap;
        createTabButton(json: ITabButton): TabButton;
        createToggleButton(json: IToggleButton): ToggleButton;
        createAdvancedButton(json: IAdvancedButton): AdvancedButton;
        createShapeToggleButton(json: IShapeToggleButton): ShapeToggleButton;
        createShapeButton(json: IShapeButton): IGraphics;
        createContainer(json: IContainer): Container;
        createImage(json: IImage): Bitmap;
        createAnimation(json: IAnimation): AnimationBase;
        protected checkAllImagesLoaded(imgArr: string[]): boolean;
        createShape(json: IShape): IGraphics;
        createButton(json: IButton): ButtonBase;
        createBtnLabel(json: ILabel, cache?: boolean): Label;
        createLabel(json: ILabel): Label;
        createMeter(json: ILabel): void;
        getButtonById(id: string): ButtonBase | TabButton | IGraphics;
        getToggleButtonById(id: string): ToggleButton;
        getbuttonArray(): {
            [key: string]: ButtonBase | TabButton | IGraphics;
        };
        getToggleButtonArray(): {
            [key: string]: ToggleButton;
        };
        protected updateButtonLabels(evt?: IEvent): void;
        getImageById(id: string): Bitmap;
        getImageArray(): {
            [key: string]: Bitmap;
        };
        getShapeById(id: string): IGraphics;
        getShapeArray(): {
            [key: string]: IGraphics;
        };
        getLabelById(id: string): Label | LabelBitmap;
        getLabelsArray(): {
            [key: string]: Label | LabelBitmap;
        };
        protected updateLabels(evt?: IEvent): void;
        getMeterById(id: string): Meter | MeterBitmap;
        getMetersArray(): {
            [key: string]: Meter | MeterBitmap;
        };
        protected updateMeters(evt?: IEvent): void;
        getSliderByID(id: string): Slider;
        getContainerByID(id: string): Container;
        getContainersArray(): {
            [key: string]: Container;
        };
        getAnimationById(id: string): AnimationBase;
        getAnimationsArray(): {
            [key: string]: AnimationBase;
        };
        getJson(): IContainer;
        getSpineById(id: string): SpineBase;
        getSpinesArray(): {
            [key: string]: SpineBase;
        };
        getAllcomponents(): Container | any;
        getComponentById(id: string): Container | any;
        getVideoContainerById(id: string): Container;
        fetchComponentById(id: string, type?: string): any;
        fadeIn(time?: number, callback?: () => void, callbackScope?: any): void;
        fadeOut(time?: number, callback?: () => void, callbackScope?: any): void;
        checkOverlap(spriteA: any, spriteB: any): boolean;
        cloneAnimation(animationToCloneName: string, clonedAnimationName?: string): void;
        protected resize(e?: IEvent): void;
        destroy(): void;
    }
}
declare namespace ingenuity.ui {
    class AnimationBase extends Container {
        json: IAnimation;
        protected animPartArray: Array<Sprite>;
        protected currentAnimPart: number;
        protected callbackFunction: (e?: IEvent) => void;
        constructor(json: IAnimation, game?: Phaser.Game, parent?: PIXI.DisplayObjectContainer);
        resetToPoster(frame?: string | number): void;
        protected createSpriteWithMultiAnimations(x: number, y: number, imageKey: string, animationsObj: any, frame?: number, regX?: number, regY?: number, alwaysAnimate?: boolean, show?: boolean): void;
        protected createSpriteWithFrames(x: number, y: number, imageKey: string, frames: any, frame?: number, regX?: number, regY?: number, alwaysAnimate?: boolean, show?: boolean): void;
        protected createAnimationSprites(json: any): void;
        playAnim(animName?: string, callbackFunction?: () => void, scope?: any): AnimationBase;
        stopAnim(resetFrame?: boolean): AnimationBase;
        pause(): AnimationBase;
        resume(): AnimationBase;
        readonly isPlaying: boolean;
        readonly isPaused: boolean;
        protected onAnimPartComplete(evt: IEvent): void;
    }
}
declare namespace ingenuity.ui {
    class SpineBase extends PhaserSpine.Spine {
        protected signals: IObject;
        json: ISpineData;
        private pause;
        constructor(json: ISpineData);
        playAnim(animName?: string, loop?: boolean, trackIndex?: number): spine.TrackEntry;
        protected createHitArea(json: any): Phaser.Rectangle | Phaser.Circle;
        setHitArea(shape: Phaser.Rectangle | Phaser.Circle | Phaser.Polygon): void;
        on(type: string, handler: (evt?: IEvent | any, data?: IObject) => void, scope?: any, once?: boolean, data?: any, priority?: number): void;
        off(type: string, handler?: (evt: IEvent | any, data?: IObject) => void, scope?: any): void;
        hasEvent(type: string): boolean;
        fireEvent(type: string, data?: any): void;
        update(): void;
        setPause(val: boolean): void;
    }
}
declare namespace ingenuity.ui {
    class AdvancedButton extends Container {
        protected hitarea: any;
        protected btn: ButtonBase;
        protected isOn: boolean;
        enabled: boolean;
        containers: {
            [key: string]: Container;
        };
        animations: {
            [key: string]: AnimationBase;
        };
        hitArea: any;
        protected idleTimer: number;
        constructor(json: IAdvancedButton);
        protected createHitArea(json: IAdvancedButton): void;
        protected createAdvButton(json: any, game: Phaser.Game): void;
        protected createMissingStates(): void;
        createButtonDisplay(json: any): void;
        createLabel(json: ILabel): Label;
        createImage(json: IImage): Bitmap;
        createAnimation(json: IAnimation): AnimationBase;
        createShape(json: IShape): IGraphics;
        createLabelBitmap(json: ILabelBitmap): LabelBitmap;
        protected createSpine(json: ISpineData): any;
        on(type: string, handler: (e?: any, data?: IObject) => void, scope?: any, once?: boolean, data?: any, priority?: number): (but?: ButtonBase, evt?: Phaser.Pointer, isOver?: boolean) => void;
        off(type: string, handler?: (e?: any, data?: IObject) => void): void;
        onInputOverHandler(sprite: Phaser.Button, pointer: Phaser.Pointer, e: IEvent): void;
        onInputOutHandler(sprite: Phaser.Button, pointer: Phaser.Pointer): void;
        onInputDownHandler(sprite: Phaser.Button, pointer: Phaser.Pointer): void;
        onInputUpHandler(sprite: Phaser.Button, pointer: Phaser.Pointer, isOver: Boolean): void;
        setInteractive(value: boolean): void;
        getInteractive(): boolean;
        setEnabled(value: boolean): void;
        enableAndTint(): void;
        disableAndTint(): void;
        changeStateFrame(state: string): void;
        protected onCompleteIdleAnim(event?: IEvent): void;
    }
}
declare namespace ingenuity.ui {
    class Video extends Phaser.Video {
        constructor(vJson: IContainer);
    }
}
declare namespace ingenuity.loader {
    class Loader extends Phaser.Loader {
        constructor(game: Phaser.Game, baseURL?: string, crossOrigin?: boolean, enableParallel?: boolean);
        processPack(pack: any): void;
        removeItem(json: IObject): void;
        loadManifest(json: IObject): void;
    }
}
declare namespace ingenuity.states {
    abstract class State extends Phaser.State {
        constructor();
        preload(): void;
        init(...args: any[]): void;
        create(): void;
        shutdown(): void;
        update(): void;
        paused(): void;
        resumed(): void;
        render(): void;
        resize(width: number, height: number): void;
    }
}
declare namespace ingenuity.events {
    let EventConstants: {
        PLAY_SOUND: string;
        STOP_SOUND: string;
        RESIZE: string;
        METER_TICKUP_STARTED: string;
        METER_TICKUP_FINISHED: string;
        STOP_METER_TICKUP: string;
        INFO_CLOSED: string;
        SLIDER_VALUE_CHANGE: string;
        BUTTON_PRESSED: string;
        BUTTON_RELESED: string;
        SHOW_PAYTABLE: string;
        INSUFFICIENT_FUNDS: string;
        SOUND_PLAY_COMPLETE: string;
        SOUND_PLAY_FAILED: string;
        SOUND_PLAY_LOOP: string;
        ERROR_LOADING_SOUND: string;
        GAME_STAGE_CLICKED: string;
        SHOW_ERROR: string;
        PRIORITIZE_LOADING_STAGE: string;
        BASEGAME_ASSETS_LOADED: string;
        BASEGAME_POSTLOAD_ASSETS_LOADED: string;
        FREEGAME_ASSETS_LOADED: string;
        INFO_ASSETS_LOADED: string;
        BONUS_ASSETS_LOADED: string;
        ALL_ASSETS_LOADED: string;
        UPDATE_LOADING_PROGRESS: string;
        FILE_LOAD_ERROR: string;
        STATE_LOADED: string;
        COMPONENT_CREATED: string;
        LOAD_STATE: string;
        REMOVE_STATE_CACHE: string;
    };
}
declare namespace ingenuity.deviceEnvironment {
    class Configrator {
        private config;
        private userAgent;
        ua: {
            [key: string]: string | string[] | boolean;
        };
        blackListDevice: boolean;
        slowDevice: boolean;
        midRes: boolean;
        lowRes: boolean;
        constructor(config: IConfig, userAgent: string);
        private checkValue(value);
        private getSignatures(key);
        private parseUserAgent();
        private matchBlackList();
        private matchSlowList();
        private matchMidResList();
        private matchLowResList();
    }
}
declare namespace ingenuity.deviceEnvironment {
    const DeviceConfig: IConfig;
}
declare namespace ingenuity {
    interface IBrowser {
        isUC?: boolean;
        isQQ: boolean;
        isChromeIOS?: boolean;
        isBaidu?: boolean;
        isEdge?: boolean;
        isVivoNative?: boolean;
        isChromeAndroid?: boolean;
        isStockAndroid?: boolean;
        isFirefox?: boolean;
        isFirefoxIOS?: boolean;
    }
    interface IConfig extends IObject {
        noContextMenu: boolean;
        userAgent?: IObject;
        blackListDevice?: IObject;
        osVersion?: IObject;
        browserVersion?: IObject;
        canvas?: IObject;
        ldpi?: IObject;
        simplifiedAnimation?: IObject;
        viewportSettings?: IViewportSettings;
        disableScrolling?: IObject;
        disableFullScreen?: IObject;
        disablePointerEvents?: IObject;
    }
    interface IViewportSettings {
        resizeTimeout: number;
        alternateCheckFullscreen: boolean;
        useWindowSize: boolean;
        margin: IMarginSettings[];
        statusBarHeight: IMobileOrientation | number;
    }
    interface IMobileOrientation {
        "portrait": number;
        "landscape": number;
    }
    interface IMarginSettings {
        mobileType: string;
        fullscreen: boolean;
        height: number[];
        offset: IOffset;
        top?: number;
        bottom?: number;
    }
    interface IOffset {
        top: number;
        bottom: number;
    }
    interface IDeviceEnvironmentUpdate {
        availWidth: number;
        availHeight: number;
        width: number;
        height: number;
        gameWidth: number;
        gameHeight: number;
        scale: number;
        portraitScale?: number;
        maxScale: number;
        portraitMaxScale?: number;
        devicePixelRatio: number;
        orientation: string;
        scaleVariant: number;
    }
    interface IDeviceEnvironment {
        update(): IDeviceEnvironmentUpdate;
        scale: number;
        isSlowDevice: () => boolean;
        isDeviceUnsupported: () => boolean;
    }
}
declare namespace ingenuity.deviceEnvironment {
    class DeviceDetector implements IDeviceEnvironment {
        private config;
        static readonly DEVICES: {
            [key: string]: string;
        };
        static readonly DEVICE_NAMES: {
            [key: string]: string | string[];
        };
        static readonly BROWSER_NAMES: {
            [key: string]: string;
        };
        static readonly RESOLUTION: {
            [key: string]: string;
        };
        static readonly SCALE_VARIANT: {
            [key: string]: number;
        };
        readonly isLocalStorageAvailable: boolean;
        readonly isIframe: boolean;
        readonly width: number;
        readonly height: number;
        readonly isTouch: boolean;
        availHeight: number;
        availWidth: number;
        devicePixelRatio: number;
        ppi: number;
        aspectRatio: number;
        isLockTouchMove: boolean;
        browser: string;
        browserVersion: number | string;
        os: string;
        osVersion: string;
        device: string;
        scale: number;
        standalone: boolean;
        orientation: string;
        protected readonly UA: string;
        protected readonly AV: string;
        protected deviceConfig: Configrator;
        protected maxSide: number;
        protected minSide: number;
        protected gameHeight: number;
        protected gameHeightPortrait: number;
        protected gameWidthPortrait: number;
        protected gameWidth: number;
        protected scaleVariant: number;
        constructor(config: IDeviceConfig);
        setScaleVariant(value: number): void;
        getScaleVariant(): number;
        setGameDimensions(width: number, height: number): void;
        setGameDimensions(config: {
            width: number;
            height: number;
        } | {
            [key: string]: {
                [key: string]: number;
            };
        }): void;
        getResolution(): string;
        getDeviceResolution(): string;
        getDpiResolution(): string;
        update(): IDeviceEnvironmentUpdate;
        getPortraitScale(): number;
        getScale(): number;
        getMaxScale(): number;
        getPortraitMaxScale(): number;
        getOrientation(): string;
        getDeviceName(): string;
        getDeviceOS(): string;
        getBrowser(): string;
        protected getAspectRatiio(): number;
        protected detectProperty(list: IObject): string;
        protected detectOS(): string;
        protected detectName(): string;
        detectBrowser(): IObject;
        isSlowDevice(): boolean;
        isLowResDevice(): boolean;
        isMidResDevice(): boolean;
        isDeviceUnsupported(): boolean;
        protected static preventDefault(e: Event): void;
        readonly isIPad: boolean;
        readonly isDesktop: boolean;
        readonly isIPhone: boolean;
        static lockContextMenu(value: boolean): void;
    }
}
declare namespace ingenuity.core {
    import IDeviceEnvironmentUpdate = ingenuity.IDeviceEnvironmentUpdate;
    class MainGame {
        enableParallelLoading: boolean;
        mainDiv: string;
        loadStateObj: IGameStates;
        constructor(mainDiv?: string, deviceConfig?: IDeviceConfig, loadStateObj?: IGameStates);
        protected setDetectDevice(deviceConfig?: IDeviceConfig): void;
        protected setGameStage(mainDiv?: string | HTMLCanvasElement, callback?: Function, callbackContext?: IObject): Phaser.Game;
        protected setGameStageWithCanvas(canvas: HTMLCanvasElement, callback?: Function, callbackContext?: IObject): void;
        protected registerStates(loadState?: IGameStates, initialState?: string): void;
        protected onSizeChange(e?: IEvent): void;
        protected resize(e?: IEvent): void;
        protected onAssetsLoaded(e?: IEvent): void;
        protected orientationChanged(devEnv: IDeviceEnvironmentUpdate): void;
    }
}
declare namespace ingenuity.loader {
    class Loading extends states.State {
        protected loader: Loader;
        protected loadingStagesArray: IMainManifest[];
        protected currentLoadingStage: IMainManifest;
        protected static loadedStages: IManifest;
        protected static prioritize: IManifest;
        static isRemovePack: boolean;
        protected initialStageArray: IMainManifest[];
        private pendingFiles;
        protected allStagesLoaded: boolean;
        init(enableParallel?: boolean): void;
        protected addLoadEventsAndLoadMainManifest(): void;
        protected loadState(evt: IEvent): void;
        protected getStateFromArray(loadingStage: string, loadArr: IMainManifest[]): IMainManifest;
        protected removeStateCache(evt: IEvent): void;
        protected onPrioritizeLoadingStage(evt: IEvent): void;
        protected onStageLoadComplete(): void;
        protected checkForLoadingStagesComplete(loadingStage: string): void;
        protected prioritizeStage(stageName: string): void;
        protected checkAndReturnJSON(json: IContainer): IObject;
        protected onMainManifestLoaded(cacheKey: string): void;
        protected checkAndLoadNextStageInQueue(): void;
        protected getNextStage(): IMainManifest;
        protected onAllStagesLoadingComplete(): void;
        protected getMainManifestListPath(): IMainManifest;
        protected onFileLoadCompleted(progress: number, cacheKey: string, success?: any, totalLoaded?: number, totalFiles?: number, fileType?: string, file?: any): void;
        protected onLoadStart(): void;
        protected onFileLoadError(fileKey: string, file: any): void;
        static isStateLoaded(key: string): boolean;
        static isVideoLoaded(key: string): boolean;
        static isImageLoaded(key: string): boolean;
        static isSpineLoaded(key: string): boolean;
        static isJSONLoaded(key: string): boolean;
        getJSONById(key: string): any;
        getImageById(key: string): HTMLImageElement;
        getAssetById(key: string, type?: number): any;
    }
}
declare namespace ingenuity.core.constructors {
    let base: any;
}
declare namespace ingenuity.deviceEnvironment {
    const constants: IObject;
}
declare namespace ingenuity.Easing {
    class Back extends Phaser.Easing.Back {
    }
}
declare namespace ingenuity.Easing {
    class Bounce extends Phaser.Easing.Bounce {
    }
}
declare namespace ingenuity.Easing {
    class Circular extends Phaser.Easing.Circular {
    }
}
declare namespace ingenuity.Easing {
    class Cubic extends Phaser.Easing.Cubic {
    }
}
declare namespace ingenuity.Easing {
    let Default: Function;
    let Power0: Function;
    let Power1: Function;
    let power2: Function;
    let power3: Function;
    let power4: Function;
}
declare namespace ingenuity.Easing {
    class Elastic extends Phaser.Easing.Elastic {
    }
}
declare namespace ingenuity.Easing {
    class Exponential extends Phaser.Easing.Exponential {
    }
}
declare namespace ingenuity.Easing {
    class Linear extends Phaser.Easing.Linear {
    }
}
declare namespace ingenuity.Easing {
    class Quadratic extends Phaser.Easing.Quadratic {
    }
}
declare namespace ingenuity.Easing {
    class Quartic extends Phaser.Easing.Quartic {
    }
}
declare namespace ingenuity.Easing {
    class Quintic extends Phaser.Easing.Quintic {
    }
}
declare namespace ingenuity.Easing {
    class Sinusoidal extends Phaser.Easing.Sinusoidal {
    }
}
declare namespace ingenuity {
    interface IMainManifest extends IObject {
        mainManifest?: IManifest;
    }
    interface IManifest extends IObject {
        name: string;
        loadData: {
            key: string;
            url: string;
            type: string;
        };
    }
}
declare namespace ingenuity {
    let soundManager: any;
    let currentGame: Phaser.Game;
    let dispatcher: events.EventDispatcher;
    let stage: Phaser.Stage;
    let deviceEnv: deviceEnvironment.DeviceDetector;
    let resolution: string;
    let lang: string;
    let currencyISO: string;
    let defaultDecimalSeparator: string;
    let defaultThousandSeparator: string;
    let baseURL: string;
    let mainManifestURL: string;
    let cdn: boolean;
    let gameData: any;
    let assetsData: any;
    let configData: {
        [key: string]: string | number | boolean | any;
    };
    let soundData: any;
    let parserModel: any;
    let baseGameModel: any;
    let freeGameModel: any;
    let disableVisibilityChange: boolean;
    let roundPixels: boolean;
    let multiTexture: boolean;
    let enableDebug: boolean;
    let antialias: boolean;
    let failIfMajorPerformanceCaveat: boolean;
    let defaultRenderer: number;
    let resolutionConfig: IDeviceConfig;
}
declare namespace ingenuity.states {
    class BaseGameState extends State {
        init(...args: any[]): void;
    }
}
declare namespace ingenuity.ui {
    class Animation extends Phaser.Animation {
        constructor(game: Phaser.Game, parent: Phaser.Sprite, name: string, frameData: Phaser.FrameData, frames: number[] | string[], frameRate?: number, loop?: boolean);
    }
}
declare namespace ingenuity.ui {
    class BitmapData extends Phaser.BitmapData {
        constructor(key: string, width?: number, height?: number, skipPool?: boolean);
    }
}
declare namespace ingenuity.ui {
    class Point extends Phaser.Point {
        constructor(x?: number, y?: number);
    }
}
declare namespace ingenuity {
    interface ISpineData {
        x: number;
        y: number;
        id: string;
        image?: string;
        images?: string[];
        premultipliedAlpha?: boolean;
        anchorX?: number;
        anchorY?: number;
        regX?: number;
        regY?: number;
        scale?: number;
        type: string;
        parent?: string;
        rotation?: number;
        visible?: boolean;
        hitArea?: {
            x: number;
            y: number;
            type: string;
            w?: number;
            h?: number;
            d?: number;
        };
    }
}
