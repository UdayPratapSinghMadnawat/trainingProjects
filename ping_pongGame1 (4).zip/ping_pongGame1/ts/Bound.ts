namespace gamePingPong {

    export class Bound implements iRigidBodies {

        public x: number;
        public y: number;
        public height: number;
        public width: number;
        public stage: any;
        private graphics = new PIXI.Graphics();
        constructor(x: number, y: number, width: number, height: number, stage: any) {
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawimg();
        }
        private drawimg() {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;

        }
         moveTo(x: number, y: number) {

             
         }

    }
}