"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var gamePingPong;
(function (gamePingPong) {
    var APaddle = /** @class */ (function () {
        function APaddle(x, y, width, height, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawimg();
        }
        APaddle.prototype.drawimg = function () {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        APaddle.prototype.moveTo = function (x, y) {
            this.y = y;
            this.graphics.position.y += y;
        };
        return APaddle;
    }());
    gamePingPong.APaddle = APaddle;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var Ball = /** @class */ (function () {
        function Ball(x, y, radius, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = 2 * radius;
            this.width = 2 * radius;
            this.stage = stage;
            this.drawimg();
        }
        Ball.prototype.drawimg = function () {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawCircle(this.x, this.y, this.width / 2);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        Ball.prototype.moveTo = function (x, y) {
            this.x = x;
            this.y = y;
            this.graphics.position.x += x;
            this.graphics.position.y += y;
        };
        return Ball;
    }());
    gamePingPong.Ball = Ball;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var Bound = /** @class */ (function () {
        function Bound(x, y, width, height, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawimg();
        }
        Bound.prototype.drawimg = function () {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        Bound.prototype.moveTo = function (x, y) {
        };
        return Bound;
    }());
    gamePingPong.Bound = Bound;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var Collider = /** @class */ (function () {
        function Collider() {
        }
        Collider.prototype.isCollide = function (object1, object2, handler) {
            if (!(((object1.y + object1.height) < object2.y) ||
                ((object1.y + object1.height) > object2.y) ||
                ((object1.x + object1.width) < object2.x) ||
                ((object1.x + object1.width) > object2.x))) {
                handler();
            }
        };
        return Collider;
    }());
    gamePingPong.Collider = Collider;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var GameController = /** @class */ (function () {
        function GameController() {
            this.app = new PIXI.Application(window.innerWidth / 2, window.innerHeight / 2, { backgroundColor: 0x451542 });
            this.app.view.style.display = "block";
            this.app.view.style.marginLeft = window.innerWidth / 4 + "px";
            this.app.view.style.marginTop = innerHeight / 4 + "px";
            this.app.view.style.marginRight = innerWidth / 4 + "px";
            this.app.view.style.marginBottom = innerHeight / 4 + "px";
            document.body.appendChild(this.app.view);
            this.start();
            this.app.ticker.add(this.makeUpdation.bind(this));
        }
        GameController.prototype.start = function () { };
        GameController.prototype.makeUpdation = function (delta) { };
        return GameController;
    }());
    gamePingPong.GameController = GameController;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var Paddle = /** @class */ (function () {
        function Paddle(x, y, width, height, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawimg();
        }
        Paddle.prototype.drawimg = function () {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        return Paddle;
    }());
    gamePingPong.Paddle = Paddle;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    /// <reference path="Ball.ts" />
    var PingPongGameController = /** @class */ (function (_super) {
        __extends(PingPongGameController, _super);
        function PingPongGameController() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.moveVelocityX = 1;
            _this.moveVelocityY = 1;
            return _this;
        }
        PingPongGameController.prototype.start = function () {
            var sw = this.app.screen.width;
            var sh = this.app.screen.height;
            this.ball = new gamePingPong.Ball(sw / 2 + 10, sh / 60, sh / 60, this.app);
            this.boundTop = new gamePingPong.Bound(0, 0, sw, sh / 300, this.app);
            this.boundLeft = new gamePingPong.Bound(0, 0, sw / 400, sh, this.app);
            this.boundRight = new gamePingPong.Bound(sw, 0, -2, sh, this.app);
            this.boundBottom = new gamePingPong.Bound(0, sh, sw, -2, this.app);
            this.paddle1 = new gamePingPong.APaddle(sw / 80, sh / 60, sw / 80, sh / 4, this.app);
            this.paddle2 = new gamePingPong.APaddle(sw - sw / 40, sh / 60, sw / 80, sh / 4, this.app);
            this.collider = new gamePingPong.Collider();
        };
        PingPongGameController.prototype.makeUpdation = function (delta) {
            var _this = this;
            //move ball 
            moveBall();
            function moveBall() {
                _this.ball.moveTo(1, 1);
            }
            //move paddle 
            movePaddle();
            function movePaddle() {
                movePaddle1();
                movePaddle2();
                function movePaddle1() {
                    _this.paddle1.moveTo(_this.paddle1.x, _this.ball.y);
                }
                function movePaddle2() {
                    if (_this.paddle2.y < 0)
                        _this.paddle2.y = 0;
                    if (_this.paddle2.y > _this.app.screen.height)
                        _this.paddle2.y = _this.app.screen.height - _this.paddle2.height;
                    //_this.paddle2.moveTo(_this.paddle2.x,_this.app.renderer.plugins.interaction.mouse.global.y);
                }
            }
            // handle  collision 
            handleCollision();
            function handleCollision() {
                _this.collider.isCollide(_this.paddle1, _this.ball, function () {
                    _this.moveVelocityX *= -1;
                    _this.ball.moveTo(_this.moveVelocityX, _this.moveVelocityY);
                });
                _this.collider.isCollide(_this.boundBottom, _this.ball, function () {
                    _this.moveVelocityY *= -1;
                    _this.ball.moveTo(_this.moveVelocityX, _this.moveVelocityY);
                });
            }
            //update stage 
            updateStage();
            function updateStage() {
                _this.collider.isCollide(_this.paddle1, _this.ball, function () { });
            }
        };
        return PingPongGameController;
    }(gamePingPong.GameController));
    gamePingPong.PingPongGameController = PingPongGameController;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var VMainGame = /** @class */ (function () {
        function VMainGame() {
            this.gc = new gamePingPong.PingPongGameController();
        }
        return VMainGame;
    }());
    gamePingPong.VMainGame = VMainGame;
    var ob1 = new VMainGame();
})(gamePingPong || (gamePingPong = {}));
