///<reference path="../interfaces.ts" />
namespace ingenuity.game {
    export class BaseGameView extends slot.BaseGame.View {

    }
}
