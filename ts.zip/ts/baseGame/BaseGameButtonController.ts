namespace ingenuity.game {
    export class BaseGameButtonController extends slot.BaseGame.ButtonController {
        public onInfoPressUp(): void {
          //  debugger;
            if (loader.Loading.isStateLoaded(core.base.constants.loader.STAGE_INFO)) {
                dispatcher.fireEvent("HIDE_IN_GAME_LOADING");
                super.onInfoPressUp();
            } else {
                dispatcher.fireEvent("SHOW_IN_GAME_LOADING");
                dispatcher.fireEvent(events.EventConstants.LOAD_STATE, core.base.constants.loader.STAGE_INFO);
                dispatcher.on(events.EventConstants.INFO_ASSETS_LOADED, this.onInfoPressUp, this, true, null, 1);
            }
        }
    }
}
