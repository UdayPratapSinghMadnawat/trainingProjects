namespace ingenuity.game {
    export class GameSlotLogic extends slot.Logic.SlotGameLogic {
        protected subscribeEvents(): void {
            super.subscribeEvents();
            dispatcher.on("BONUS_INTRO_HIDE_COMPLETE", this.onBonusIntroHide, this);
        }
        protected unsubscribeEvents(): void {
            super.unsubscribeEvents();
            dispatcher.off("BONUS_INTRO_HIDE_COMPLETE", this.onBonusIntroHide, this);
        }
        private onBonusIntroHide(e?: IEvent): void {
            currentGame.state.start("bonus", false, false);
        }

        protected onBonusPresentation(): void {
            if (this.model.isBonus) {
                this.unSubscribeReelPanelControllerEvents();
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSUBSCRIBE_BASEGAME_REELPANEL_EVENTS);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INTRO_SHOW);
            } else {
                this.showNextWinPresentation();
            }
        }
    }
}
