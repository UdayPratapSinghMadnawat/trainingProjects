///<reference path="interfaces.ts" />
///<reference path="parser/GameParserModel.ts" />
///<reference path="parser/GameParser.ts" />

namespace ingenuity.game {
    const Percent100: number = 100;
    export class MainGame extends core.MainGame {
        constructor(mainDiv: string, deviceConfig: IDeviceConfig, loadStateObject: IGameStates) {
            super(mainDiv, deviceConfig, loadStateObject);
            this.subscribeEvents();

            dispatcher.fireEvent(platform.EventConstants.ENVIRONMENT_READY);
        }

        private subscribeEvents(): void {
            dispatcher.on(platform.EventConstants.ENVIRONMENT_READY, this.enviornmentReady, this);
            // dispatcher.on(platform.EventConstants.FREE_GAME_STARTED, this.startFreeGame, this);
            // dispatcher.on(platform.EventConstants.ASSETS_LOADED, this.onAssetsLoaded, this);
            // dispatcher.on(platform.EventConstants.OPEN_GAME_PROCESSED, this.openGame, this);
            dispatcher.on("BROKEN_BONUS_GAME", this.brokenBonusGame, this);
            dispatcher.on(platform.EventConstants.BROKEN_FREE_GAME, this.brokenFreeGame, this);
            // dispatcher.on(slot.slotConstants.SlotEventConstants.GAME_RESIZE, this.resize, this);
            dispatcher.on(events.EventConstants.UPDATE_LOADING_PROGRESS, this.onLoadingProgress, this);
            dispatcher.on("SHOW_IN_GAME_LOADING", this.showPostloader, this);
            dispatcher.on("HIDE_IN_GAME_LOADING", this.hidePostloader, this);
            dispatcher.on(platform.EventConstants.HIDE_LOADER, this.onHideLoader, this);
            window.addEventListener("error", (e: ErrorEvent) => {
                alert("An Error has occured. Please reload this page. For information check console.");
                console.error(`Error ::  ${e.message} at line ${e.lineno}`);
            });
        }

        private enviornmentReady(e: IEvent): void {
            this.setGameStage(utils.getElement("#gameCanvas"), () => {
                this.registerStates(this.loadStateObj);
                currentGame.input.mspointer.capture = false;
                if (deviceEnv.os.toLowerCase() === deviceEnvironment.constants.OS_NAMES.ANDROID) {
                    currentGame.input.mouse.enabled = false;
                }
            });
        }
        private onLoadingProgress(e: IEvent): void {
            if (e.data >= Percent100) {
                e.remove();
            }
            utils.getElement("#progressDynamic").style.width = e.data + "%";
        }

        private onHideLoader(e: IEvent): void {
            utils.getElement("#loader").style.display = "none";
        }
        private createBackground(): void {
            const view: BackgroundView = new game.BackgroundView(assetsData.getJSON("main").backgrounds);
        }
        private registerServerClasses(): void {
            configData.pathGenericServer = utils.getParams("serverPath") || "http://localhost:9000";
            parserModel = new GameParserModel();
            new platform.generic.ServerComm(parserModel);
            new GameParser(parserModel);
        }
        protected onAssetsLoaded(e: IEvent): void {
            assetsData = currentGame.cache;
            currentGame.scale.scaleMode = Phaser.ScaleManager.RESIZE;
            currentGame.stage.disableVisibilityChange = true;
            currentGame.stage.smoothed = true;

            this.createBackground();
            this.registerServerClasses();
            currentGame.state.start(slot.slotConstants.SlotConstants.baseGameState, false, false);
        }

        private brokenFreeGame(evt?: IEvent): void {
            if (loader.Loading.isStateLoaded(slot.slotConstants.SlotConstants.freeGameState)) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INITIALIZE_SLOT_LOGIC);
                currentGame.state.start(slot.slotConstants.SlotConstants.freeGameState, false, false, currentGame);
                dispatcher.fireEvent(platform.EventConstants.HIDE_LOADER);
            } else {
                dispatcher.on(events.EventConstants.FREEGAME_ASSETS_LOADED, this.brokenFreeGame, this);
                dispatcher.fireEvent(events.EventConstants.PRIORITIZE_LOADING_STAGE, core.base.constants.loader.STAGE_FREE_GAME);
            }
        }
        private brokenBonusGame(evt?: IEvent): void {
            if (loader.Loading.isStateLoaded(core.base.constants.loader.STAGE_BONUS)) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INITIALIZE_SLOT_LOGIC);
                currentGame.state.start("bonus", false, false, currentGame);
                dispatcher.fireEvent(platform.EventConstants.HIDE_LOADER);
            } else {
                dispatcher.on(events.EventConstants.BONUS_ASSETS_LOADED, this.brokenBonusGame, this);
                dispatcher.fireEvent(events.EventConstants.PRIORITIZE_LOADING_STAGE, core.base.constants.loader.STAGE_BONUS);
            }
        }
        private showPostloader(): void {
            document.getElementById("postloader").style.display = "block";
        }
        /**
         * Function called to show preloader in case of lazy loading
         */
        private hidePostloader(): void {
            document.getElementById("postloader").style.display = "none";
        }
    }
}
