/// <reference path ="../interfaces.ts"/>
namespace ingenuity.game {
    const halfConverter: number = 0.5;
    export class BackgroundView extends ui.BaseView {
        protected resize(e?: any): void {
            const { gameWidth, gameHeight }: IDeviceEnvironmentUpdate = e.data;
            this.pivot.set(gameWidth * halfConverter, gameHeight * halfConverter);
            this.x = innerWidth * halfConverter;
            this.y = innerHeight * halfConverter;
           // this.scale.set((e.data as IDeviceEnvironmentUpdate).maxScale);
        }
    }
}
