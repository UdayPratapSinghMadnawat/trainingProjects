namespace ingenuity.game {
    export class FreeGameController extends slot.FreeGame.FreeGameController {
        protected model: FreeGameModel;
        protected initializeButtonController(): void {
            this.buttonController = new FreeGameButtonController(this.view, this.model);
        }
    }
}
