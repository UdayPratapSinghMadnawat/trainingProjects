namespace ingenuity.game {
    const delayTime: number = 1000;
    export class FreeGameButtonController extends slot.FreeGame.ButtonController {
        constructor(view: slot.FreeGame.View, model: FreeGameModel) {
            super(view, model);
        //  debugger;
            utils.delayedCall("freeGameStartTimer", delayTime, this.onSkipPressUp, this);
        }

        protected onSkipPressUp(): void {
        //  debugger;
            utils.killDelayedCall("freeGameStartTimer");
            super.onSkipPressUp(this.skipBtn);
        }
    }
}
