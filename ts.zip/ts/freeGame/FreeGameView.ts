namespace ingenuity.game {
    export class FreeGameView extends slot.FreeGame.View {

    }
}
