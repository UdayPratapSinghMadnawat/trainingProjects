/// <reference path="../tsd/slot/slot-core.d.ts" />
