///<reference path="states/BaseGameState.ts"/>
///<reference path="states/FreeGameState.ts"/>
///<reference path="states/BonusGameState.ts"/>
///<reference path="baseGame/BaseGameButtonController.ts"/>
///<reference path="freeGame/FreeGameButtonController.ts"/>
///<reference path="SlotLogic/GameSlotLogic.ts"/>
///<reference path="MainGame.ts"/>
namespace ingenuity {
    mainManifestURL = "manifest/mainManifest.json";
    baseURL = "res/";
    lang = utils.getParams("lang") || lang;
    currencyISO = utils.getParams("currency") || currencyISO;

    configData.maxLines = 20;

    core.constructors.slot.BaseButtonController = game.BaseGameButtonController;
    core.constructors.slot.FreeButtonController = game.FreeGameButtonController;
    core.constructors.slot.SlotLogic = game.GameSlotLogic;

    const gameContainerDiv: string = "gameContainer";
    const stateObj: IGameStates = {
        load: new loader.Loading(),
        [slot.slotConstants.SlotConstants.baseGameState]: new game.BaseGameState(),
        [slot.slotConstants.SlotConstants.freeGameState]: new game.FreeGameState(),
        bonus: new game.BonusGameState(),
    };

    const deviceConfig: IDeviceConfig = {
        desktop: {
            width: 1280,
            height: 720
        },
        hd: {
            width: 1280,
            height: 720
        },
        sd: {
            width: 1280,
            height: 720
        },
        ld: {
            width: 1280,
            height: 720
        },
        mobilePortrait: {
            width: 960,
            height: 320
        }
    };

    utils.LoadFonts(["MyriadPro-Bold", "MyriadPro-BoldCond", "MyriadPro"]);

    const mainGame: game.MainGame = new game.MainGame(gameContainerDiv, deviceConfig, stateObj);
}
