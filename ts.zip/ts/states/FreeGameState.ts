///<reference path="../freeGame/FreeGameView.ts" />
///<reference path="../freeGame/FreeGameModel.ts" />
namespace ingenuity.game {

    export class FreeGameState extends slot.FreegameState {
        private fgControler: slot.FreeGame.FreeGameController;

        public init(): void {
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CLEAR_DATA);
            super.init();
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INITIALIZE_ALL_CONTROLLERS_FG);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUBSCRIBE_EVENTS_ON_REEL_START);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUBSCRIBE_EVENTS_ON_REEL_START_FG);
        }

        protected initializeModel(): void {
            freeGameModel = this.model = new FreeGameModel(parserModel);
        }

        protected initializeView(): void {
            this.view = new slot.FreeGame.View(assetsData.getJSON("main").freeGame);
            currentGame.stage.addChild(this.view);
        }
        protected initializeReelPanel(): void {
            this.reelModel = new core.constructors.reelPanel.ReelModel();
            this.reelModel.json = assetsData.getJSON("main").freeGame.reels = assetsData.getJSON("main").baseGame.reels;
            this.reelPanel = new core.constructors.reelPanel.ReelPanel(currentGame, this.reelModel);
            this.view.setReelView(this.reelPanel, 6, "reelsContainer");
        }
        protected initializeWinReelPresentation(): void {
            super.initializeWinReelPresentation();
            this.view.setWinReelView(this.winReelpanel, 7, "reelsContainer");
        }
        protected initializePayline(): void {
            this.paylineView = new core.constructors.reelPanel.PaylineView(assetsData.getJSON("main").paylineInfo, this.reelModel,
                this.view.getContainerByID("reelsContainer"));
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_CREATE_WINBOX);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_CREATE_PAYLINE_SPAGGITTE);
            this.view.setPaylineView(this.paylineView, 8, "reelsContainer");
        }

        protected setReelPanelLayering(): void {
            this.paylineView.position.set(-100, -20);
            if (assetsData.getJSON("main").baseGame.reels.indexing) {
                for (const i of assetsData.getJSON("main").baseGame.reels.indexing) {
                    this.view.getContainerByID("reelsContainer").forEach((comp: ui.Container) => {
                        if (comp.name === i) {
                            this.view.getContainerByID("reelsContainer").addChild(comp);
                        }
                    }, this);
                }
            }
        }
        protected initializeController(): void {
            this.freeGameController = new FreeGameController(this.view, this.model, assetsData.getJSON("main"), assetsData);
        }

        public shutdown(): void {
            if (this.model.getFreeSpinsRemaining() > 0) {
                return;
            }
            // dispatcher.fireEvent(EventConstants.ADD_BIG_WIN_TO_BASE_GAME);
            this.view.visible = false;
            super.shutdown();
            // this.bgView.visible = false;
            // (this.bgView) && this.bgView.destroy();
            // this.bgView = null;
            // this.bgController = null;
        }
    }
}
