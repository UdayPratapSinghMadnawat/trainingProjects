///<reference path="../bonusGame/BonusGameView.ts" />
///<reference path="../bonusGame/BonusGameModel.ts" />
namespace ingenuity.game {
    export class BonusGameState extends slot.BasegameState {
        public init(): void {
            super.init();
            dispatcher.on(platform.EventConstants.OPEN_GAME_PROCESSED, () => {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INITIALIZE_ALL_CONTROLLERS_BG);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INITIALIZE_SLOT_LOGIC);
                dispatcher.fireEvent(platform.EventConstants.HIDE_LOADER);
            });
            dispatcher.fireEvent(platform.EventConstants.INIT_GAME);
        }
        protected initializeView(): void {
            const bonusViewJson: any = assetsData.getJSON("main").bonusGame;
            this.view = new BonusGameView(bonusViewJson);
            currentGame.stage.addChild(this.view);
        }
        protected initializeModel(): void {
            baseGameModel = this.model = new BaseGameModel(parserModel);
        }
        protected initializeController(): void {
            this.basecontroller = new slot.BaseGame.BaseController(this.view, this.model, assetsData.getJSON("main"), assetsData);
        }
        protected initializeReelPanel(): void {
            this.reelModel = new core.constructors.reelPanel.ReelModel();
            this.reelModel.json = assetsData.getJSON("main").baseGame.reels;
            this.reelPanel = new core.constructors.reelPanel.ReelPanel(ingenuity.currentGame, this.reelModel);
            this.view.setReelView(this.reelPanel, 0, "reelsContainer");
        }
        protected initializePayline(): void {
            this.paylineView = new core.constructors.reelPanel.PaylineView(assetsData.getJSON("main").paylineInfo, this.reelModel,
                this.view.getContainerByID("reelsContainer"));
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CREATE_WINBOX);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CREATE_PAYLINE_SPAGGITTE);
            this.view.setPaylineView(this.paylineView, 0, "reelsContainer");
        }
        protected setReelPanelLayering(): void {
            this.paylineView.position.set(-100, -20);
            if (assetsData.getJSON("main").baseGame.reels.indexing) {
                for (const i of assetsData.getJSON("main").baseGame.reels.indexing) {
                    this.view.getContainerByID("reelsContainer").forEach((comp: ui.Container) => {
                        if (comp.name === i) {
                            this.view.getContainerByID("reelsContainer").addChild(comp);
                        }
                    }, this);
                }
            }
        }
        //  protected initializeBigWinPresentation(): void {     }
        protected initializePaytable(): void {
            if (loader.Loading.isStateLoaded(core.base.constants.loader.STAGE_INFO)) {
                const paytableView: PaytableView = new PaytableView(assetsData.getJSON("main").paytable);
                new PaytableController(paytableView, this.model);
                currentGame.stage.addChild(paytableView);
            } else {
                dispatcher.on(events.EventConstants.INFO_ASSETS_LOADED, this.initializePaytable, this, false, null, 2);
            }
        }
        protected initializeIntroOutro(): void {
            const introOutroView: slot.IntroOutro.View = new slot.IntroOutro.View(assetsData.getJSON("main").IntroOutro);
            new IntroOutroController(introOutroView, parserModel);
            currentGame.stage.addChild(introOutroView);
        }

    }
}
