namespace ingenuity.game {
    export class PaytableController {
        private backButton: ui.ButtonBase;
        private nextButton: ui.ButtonBase;
        private prevButton: ui.ButtonBase;

        private pageContainer: ui.Container;
        constructor(private view: PaytableView, private model: slot.BaseGame.Model) {
            this.pageContainer = view.getContainerByID("pagesContainer");
            this.pageContainer.cursor = this.pageContainer.getChildAt(0);

            this.backButton = view.getButtonById("info_back_button") as ui.ButtonBase;
            this.nextButton = view.getButtonById("info_next_button") as ui.ButtonBase;
            this.prevButton = view.getButtonById("info_prev_button") as ui.ButtonBase;

            this.subscribeEvents();
        }

        private subscribeEvents(): void {
            dispatcher.on(events.EventConstants.SHOW_PAYTABLE, () => {
                this.view.visible = true;
            }, this);
            dispatcher.on("HIDE_PAYTABLE", () => {
                this.view.visible = false;
            }, this);
            this.backButton && this.backButton.on(ui.ButtonBase.UP, this.onBackBtnPressUp, this);
            this.nextButton && this.nextButton.on(ui.ButtonBase.UP, this.onNextPressUp, this);
            this.prevButton && this.prevButton.on(ui.ButtonBase.UP, this.onPrevPressUp, this);
        }

        private onBackBtnPressUp(): void {
            this.destroy();
            dispatcher.fireEvent(events.EventConstants.REMOVE_STATE_CACHE, core.base.constants.loader.STAGE_INFO);
            dispatcher.fireEvent("HIDE_PAYTABLE");
        }

        private onNextPressUp(): void {
            if (this.pageContainer.cursorIndex < this.pageContainer.length - 1) {
                this.pageContainer.cursor.visible = false;
                this.pageContainer.next().visible = true;
            }
            this.checkButtonState();
        }

        private onPrevPressUp(): void {
            if (this.pageContainer.cursorIndex > 0) {
                this.pageContainer.cursor.visible = false;
                this.pageContainer.previous().visible = true;
            }
            this.checkButtonState();
        }
        private checkButtonState(): void {
            if (this.pageContainer.cursorIndex === 0) {
                this.prevButton.disableAndTint();
            } else {
                this.prevButton.enableAndTint();
            }
            if (this.pageContainer.cursorIndex === this.pageContainer.length - 1) {
                this.nextButton.disableAndTint();
            } else {
                this.nextButton.enableAndTint();
            }
        }

        public destroy(): void {
            this.backButton && this.backButton.off(ui.ButtonBase.UP, this.onBackBtnPressUp);
            this.nextButton && this.nextButton.off(ui.ButtonBase.UP, this.onNextPressUp);
            this.prevButton && this.prevButton.off(ui.ButtonBase.UP, this.onPrevPressUp);
            dispatcher.offForScope(events.EventConstants.SHOW_PAYTABLE, this);
        }

    }
}
