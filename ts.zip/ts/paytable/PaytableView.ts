namespace ingenuity.game {
    export class PaytableView extends ui.BaseView {
        constructor(json: IObject) {
            super(json);
            this.visible = false;
        }
    }
}
