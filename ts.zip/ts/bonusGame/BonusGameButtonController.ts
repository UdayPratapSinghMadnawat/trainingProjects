namespace ingenuity.game{
    const delayTime: number = 1000;
    export class BonusGameButtonController extends slot.BaseGame.ButtonController{

    constructor(view: slot.BaseGame.View, model: BaseGameModel){
        super(view, model);
        //  debugger;
        utils.delayedCall("freeGameStartTimer", delayTime , this.onSkipPressUp, this);
    }

    protected onSkipPressUp(): void {
        //  debugger;
        utils.killDelayedCall("bousGameStartTimer");
        super.onSkipPressUp(this.skipBtn);
    }
}

}
