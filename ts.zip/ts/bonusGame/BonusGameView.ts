namespace ingenuity.game {
    export class BonusGameView extends slot.BaseGame.View {

    }
}
