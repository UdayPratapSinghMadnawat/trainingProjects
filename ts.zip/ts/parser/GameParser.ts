namespace ingenuity.game {
    export class GameParser extends platform.generic.Parser {
        protected model: GameParserModel;
        protected onInitResponseReceived(evt?: IEvent): void {
            const data = evt.data;
            if (data.game.action === "refresh") {
                if (data.game.status === "close") {
                    this.parseInitResponse(data);
                } else {
                    this.parseBrokenResponse(data);
                }
            } else {
                throw new Error("Expecting Game Refresh Response !!");
            }
        }
        protected onBetResponseReceived(evt?: IEvent): void {
            const data: IResponseInit = evt.data;
            if (data.game.nextAction === "bonus") {
                this.parseBetResponse(data);
                this.model.isBonus = true;
                this.model.bonusValues = data.bonus.options;
            } else {
                super.onBetResponseReceived(evt);
            }
        }
        protected parseBrokenResponse(data: IResponseInit): void {
            if (data.game.nextAction === "freespin") {
                this.processConfig(data.config);
                this.processGame(data.game);
                this.processSlot(data.spinResponse);
                this.processFreeSpinsData(data.freespin);
                dispatcher.fireEvent(platform.EventConstants.BROKEN_FREE_GAME);
            } else if (data.game.nextAction === "bonus") {
                this.processConfig(data.config);
                this.processGame(data.game);
                this.processSlot(data.spinResponse);
                this.model.isBonus = true;
                this.model.bonusValues = data.bonus.options;
                dispatcher.fireEvent("BROKEN_BONUS_GAME");
            }
        }
    }
    interface IResponseInit extends platform.generic.IResponseInit {
        bonus?: {
            offsets: number[];
            options: number[];
        };
    }
}
