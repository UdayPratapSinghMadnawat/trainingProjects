namespace ingenuity.game {
    export class GameParserModel extends platform.generic.Model {
        private isBonusWon: boolean;
        private bonusOptions: number[];
        public set isBonus(value: boolean) {
            this.isBonusWon = value;
        }

        public get isBonus(): boolean {
            return this.isBonusWon;
        }

        public set bonusValues(value: number[]) {
            this.bonusOptions = value;
        }

        public get bonusValues(): number[] {
            return this.bonusOptions;
        }
    }
}
