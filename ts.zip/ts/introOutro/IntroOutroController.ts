namespace ingenuity.game {
    export class IntroOutroController extends slot.IntroOutro.Controller {
        protected IntroLabel1: ui.Label;
        protected IntroLabel2: ui.Label;
        protected IntroLabel3: ui.Label;
        protected IntroSubContainer: ui.Container;
        constructor(protected view: slot.IntroOutro.View, private model: GameParserModel) {
            super(view);
            this.IntroLabel3 = this.view.getLabelById("freeSpinNumber") as ui.Label;
            this.IntroSubContainer = this.view.getContainerByID("freeGameIntro");
        }

        protected onIntroShow(): void {
            this.IntroSubContainer.visible = true;
            super.onIntroShow();
            if (this.model.isBonus) {
                this.IntroLabel3.setText("Bonus");
            } else {
                this.IntroLabel3.setText(this.model.getFreeSpinNum() + "");
            }
            const introHideTime: number = 2000;
            utils.delayedCall("hideIntroPopup", introHideTime, this.onIntroHide, this);
        }
        protected onIntroHide(): void {
            if (this.model.isBonus) {
                if (loader.Loading.isStateLoaded(core.base.constants.loader.STAGE_BONUS)) {
                    dispatcher.fireEvent("HIDE_IN_GAME_LOADING");
                    this.IntroOutroContainer && (this.IntroOutroContainer.visible = false);
                    this.IntroContainer && (this.IntroContainer.visible = false);
                    dispatcher.fireEvent("BONUS_INTRO_HIDE_COMPLETE");
                } else {
                    dispatcher.fireEvent("SHOW_IN_GAME_LOADING");
                    dispatcher.fireEvent(events.EventConstants.LOAD_STATE, core.base.constants.loader.STAGE_BONUS.toLowerCase());
                    dispatcher.on(events.EventConstants.BONUS_ASSETS_LOADED, this.onIntroHide, this, true, null, 1);
                }
            } else {
                if (loader.Loading.isStateLoaded(core.base.constants.loader.STAGE_FREE_GAME)) {
                    dispatcher.fireEvent("HIDE_IN_GAME_LOADING");
                    super.onIntroHide();
                } else {
                    dispatcher.fireEvent("SHOW_IN_GAME_LOADING");
                    dispatcher.fireEvent(events.EventConstants.LOAD_STATE, core.base.constants.loader.STAGE_FREE_GAME.toLowerCase());
                    dispatcher.on(events.EventConstants.FREEGAME_ASSETS_LOADED, this.onIntroHide, this, true, null, 1);
                }
            }
        }
    }
}
