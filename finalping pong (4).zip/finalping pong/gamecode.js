"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var gamePingPong;
(function (gamePingPong) {
    var APaddle = /** @class */ (function () {
        function APaddle(x, y, width, height, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawimg();
        }
        APaddle.prototype.drawimg = function () {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        APaddle.prototype.moveTo = function (x, y) {
            this.y = y;
            this.graphics.position.y += y;
        };
        return APaddle;
    }());
    gamePingPong.APaddle = APaddle;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var Ball = /** @class */ (function () {
        function Ball(x, y, radius, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = 2 * radius;
            this.width = 2 * radius;
            this.stage = stage;
            this.drawimg();
        }
        Ball.prototype.drawimg = function () {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawCircle(this.x, this.y, this.width / 2);
            this.graphics.endFill();
            this.graphics.pivot.set(-(this.graphics.height / 2), -(this.graphics.height / 2));
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        Ball.prototype.moveTo = function (x, y) {
            this.x += x;
            this.y += y;
            this.graphics.position.x += x;
            this.graphics.position.y += y;
        };
        return Ball;
    }());
    gamePingPong.Ball = Ball;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var Bound = /** @class */ (function () {
        function Bound(x, y, width, height, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawimg();
        }
        Bound.prototype.drawimg = function () {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            //   this.graphics.interactive = true;
            return this;
        };
        Bound.prototype.moveTo = function (x, y) {
        };
        return Bound;
    }());
    gamePingPong.Bound = Bound;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var Collider = /** @class */ (function () {
        function Collider() {
        }
        Collider.prototype.isCollide = function (object1, object2) {
            if ((((object1.y + object1.height) > object2.y) &&
                ((object2.y + object2.height) > object1.y) &&
                ((object1.x + object1.width) > object2.x) &&
                ((object2.x + object2.width) > object1.x))) {
                return true;
            }
        };
        return Collider;
    }());
    gamePingPong.Collider = Collider;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var GameController = /** @class */ (function () {
        function GameController() {
            this.app = new PIXI.Application(window.innerWidth / 2, window.innerHeight / 2, { backgroundColor: 0x451542 });
            this.app.view.style.display = "block";
            this.app.view.style.marginLeft = window.innerWidth / 4 + "px";
            this.app.view.style.marginTop = innerHeight / 4 + "px";
            this.app.view.style.marginRight = innerWidth / 4 + "px";
            this.app.view.style.marginBottom = innerHeight / 4 + "px";
            document.body.appendChild(this.app.view);
            this.start();
            this.app.ticker.add(this.makeUpdation.bind(this));
        }
        GameController.prototype.start = function () { };
        GameController.prototype.makeUpdation = function (delta) { };
        return GameController;
    }());
    gamePingPong.GameController = GameController;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    /// <reference path="Ball.ts" />
    var PingPongGameController = /** @class */ (function (_super) {
        __extends(PingPongGameController, _super);
        function PingPongGameController() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.moveVelocityX = 2;
            _this.moveVelocityY = 2;
            return _this;
        }
        PingPongGameController.prototype.start = function () {
            var sw = this.app.screen.width;
            var sh = this.app.screen.height;
            this.ball = new gamePingPong.Ball(sw / 2, sh / 6, sh / 60, this.app);
            this.boundTop = new gamePingPong.Bound(0, 0, sw, sh / 300, this.app);
            this.boundLeft = new gamePingPong.Bound(0, 0, sw / 400, sh, this.app);
            this.boundRight = new gamePingPong.Bound(sw - 2, 0, 2, sh, this.app);
            this.boundBottom = new gamePingPong.Bound(0, sh - 2, sw, 2, this.app);
            this.paddle1 = new gamePingPong.APaddle(sw / 80, sh / 60, sw / 80, sh / 4, this.app);
            this.paddle2 = new gamePingPong.APaddle(sw - sw / 40, sh / 60, sw / 80, sh / 4, this.app);
            this.collider = new gamePingPong.Collider();
        };
        PingPongGameController.prototype.makeUpdation = function (delta) {
            var _this = this;
            //move ball 
            moveBall();
            function moveBall() {
                _this.ball.moveTo(_this.moveVelocityX, _this.moveVelocityY);
            }
            //move paddle 
            movePaddle();
            function movePaddle() {
                movePaddle1();
                movePaddle2();
                function movePaddle1() {
                    _this.paddle1.moveTo(_this.paddle1.x, _this.moveVelocityY);
                }
                function movePaddle2() {
                    var x1 = _this.app.renderer.plugins.interaction.mouse.global.x;
                    var y1 = _this.app.renderer.plugins.interaction.mouse.global.y;
                    if (y1 < 0)
                        y1 = 0;
                    if (y1 > _this.app.screen.height)
                        y1 = _this.app.screen.height;
                    _this.paddle2.y = y1;
                    _this.paddle2.graphics.position.y = y1 - _this.paddle2.height / 2;
                    // _this.paddle2.moveTo(_this.paddle2.x, y1-_this.paddle2.height / 2);
                }
            }
            // handle  collision 
            handleCollision();
            function handleCollision() {
                console.log(_this.collider.isCollide(_this.paddle1, _this.ball));
                if (_this.collider.isCollide(_this.paddle1, _this.ball))
                    _this.moveVelocityX *= -1;
                if (_this.collider.isCollide(_this.paddle2, _this.ball))
                    _this.moveVelocityX *= -1;
                if (_this.collider.isCollide(_this.boundBottom, _this.ball))
                    _this.moveVelocityY *= -1;
                if (_this.collider.isCollide(_this.boundLeft, _this.ball))
                    _this.moveVelocityX *= -1;
                if (_this.collider.isCollide(_this.boundTop, _this.ball))
                    _this.moveVelocityY *= -1;
                if (_this.collider.isCollide(_this.boundRight, _this.ball))
                    _this.moveVelocityX *= -1;
            }
            //update stage 
            updateStage();
            function updateStage() {
                //_this.collider.isCollide(_this.paddle1,_this.ball,function(){})
            }
        };
        return PingPongGameController;
    }(gamePingPong.GameController));
    gamePingPong.PingPongGameController = PingPongGameController;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var VMainGame = /** @class */ (function () {
        function VMainGame() {
            this.gc = new gamePingPong.PingPongGameController();
        }
        return VMainGame;
    }());
    gamePingPong.VMainGame = VMainGame;
    var ob1 = new VMainGame();
})(gamePingPong || (gamePingPong = {}));
