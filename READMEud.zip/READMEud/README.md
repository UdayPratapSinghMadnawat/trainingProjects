# Template
> Version 2.1.4
loading issues on samsung native browser, post loading of spines and sounds, delete cache, 2 reel strips spinning, spine pause/resume

> Version 1.3.4

> This is generic template with a generic server, the development team should take this as a base for their template.

> Please make changes in the grunt files as required by your environment.

## How to install

>Export the tag to a director which will be called as the root.

>Open command prompt at root and run ```npm install```

>Once npm is install run ```npm run build```

>Once build process is over.

>change to the build directory

## Changelog

### v1.3.4

* Fixed issues

### v1.3.3

* Fixed issues

### v1.3.2

* Fixed issues

### v1.3.1

* Fixed issues

### v1.3.0

* Fixed issues
* added cacheAsBitmap to labels and graphics

### v1.2.0

* updated phaser to 2.10.6.
* Added support for multi texture loading to GPU.

### v1.1.0

* Code Fixes.
* Added support of Video
* Added Features
  * Free Game Retrigger
  * Random Wild

### v1.0.0

* Added portrait mode.
* Added Advanced Button.
* Added Label states in the basic button
* Animated Paylines
* Animated Winboxes
* Draw Payline Support

### v0.1.4

* Fixed QA issues.

### v0.1.3

* Fixed QA issues.

### v0.1.2

* Fixed issues related to symbol spine.

## Known Issues

1. Dynamic font will be blurred on high DPI devices like Samsung S6 and above. 
