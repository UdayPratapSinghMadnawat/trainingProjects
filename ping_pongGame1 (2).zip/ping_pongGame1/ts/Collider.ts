namespace gamePingPong {
export class Collider {
public isCollide(object1: iRigidBodies, object2: iRigidBodies, handler:any) {
    if(!(
        ((object1.y + object1.height)< object2.y )||
        ((object1.y + object1.height)> object2.y)||
        ((object1.x + object1.width) < object2.x) ||
        ((object1.x + object1.width)> object2.x)  ) ) {
    
    
        handler() ;
        }
    }  
    


}
}