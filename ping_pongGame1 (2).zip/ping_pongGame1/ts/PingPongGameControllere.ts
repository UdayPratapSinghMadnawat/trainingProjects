namespace gamePingPong {
     export class PingPongGameController extends GameController {
         collider:Collider;
         app: PIXI.Application;
         paddle1: APaddle | undefined;
         paddle2: APaddle | undefined;
         boundTop: Bound | undefined;
         boundRight: Bound | undefined;
         boundLeft: Bound | undefined;
         boundBottom: Bound | undefined;
         ball: Ball | undefined;

constructor() {
    super();
    this.app = new PIXI.Application(800, 600, { backgroundColor: 0x451542 });
    this.app.view.style.display="block";
    this.app.view.style.marginLeft="560px";
    this.app.view.style.marginTop="164px";
    document.body.appendChild(this.app.view);
    this.collider = new Collider();
    this.start();
    }
start() {

    this.ball = new Ball(450, 10, 10, this.app);
    this.boundTop = new Bound(0, 0, 800, 2, this.app);
    this.boundLeft = new Bound(0, 0, 2, 600, this.app);
    this.boundRight = new Bound(800, 0, -2, 600, this.app);
    this.boundBottom = new Bound(0, 600, 800, -2, this.app);
    this.paddle1 = new APaddle(10, 10, 10, 100, this.app);
    this.paddle2 = new APaddle(780, 10, 10, 100, this.app);

}

    }
}