
namespace gamePingPong {
export class VMainGame {
  gc: PingPongGameController;

 
 
  constructor() {
    
           
    this.gc = new PingPongGameController();        
        
            
            

  }
}

var ob1 = new VMainGame();
}