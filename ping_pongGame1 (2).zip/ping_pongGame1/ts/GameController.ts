namespace gamePingPong {
    export class GameController {



        
        public start(){}

        public makeUpdation() { }



    }
}