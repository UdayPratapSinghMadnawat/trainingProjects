namespace gamePingPong {

    export class Ball implements iRigidBodies {

        x: number;
        y: number;
        height: number;
        width: number;
        stage: any;
        graphics = new PIXI.Graphics();
        constructor(x: number, y: number, radius: number ,stage: any) {
            this.x = x;
            this.y = y;
            this.height = 2*radius;
            this.width = 2*radius;
            this.stage = stage;
            this.drawimg();
        }
        private drawimg() {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawCircle(this.x, this.y, this.width/2);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            
            return this;

        }
        // moveTo(x: number, y: number) {
        //     this.graphics.position.x = x;
        //     this.graphics.position.y = y;

        // }

    }
}