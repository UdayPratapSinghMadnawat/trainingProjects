"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var gamePingPong;
(function (gamePingPong) {
    var APaddle = /** @class */ (function () {
        function APaddle(x, y, width, height, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawimg();
        }
        APaddle.prototype.drawimg = function () {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        return APaddle;
    }());
    gamePingPong.APaddle = APaddle;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var Ball = /** @class */ (function () {
        function Ball(x, y, radius, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = 2 * radius;
            this.width = 2 * radius;
            this.stage = stage;
            this.drawimg();
        }
        Ball.prototype.drawimg = function () {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawCircle(this.x, this.y, this.width / 2);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        return Ball;
    }());
    gamePingPong.Ball = Ball;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var Bound = /** @class */ (function () {
        function Bound(x, y, width, height, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawimg();
        }
        Bound.prototype.drawimg = function () {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        return Bound;
    }());
    gamePingPong.Bound = Bound;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var Collider = /** @class */ (function () {
        function Collider() {
        }
        Collider.prototype.isCollide = function (object1, object2, handler) {
            if (!(((object1.y + object1.height) < object2.y) ||
                ((object1.y + object1.height) > object2.y) ||
                ((object1.x + object1.width) < object2.x) ||
                ((object1.x + object1.width) > object2.x))) {
                handler();
            }
        };
        return Collider;
    }());
    gamePingPong.Collider = Collider;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var GameController = /** @class */ (function () {
        function GameController() {
        }
        GameController.prototype.start = function () { };
        GameController.prototype.makeUpdation = function () { };
        return GameController;
    }());
    gamePingPong.GameController = GameController;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var Paddle = /** @class */ (function () {
        function Paddle(x, y, width, height, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = height;
            this.width = width;
            this.stage = stage;
            this.drawimg();
        }
        Paddle.prototype.drawimg = function () {
            this.graphics.beginFill(0x11dd22);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
            this.graphics.interactive = true;
            return this;
        };
        return Paddle;
    }());
    gamePingPong.Paddle = Paddle;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var PingPongGameController = /** @class */ (function (_super) {
        __extends(PingPongGameController, _super);
        function PingPongGameController() {
            var _this = _super.call(this) || this;
            _this.app = new PIXI.Application(800, 600, { backgroundColor: 0x451542 });
            _this.app.view.style.display = "block";
            _this.app.view.style.marginLeft = "560px";
            _this.app.view.style.marginTop = "164px";
            document.body.appendChild(_this.app.view);
            _this.collider = new gamePingPong.Collider();
            _this.start();
            return _this;
        }
        PingPongGameController.prototype.start = function () {
            this.ball = new gamePingPong.Ball(450, 10, 10, this.app);
            this.boundTop = new gamePingPong.Bound(0, 0, 800, 2, this.app);
            this.boundLeft = new gamePingPong.Bound(0, 0, 2, 600, this.app);
            this.boundRight = new gamePingPong.Bound(800, 0, -2, 600, this.app);
            this.boundBottom = new gamePingPong.Bound(0, 600, 800, -2, this.app);
            this.paddle1 = new gamePingPong.APaddle(10, 10, 10, 100, this.app);
            this.paddle2 = new gamePingPong.APaddle(780, 10, 10, 100, this.app);
        };
        return PingPongGameController;
    }(gamePingPong.GameController));
    gamePingPong.PingPongGameController = PingPongGameController;
})(gamePingPong || (gamePingPong = {}));
var gamePingPong;
(function (gamePingPong) {
    var VMainGame = /** @class */ (function () {
        function VMainGame() {
            this.gc = new gamePingPong.PingPongGameController();
        }
        return VMainGame;
    }());
    gamePingPong.VMainGame = VMainGame;
    var ob1 = new VMainGame();
})(gamePingPong || (gamePingPong = {}));
