var abloadingStatus = document.getElementById("loadingStatus");
var abloadbar2 = document.getElementById("loadbar2");
var width1 = 0 ;
window.onorientationcha
 var ab1 = setInterval(setPosition1,16.66);
 function setPosition1(){
     if (width1 >= 100) {
         clearInterval(ab1);
       //  abloadingStatus.innerText="WELCOME";
         abloadingStatus.style.fontSize="200%";
       //  abloadingStatus.style.marginTop="20%";
       //  abloadingStatus.style.marginLeft = "32%";
       //  abloadingStatus.style.color="#ddfddd";
        //  window.location.href = "https://yggdrasilgaming.com/games/super-heroes/#tryit";
    
     }
     else {
     width1 +=1;
abloadbar2.style.width = width1 + "%";
abloadingStatus.innerHTML="Loading"+" " + width1+"%";  
         abloadingStatus.style.textAnchor = "middle";
     }

}

