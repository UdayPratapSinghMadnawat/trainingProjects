/// <reference path="../tsd/pixi.js.d.ts" />
/// <reference path="../pixi-sound.d.ts" />

declare namespace gamePingPong {
   export interface iRigidBodies {
        x: number;
        y: number;
        height :number;
        width : number;
        stage: any;
        graphics:PIXI.Graphics;
     moveTo(x: number,y: number):void;
    }
}