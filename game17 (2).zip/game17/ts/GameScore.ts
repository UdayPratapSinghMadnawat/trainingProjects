namespace gamePingPong {
    export class GameScore  {

        x:number = 0;
        y:number = 0;
        width:number=0;
        height:number= 0 ;
        stage1:any;
        scorePlayerRight:any;
       static addScore:number=0;
        constructor(x: number, y: number , width: number , height: number , stage1:any) {
            this.x = x;
            this.y  = y;
            this.width = width;
            this.height = height;
            this.stage1=stage1;
            this.setScore();
        }
            setScore() {
                        GameScore.addScore += 1;
                        this.scorePlayerRight = new PIXI.Text('Player Right :' + GameScore.addScore);
                        this.scorePlayerRight.x = this.x;
                        this.scorePlayerRight.y = this.y;
                        this.stage1.stage.addChild(this.scorePlayerRight);
                        return this ;

            }

    }
}