var app = new PIXI.Application(window.innerWidth , window.innerHeight);
document.body.appendChild(app.view);
var animnate ;
PIXI.loader.add("./spritesheet.json").load(onAssetLoaded);
var wh = app.screen.height ;
var ww = app.screen.width ;
function onAssetLoaded() {
    staticBodies("background",0,0);
    staticBodies("objects/BusBench",500,wh-451);
    staticBodies("objects/FlowerPot",400,wh-150);
    staticBodies("objects/Fruitstand0001",1200,wh-150);
    staticBodies("objects/Hydrant0001",1000,311);
    staticBodies("objects/manhole/Manhole_01", 1200, 425);
    staticBodies("objects/Rain", 1200, 891);
    staticBodies("objects/manhole/Manhole_01", 1200, 425);




     animationSprite1("capguy_0",100,app.screen.height-152,9,1,0.5);
    animationSprite2("objects/manhole/Manhole_0", 1489, 891, 9, 2, 0.5);
    // animationSprite("capguy_0", 400, app.screen.height - 132, 9, 3, 0.5);
    // animationSprite("objects/Crate0",1200,app.screen.height-172,6,4,0.5);
               // animationSprite("capguy_0",100,app.screen.height-172,9,1,0.5);
               // animationSprite("capguy_0",100,app.screen.height-172,9,1,0.5);
               // animationSprite("capguy_0",100,app.screen.height-172,9,1,0.5);


function staticBodies(textureUrl,x,y){
    var textureId = PIXI.Texture.from(textureUrl + ".png");
    var spriteId = new PIXI.Sprite(textureId);
    spriteId.x=x;
    spriteId.y=y;
    app.stage.addChild(spriteId);
}

    function animationSprite1(textureUrl,x,y,n,m,anch) {
    var arrayContainer = "frame" + m ;
    arrayContainer1 =[];
    for(let i =1 ;i<n;i++)
    {
        arrayContainer1.push(PIXI.Texture.fromFrame(textureUrl + i + ".png"));

    }
 
        animnate = new PIXI.extras.AnimatedSprite(arrayContainer1)

    animnate.x = x;
    animnate.y = y;
    animnate.animationSpeed = 0.15;
    animnate.anchor.set(anch);
    //animnate.play();
    animnate.interactive = true ;
    animnate.buttonMode = true ;
    animnate.on("click", startAnimation);
    app.stage.addChild(animnate);
    
}

    function animationSprite2(textureUrl, x, y, n, m, anch) {
        var arrayContainer = "frame" + m;
        arrayContainer4 = [];
        for (let i = 1; i < n; i++) {
            arrayContainer4.push(PIXI.Texture.fromFrame(textureUrl + i + ".png"));

        }
    
        animnate1 = new PIXI.extras.AnimatedSprite(arrayContainer4)

        animnate1.x = x;
        animnate1.y = y;
        animnate1.animationSpeed = 0.15;
        animnate1.anchor.set(anch);
       //  animnate1.play();
        animnate1.interactive = true;
        animnate1.loop = false;
        app.stage.addChild(animnate1);

    }
    function startAnimation() {
    app.ticker.add(function () {
        
        animnate.play();
        animnate.x += 5;
        if (animnate.x > app.screen.width + animnate.width / 2){
            animnate.x = 0;
        }   
      //  animnate1.x += 5;
        if (animnate1.x > app.screen.width + animnate1.width / 2){
            animnate1.x = 0; 
        }

             if(animnate.x > 1300){
                 animnate.gotoAndStop(5);
             }
            if(animnate.x>1380) {
               
                animnate1.play();
                app.stage.removeChild(animnate);
            }
        
    });
}
}