/// <reference path="../tsd/pixi.js.d.ts" />
namespace gamePingPong{
   export   class RigidBodies {  
    public app ;
    public graphics ;


constructor() {
 this.app = new PIXI.Application(800, 600, { backgroundColor: 0x8877dd, antialias: true });
    document.body.appendChild(this.app.view);
    this.graphics = new PIXI.Graphics();
    }

    public drawPaddle(x: number, y: number, w: number, h: number):any{
        this.graphics.beginFill(0x11dd22);
        var paddle1 = this.graphics.drawRect(x,y,w,h);
        this.graphics.endFill();
        this.app.stage.addChild(this.graphics);
        this.graphics.interactive=true;
        return this ;
    }

    public drawBall(x: number, y: number,r: number): any {
        this.graphics.beginFill(0x11dd22);
        var paddle1 = this.graphics.drawCircle(x, y,r);
        this.graphics.endFill();
        this.app.stage.addChild(this.graphics);

        return this ;
    }

    public giveMotion() {

       // ball.position.x += 1 ;
    }
    }

var ob1 = new RigidBodies();
var paddle1=ob1.drawPaddle(10,100,10,100);
var paddle2=ob1.drawPaddle(750,100,10,100);
var paddleLeft = ob1.drawPaddle(0, 0, 0, 600);
var paddleRight = ob1.drawPaddle(800, 0, 0, 600);
var paddleBottom = ob1.drawPaddle(0, 600, 800, 0);
var paddleTop=ob1.drawPaddle(0,0,0,800);
var ball =  ob1.drawBall(352,20,20);
var ab1 = setInterval(ob1.giveMotion,100);
}