class GameController {
    public cordinateBallX:number;
    public cordinateBallY: number;
    public cordinateLedgelX:number;
    public cordinateLedgerX: number;
    public cordinateLedgelY: number;
    public cordinateLedgerY: number;
    public scoreL: number;
    public scoreR: number;


    public detectCollision() {

    }


    public makeUpdation() {


    }



}