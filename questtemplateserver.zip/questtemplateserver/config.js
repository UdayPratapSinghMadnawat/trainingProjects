const SlotConfig = {
    minbet: 1,
    maxbet: 200,
    defaultStake: 10,
    stakeValues: [1, 2, 5, 10, 50, 100, 200],
    currency: 'GBP'
};

const RouletteConfig = {
    chipsize: [1, 2, 5, 10, 50, 100, 200],
    defaultStake: 5,
    currency: 'GBP',
    minNumber: 0,
    maxNumber: 36,
    minTableLimit: 1,
    maxTableLimit: 1000
};

const BlackJackConfig = {
    chipsize: [1, 2, 5, 10, 50, 100, 200],
    currency: 'GBP',
    minStake: 0.5,
    maxStake: 1000.00,
    defaultStake: 5
};

const Props = {
    isWaysWinGame: false,
    isFreeSpinRetriggerAvailable: false,
    isExpendingWildAvailable: false,
    isRandomWildAvailable: false,
    isStickyWildAvailable: false,
    isBonusAvailable: true
};

exports.SlotConfig = SlotConfig;
exports.RouletteConfig = RouletteConfig;
exports.BlackJackConfig = BlackJackConfig;
exports.Props = Props;