const grid = require('./grid').Grid;
const {LineWinEvaluator, WaysWinEvaluator} = require('./winevaluator');

class EvalSlotFeature
{

    constructor(isWaysWin, payLines, payTable, wildList, scatterList)
    {
        this.winevaluator = ( isWaysWin) ? 
        new WaysWinEvaluator( payTable, wildList, scatterList) : 
        new LineWinEvaluator( payLines, payTable, wildList, scatterList);

        const util = {
            deepCopy : g => {return g.map(v=>v.slice());}, 
            getReelsContainingSymbol : (s, g, t) => { return t.filter( v => g[v-1].some( v => v==s));},
            getGridWithTargetReelsReplacedWithSymbol:(s, g, t) => { let ng = g.map( v => v.slice());
                t.map((v, i) => ng[v-1] = Array.from( new Array( ng[0].length ), () => s)); return ng;}
        };
    }

    processGrids (state, rng, reelSet, rowCount)
    {
        state.stops = Array.from( new Array( reelSet.length), ( v, i) => rng.getNextRandom( reelSet[i].length));
        state.grid = grid.generateSymbolGrid(state.stops, reelSet, rowCount);
        return state;
    }
    
    processGridWins (state, bet, totallines)
    {
        const winnings = this.winevaluator.calculateWinning( (state.wingrid)?state.wingrid:state.grid, totallines, bet);
        state.winnings = winnings.concat(state.winnings);
        state.win = 0;
        for(let winning of state.winnings) 
        { 
            state.win += winning.payout;
        }
        return state;
    }

    updateFeatureTriggered(state)
    {
        if( state.win == 0 )
            state.randomSymbol = state.expendingReels = undefined;

        return state;
    }
    
    processScatterPayout( symbolid, offsets=[], winnings=[], multiplier=1, payout=[]){
        const scatterPayout = payout[offsets.length];
        if(scatterPayout > 0)
        {
            winnings.push(
            {
                'symbol': symbolid,
                'payline': -1,
                'count': offsets.length,
                'payout': scatterPayout*multiplier,
                'offsets': offsets
            });
        }
        return winnings;
    }
    
    processExpendingSymbol (state, expend)
    {
        console.log('Expending Symbol');
        state.expendingReels = undefined;
        const expendingReels = grid.getReelsContainingSymbol(expend.symbolid, state.grid, expend.reels);
        if (expendingReels.length == 0) { return state; }
        state.expendingSymbol = {};
        state.expendingSymbol.symbol = expend.symbolid;
        state.expendingSymbol.initialGrid = state.grid.map(v=>v.slice());
        state.expendingSymbol.reels = expendingReels;
        state.grid = grid.getGridWithTargetReelsReplacedWithSymbol(expend.symbolid, state.grid, expendingReels);
        return state;
    }
    
    processRandomSymbol (state, random, rng)
    {
        const norandom = rng.getNextRandom(random.probablity) > 0;
        console.log('Random Symbol ', !norandom);
        state.randomSymbol = undefined;
        if (norandom) { return state; }
        state.randomSymbol = {};
        state.randomSymbol.symbol = random.symbolid;
        state.randomSymbol.offsets = rng.getUniqueRandomNumbers(0, state.grid.length*state.grid[0].length, rng.getNextRandom(random.randomWild)+1).sort();
        state.randomSymbol.initialGrid = state.grid.map(v=>v.slice());
        state.grid = grid.getReplacedGridWithSymbolInOffsets( random.symbolid, state.randomSymbol.initialGrid, state.randomSymbol.offsets);
        return state;
    }
    
    processStickySymbol (state, sticky)
    {
        if(!state.stickySymbol)
        {  
            state.stickySymbol = [];
        }
        if (state.stickySymbol && state.stickySymbol.length > 0)
        {
            state.stickySymbol.map((v, i) => { state.stickySymbol[i].count--;}) ;
            state.stickySymbol = state.stickySymbol.filter(v => v.count >= 0);
        }

        const offsets = grid.getSymbolOffsetsInGrid( sticky.symbolid, state.grid );
        console.log('Sticky Symbol ', offsets);
        offsets.forEach(v => { if(Array.from(state.stickySymbol).every( f => f.offset != v ))
            {
                state.stickySymbol.push(
                {
                    'symbol' : sticky.symbolid,
                    'count' : sticky.count,
                    'offset' : v
                });
            }});

        state.wingrid = (state.stickySymbol.map.length == 0) ? undefined : 
            grid.getReplacedGridWithSymbolInOffsets(sticky.symbolid, state.grid, state.stickySymbol.map(v=>v.offset));
        
        return state;
    }
}

class EditSlotState 
{

    constructor(){}

    addSpinsAwarded( state, offsets, spins )
    {
        const spinAwarded = spins[offsets.length];
        if(spinAwarded == 0){ return undefined;}
    
        state.spinsAwarded = spinAwarded;
        state.spinsRemaining = spinAwarded;
        state.spinsRetriggered = 0;
        state.offsets = offsets;
        state.totalWin = 0;
        return state;
    }
    
    updateSpinsAwarded( state, offsets, spins )
    {
        const spinAwarded = spins[offsets.length];
        if(spinAwarded == 0)
        {
            state.offsets = undefined;
            state.spinsRetriggered = 0;
            return state;
        }
    
        state.spinsAwarded += spinAwarded;
        state.spinsRemaining += spinAwarded;
        state.spinsRetriggered = spinAwarded;
        state.offsets = offsets;
        return state;
    } 
}

exports.EditSlotState = EditSlotState;
exports.EvalSlotFeature = EvalSlotFeature;
