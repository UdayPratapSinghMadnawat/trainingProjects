const {Props} = require('../../config');
const {SlotMath, RouletteMath, BkaclJackMath} = require('../math');
const {EvalSlotFeature, EditSlotState} = require('./slotutil');
const grid = require('./grid').Grid;

class SlotEngine 
{
    constructor()
    {
        this.esf = new EvalSlotFeature(Props.isWaysWinGame, SlotMath.payLines, SlotMath.payTable, 
                                SlotMath.wildSymbolList, SlotMath.scatterSymbolList);
        this.ess = new EditSlotState();
    }

    refresh(state)
    { 
        //state.spin = undefined;
        //state.freespin = undefined;
        //state.game.nextAction = 'spin';
        return state; 
    }

    spin(state, rng, bet)
    {
        state.request = {};
        state.freespin = undefined;
        state.bonus = undefined;

        state.request.betPerLine = bet;
        state.request.totalBet = bet * SlotMath.payLines.length;
        state.spin = (state.spin) ? state.spin : {};
        state.spin = this.esf.processGrids(state.spin, rng, SlotMath.reelSet, SlotMath.rowCount);
        const scatterOffsets = grid.getSymbolOffsetsInGrid(SlotMath.scatterSymbolList[0], state.spin.grid);
        state.spin.winnings = this.esf.processScatterPayout(SlotMath.scatterSymbolList[0], scatterOffsets, [], bet, SlotMath.scatterPayout);
        if (Props.isBonusAvailable && scatterOffsets.length > 2) {
            state.bonus = { "offsets": scatterOffsets, "options": SlotMath.bonus }
        } else {
            state.freespin = this.ess.addSpinsAwarded({}, scatterOffsets, SlotMath.triggerFreeSpins);
        }
        state.spin = (Props.isRandomWildAvailable) ? this.esf.processRandomSymbol(state.spin, SlotMath.randomSymbol, rng) : state.spin;
        state.spin = (Props.isExpendingWildAvailable) ? this.esf.processExpendingSymbol(state.spin, SlotMath.expendingSymbol) : state.spin;
        state.spin = (Props.isStickyWildAvailable) ? this.esf.processStickySymbol(state.spin, SlotMath.stickySymbol) : state.spin;
        state.spin = this.esf.processGridWins(state.spin, bet, SlotMath.payLines.length);
        state.spin = this.esf.updateFeatureTriggered(state.spin);

        if (state.freespin)
        {
            state.game.status = 'open';
            state.game.nextAction = 'freespin';
        }
        if (state.bonus) {
            state.game.status = 'open';
            state.game.nextAction = 'bonus';
        }
        
        state.game.totalWin = state.spin.win;
        return state;
    }

    freespin(state, rng)
    {
        state.freespin = this.esf.processGrids(state.freespin, rng, SlotMath.reelSet, SlotMath.rowCount);
        const scatterOffsets = grid.getSymbolOffsetsInGrid(SlotMath.scatterSymbolList[0], state.freespin.grid);
        state.freespin.winnings = this.esf.processScatterPayout(SlotMath.scatterSymbolList[0], scatterOffsets, [], state.request.betPerLine, SlotMath.scatterPayout);
        state.freespin = (Props.isFreeSpinRetriggerAvailable) ? this.ess.updateSpinsAwarded(state.freespin, scatterOffsets, SlotMath.retriggerFreeSpins) : state.freespin;        
        state.freespin = (Props.isRandomWildAvailable) ? this.esf.processRandomSymbol(state.freespin, SlotMath.randomSymbol, rng) : state.freespin;
        state.freespin = (Props.isExpendingWildAvailable) ? this.esf.processExpendingSymbol(state.freespin, SlotMath.expendingSymbol) : state.freespin;
        state.freespin = (Props.isStickyWildAvailable) ? this.esf.processStickySymbol(state.freespin, SlotMath.stickySymbol) : state.freespin;
        state.freespin = this.esf.processGridWins(state.freespin, state.request.betPerLine, SlotMath.payLines.length);
        state.freespin = this.esf.updateFeatureTriggered(state.freespin);
        
        state.freespin.spinsRemaining--;
        if (state.freespin.spinsRemaining == 0)
        {
            state.game.status = 'close';
            state.game.nextAction = 'spin';
        }

        state.freespin.totalWin += state.freespin.win;
        state.game.totalWin += state.freespin.win;
        return state;
    }

    bonus(state, rng)
    {
        let index = rng.getNextRandom(SlotMath.bonus.length);
        state.bonus.multiplier = SlotMath.bonus[index];
        state.bonus.win = state.bonus.multiplier * state.request.totalBet;
        state.game.totalWin += state.bonus.win;
        state.game.status = 'close';
        state.game.nextAction = 'spin';
        return state;
    }
}

class RouletteEngine 
{
    constructor() {}

    refresh(state){ return state; }

    play(state, rng, bet)
    {
        state.drawnNumber = rng.getNextRandom(36);
        state.game.totalWin = 0;
        state.request = {};
        state.request.totalBet = 0;
        bet.forEach( (v, i)=>{  
            const c = RouletteMath.bets[v.id];
            v.win = (c.bet.indexOf(state.drawnNumber)>=0) ? v.win = v.bet* RouletteMath.bettypes[c.type] : 0;
            state.game.totalWin += v.win; 
            state.request.totalBet += v.bet;
         });
        state.player = bet;
        return state;
    }
}

class BlackJackEngine
{
    constructor()
    {
        this.cards = [];
    }

    refresh(state){ return state; }

    // TODO -- Need to take care of code duplicacy in this class 

    deal(state, rng, input)
    { 
        state.cards = rng.getUniqueRandomNumbers(1, BkaclJackMath.length, BkaclJackMath.length-1);
        state.request = {};
        state.request.totalBet = 0;
        state.request.insuranceBet = 0;
        input.forEach(v => { v.cards=[];
            state.request.totalBet += v.bet;
            const c1 = BkaclJackMath[state.cards.shift()];
            const c2 = BkaclJackMath[state.cards.shift()];
            v.total_type = (c1.value == 12 || c2.value == 12) ? 'soft' : 'hard';
            v.cards.push(c1.name); v.cards.push(c2.name);
            v.status = 'open';
            v.points = c1.points + c2.points;
            v.cardPoints = [c1.points, c2.points];
            v.win = 0;
            v.doubled = "no";
            v.insured = 'no';
            v.originalBet = v.bet;
            v.actions = ['hit','stand'];
            if(v.points > 21 && c1.value == 11) { v.points = 12; }
            if(v.points >= 9 && v.points <= 11){ v.actions.push('double');}
            if(c1.value == c2.value){ v.actions.push('split');}
            if (v.points == 21) { v.status='blackjack'; v.actions=[];}});
        state.player = input;
        const c = BkaclJackMath[state.cards.shift()];
        state.dealer = {};
        state.dealer.insurance = c.value == 12 ? 'yes' : 'no'; 
        state.dealer.cards = [c.name];
        state.dealer.points = c.points;
        state.game.nextAction = '';
        state.game.status = 'open';
        state.dealer.total_type = (c.value == 12) ? 'soft' : 'hard';

        if(this.ifAllPlayersDone(state))
            state = this.drawDealerCardANdCalculateWin(state);

        return state; 
    }

    hit(state, input, forceclose = false)
    { 
        state.dealer.insurance = 'no';
        state.player.forEach((v, i)=>{
            if(v.id == input[0].id && v.actions.indexOf('hit') >= 0){
                const c = BkaclJackMath[state.cards.shift()];
                state.player[i].cards.push(c.name);
                v.cardPoints.push(c.points);
                state.player[i].points = this.addValuesToPoints(v.cardPoints);
                v.total_type = 'hard';
                if (state.player[i].points > 21) { state.player[i].status='busted';}
                if (state.player[i].points == 21) { state.player[i].status='stand';}
                state.player[i].actions = (state.player[i].status == 'open') ? ['hit','stand'] : [];

                if(forceclose && (state.player[i].status == 'open')){
                    state.player[i].actions = [];
                    state.player[i].status = 'stand';
                }
            }
        });

        if(this.ifAllPlayersDone(state))
            state = this.drawDealerCardANdCalculateWin(state);

        return state; 
    }

    double(state, input)
    { 
        state.dealer.insurance = 'no';
        state.player.forEach((v, i)=>{
            if(v.id == input[0].id && v.actions.indexOf('double') >= 0){
                const c = BkaclJackMath[state.cards.shift()];
                state.player[i].cards.push(c.name);
                v.cardPoints.push(c.points);
                state.player[i].points = this.addValuesToPoints(v.cardPoints);
                state.player[i].bet *= 2;
                state.player[i].status='stand';
                state.player[i].doubled = "yes";
                if (state.player[i].points > 21) { state.player[i].status='busted';}
                if (state.player[i].points == 21) { state.player[i].status='stand';}
                state.player[i].actions = [];
            }
        });

        if(this.ifAllPlayersDone(state))
            state = this.drawDealerCardANdCalculateWin(state);

        return state; 
    }

    stand(state, input)
    { 
        state.dealer.insurance = 'no';
        state.player.forEach((v, i)=>{
            if(v.id == input[0].id && v.actions.indexOf('stand') >= 0){
                state.player[i].actions = [];
                state.player[i].status = 'stand';
            }
        });

        if(this.ifAllPlayersDone(state))
            state = this.drawDealerCardANdCalculateWin(state);

        return state;
    }

    split (state, input)
    { 
        state.dealer.insurance = 'no';
        let isAceSplit = false;
        state.player.forEach((v, i)=>{
            if(v.id == input[0].id && v.actions.indexOf('split') >= 0){
                let split = {
                    'id' : v.id + '_2',
                    'cards' : [v.cards[0]],
                    'bet' : v.bet,
                    'status' : v.status,
                    'points' : v.points/2,
                    'cardPoints' : [v.cardPoints[0]],
                    'actions' : ['hit','stand'],
                    'seat' : v.seat,
                    'originalBet' : v.originalBet, 
                    'doubled' : v.doubled,
                    'insured' : v.insured,
                    'total_type' : 'hard',
                };
                state.player[i].id += '_1';
                state.player[i].points = v.points/2;
                state.player[i].cards = [v.cards[1]];
                state.player[i].actions = ['hit','stand'];
                state.player[i].total_type = 'hard';
                state.player[i].cardPoints.pop();
                state.player.splice(i+1, 0, split);
                
                if(v.cards[0].indexOf('A') > 0){
                    isAceSplit = true;
                }
            }
        });

        if (isAceSplit == true){
            let inp1 = [ { id: input[0].id + '_1' } ];
            this.hit(state, inp1, true);
            let inp2 = [ { id: input[0].id + '_2' } ];
            this.hit(state, inp2, true);
        }

        if(this.ifAllPlayersDone(state))
            state = this.drawDealerCardANdCalculateWin(state);

        return state;
    }

    insurance (state, input)
    {
        state.dealer.insurance = 'no';
        input.forEach((v, i)=>{
            if(v.insured == 'yes'){
                state.player[i].insured = 'yes';
                state.request.insuranceBet +=  state.player[i].bet/2;
            }
        });
        return state;
    }

    addValuesToPoints( values )
    {
        let point = 0;
        let a = 0;
        values.forEach( v => {point+=v; if (v == 11){a++;}} );
        if (point > 21 && a > 0){
            for(let i=0; i<a; i++){
                point -= 10;
                if(point <= 21){ break; }
            }
        }
        return point;
    }
    
    ifAllPlayersDone ( state )
    {
        return state.player.every((v) => v.actions.length == 0);
    }

    drawDealerCardANdCalculateWin ( state )
    {
        while (state.dealer.points < 17)
        {
            const c = BkaclJackMath[state.cards.shift()];
            state.dealer.cards.push(c.name);
            state.dealer.points += c.points;
        }
        state.dealer.status = '';
        if (state.dealer.points > 21) { state.dealer.status='busted';}
        if (state.dealer.points == 21) { state.dealer.status='blackjack';}

        state.game.cardWin = 0;        
        state.player.forEach((v)=>{
            v.win = 0;
            if (v.status == 'blackjack' || (v.status == 'stand' && state.dealer.status == 'busted') || 
                (v.status == 'stand' && state.dealer.status == '' && v.points > state.dealer.points)) { v.win = v.bet*2;}
            if (v.status == 'stand' && state.dealer.status == '' && v.points == state.dealer.points)  { v.win = v.bet; v.status='pass';}
            if ( v.status == 'stand' && v.win > 0) { v.status = 'won';}
            if ( v.status == 'stand' && v.win == 0) { v.status = 'loose';}
            if (v.points == state.dealer.points && v.status != 'busted'){v.status = 'push';}
            state.game.cardWin += v.win;
        });
        state.game.status = 'close';
        state.game.nextAction = 'deal';

        if (state.dealer.status == 'blackjack'){
            state.game.insuranceWin = state.request.insuranceBet * 2;
        }

        state.game.totalWin = state.game.insuranceWin;
        state.game.totalWin += state.game.cardWin;

        return state;
    }
}

exports.SlotEngine = new SlotEngine();
exports.RouletteEngine = new RouletteEngine();
exports.BlackJackEngine = new BlackJackEngine();
