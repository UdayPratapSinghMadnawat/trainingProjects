class Grid 
{

    constructor(){}
    
    generateSymbolGrid(stops, reelSet, rowCount)
    {
        let symbolGrid = [];
        for (var col = 0; col < rowCount.length; col++)
        {
            let index = stops[col];
            let reel = [];
            const len = rowCount[col];
            for (var row = 0; row < len; row++)
            {
                reel.push(reelSet[col][index]);
                index = index + 1;
                index = index % reelSet[col].length;
            }
            symbolGrid.push(reel);
        }
        return symbolGrid;
    }

    getSymbolOffsetsInGrid(symbolID, grid)
    {
        let offsets = [];
        for(var col=0; col<grid.length; col++)
        {
            for(var row=0; row<grid[col].length; row++)
            {
                if(grid[col][row] == symbolID)
                {
                    offsets.push((row*grid.length)+col); 
                }
            }
        }
        return offsets;
    }
    
    getReplacedGridWithSymbolInOffsets(symbolID, grid, offsets)
    {
        let newGrid = [];
        for(var col=0; col<grid.length; col++)
        {
            newGrid[col] = [];
            for(var row=0; row<grid[col].length; row++)
            {
                const index = (row*grid.length)+col;
                newGrid[col][row] = (offsets.indexOf(index) >= 0) ? symbolID : grid[col][row];
            }
        }
        return newGrid;
    }

    getReelsContainingSymbol(symbolid, grid, targetReels)
    {
        return targetReels.filter(v=>grid[v-1].some(v=>v==symbolid));
    }

    getGridWithTargetReelsReplacedWithSymbol(symbolid, grid, targetReels)
    {
        let newgrid = grid.map(v=>v.slice());
        targetReels.map((v,i)=>newgrid[v-1]=Array.from(new Array(newgrid[0].length),()=>symbolid));
        return newgrid;
    }
    
}

exports.Grid = new Grid();
