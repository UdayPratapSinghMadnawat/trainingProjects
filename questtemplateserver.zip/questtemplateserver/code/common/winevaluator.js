class LineWinEvaluator
{

    constructor(payLines, payTable, wildList=[], scatterList=[])
    {
        this.payLines = payLines;
        this.payTable = payTable;
        this.wildList = wildList;
        this.scatterList = scatterList;
    }

    calculateWinning(grid, linesCount, multiplier=1, wildMultiplier=1, isMultiplierOnWild=false, preferWildWins=true)
    {
        let winnings=[];
        for (var line=0; line < linesCount; line++)
        {
            const win = this.detectLineWin(grid, line, multiplier, wildMultiplier, isMultiplierOnWild, preferWildWins);
            if(win.payout > 0)
            {
                winnings.push(win);
            }
        }
        return winnings;
    }

    detectLineWin( grid, line, multiplier=1, wildMultiplier=1, isMultiplierOnWild=false, preferWildWins=true)
    {
        let symbolCount = 0;
        let consecutiveWildCount = 0;
        let symbolID = -1;
        let wildSymbolID = -1;
        let payLine = this.payLines[line];
        let reelsCount = grid.length;
        let isWildInclude = false;
        
        for (var column=0; column<reelsCount; column++)
        {
            const row = payLine[column];
            const currSymbolID = Number(grid[column][row]);
            if (this.scatterList.indexOf(currSymbolID) > 0)
            {
                break;
            }
            if (symbolID == -1 )
            {
                symbolCount++;
                if (this.wildList.indexOf(currSymbolID) >= 0)
                {
                    consecutiveWildCount++;
                    wildSymbolID = currSymbolID;
                    isWildInclude = true;
                } 
                else 
                {
                    symbolID = currSymbolID;
                }
                continue;
            }

            if (symbolID == currSymbolID || this.wildList.indexOf(currSymbolID) >= 0)
            {
                isWildInclude = (this.wildList.indexOf(currSymbolID) >= 0);              
                symbolCount++;
            } 
            else
            {
                break;
            }
        }

        let wildWin = 0;
        if (wildSymbolID > -1 && consecutiveWildCount > 0)
        {
            wildWin = this.payTable[wildSymbolID][consecutiveWildCount];
            if (isMultiplierOnWild)
            {
                wildWin = wildWin* wildMultiplier;
            }
        }

        let symbolWin = 0;
        if (symbolID > -1 && symbolCount > 0)
        {
            symbolWin = this.payTable[symbolID][symbolCount];
            if (isWildInclude)
            {
                symbolWin = symbolWin * wildMultiplier;
            }
        }
        
        let winSymbolID = symbolID;
        let winSymbolCount = symbolCount;
        let winSymbolPayout = symbolWin;
        if (wildWin > symbolWin || (preferWildWins && wildWin == symbolWin))
        {
            winSymbolID = wildSymbolID;
            winSymbolCount = consecutiveWildCount;
            winSymbolPayout = wildWin;
        }
        let offsets = [];
        for( var i=0; i<winSymbolCount; i++ )
        {
            offsets.push(( payLine[i] * reelsCount ) + i); 
        }

        return {
            'symbol': winSymbolID,
            'payline': line + 1,
            'count': winSymbolCount,
            'payout': winSymbolPayout*multiplier,
            'offsets': offsets
        };
    }

}


class WaysWinEvaluator
{
    constructor(payTable, wildList=[], scatterList=[])
    {
        this.payTable = payTable;
        this.wildList = wildList;
        this.scatterList = scatterList;
    }

    calculateWinning(grid, linesCount=0, multiplier=1, wildMultiplier=1)
    {
        let symbolList = [];
        for(var i = 0; i < grid.length; i++)
        {
            let isWildInReel = false; 
            for(var j in grid[i])
            {
                const symbol = Number(grid[i][j]);
                if (this.wildList.indexOf(symbol) >= 0)
                {
                    isWildInReel = true;
                } 
                else 
                {
                    if (this.scatterList.indexOf(symbol) == -1)
                    {
                        symbolList.push(symbol);
                    }
                }
            }
            if (!isWildInReel)
            {
                break;
            }
        }
        symbolList = symbolList.filter((v, i, a) => a.indexOf(v) === i);
        let winnings=[];
        for (var s in symbolList)
        {
            const symbol = symbolList[s];
            let winSymbolOffsets = [];
            let currentSymbolOffsets = [];
            let flag = false;
            for (var col = 0; col < grid.length ; col++)
            {
                for (var row = 0; row < grid[col].length; row++)
                {
                    let currentSymbol = Number(grid[col][row]);
                    if (currentSymbol == symbol || this.wildList.indexOf(currentSymbol) >= 0)
                    {
                        if (col == 0){
                            if (this.wildList.indexOf(currentSymbol) >= 0)
                            {
                                currentSymbolOffsets.push('w,' + ((row*grid.length)+col));
                            } 
                            else 
                            {
                                currentSymbolOffsets.push('n,' + ((row*grid.length)+col));
                            }
                        } else 
                        {
                            for (var o in winSymbolOffsets)
                            {
                                let offset = winSymbolOffsets[o];
                                if (this.wildList.indexOf(currentSymbol) >= 0 )
                                {
                                    offset = offset.split(",");
                                    offset[0] = "w";
                                }
                                offset = offset + ',' + ((row*grid.length)+col);
                                currentSymbolOffsets.push(offset);
                            }
                        }
                        flag = true;
                    }
                }
                if (flag)
                {
                    winSymbolOffsets = [];
                    winSymbolOffsets = winSymbolOffsets.concat(currentSymbolOffsets);
                    currentSymbolOffsets = [];
                    flag = false;
                } 
                else 
                {
                    break;
                }
            }
            const symbolWinning = this.detectWaysWins(symbol, winSymbolOffsets, multiplier, wildMultiplier);
            if (symbolWinning.length > 0)
            {
                winnings = winnings.concat(symbolWinning);
            }
        }
        return winnings;
    }

    detectWaysWins(symbol, winSymbolOffsets=[], multiplier=1, wildMultiplier=1)
    {
        let symbolWinnings = [];
        let symbolOffset = [];
        let symbolOffsetWithMultiplier = [];
        let symbolWin = 0;
        let symbolWinWithMultiplier = 0;

        for (var o in winSymbolOffsets)
        {
            const offset = winSymbolOffsets[o];
            let isWildSubstitute = offset.split(",")[0] == 'w';
            let offsetList = offset.split(",").splice(1, offset.split(",").length);
            const payout = this.payTable[symbol][offsetList.length];
            if (payout > 0 )
            {
                if (isWildSubstitute && wildMultiplier != 1)
                {
                    symbolOffsetWithMultiplier.push(offsetList);
                    symbolWinWithMultiplier = symbolWinWithMultiplier + payout;
                } 
                else 
                {
                    symbolOffset.push(offsetList);
                    symbolWin += payout;
                }
            }
        }
        if (symbolWin > 0)
        {
            symbolWin = symbolWin * multiplier;
            symbolWinnings.push(
            {
                'symbol' : symbol,
                'payline' : -1,
                'offsets' : symbolOffset,
                'payout' : symbolWin
            });
        }
        if (symbolWinWithMultiplier > 0)
        {
            symbolWinWithMultiplier = symbolWinWithMultiplier * multiplier * wildMultiplier;
            symbolWinnings.push(
            {
                'symbol' : symbol,
                'payline' : -1,
                'offsets' : symbolOffsetWithMultiplier,
                'payout' : symbolWinWithMultiplier
            });
        }
        return symbolWinnings;
    }
}

exports.LineWinEvaluator = LineWinEvaluator;
exports.WaysWinEvaluator = WaysWinEvaluator;
