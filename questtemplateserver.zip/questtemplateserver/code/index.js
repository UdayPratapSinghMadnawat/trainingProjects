const express = require('express');
const bodyparser = require('body-parser');
const app = express();

const {ProcessGame} = require('./platform/process');

console.log('Game Type', process.argv[2]);
const game = new ProcessGame(process.argv[2]);

app.use(bodyparser.text());
app.use(bodyparser.json());

app.use((req, res, next) => 
{
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
});

app.post('/', (req, res) =>
{
    console.log(req.body);
    const input = (req.headers['content-type'].indexOf('json') >= 0) ? req.body : JSON.parse(req.body);
    res.send(game.processRequest(input));
    console.log('----------------------------');
});

app.listen(9000, ()=>console.log('Server started at 9000'));
