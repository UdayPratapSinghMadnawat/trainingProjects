const {SlotConfig, RouletteConfig, BlackJackConfig} = require('./../../config');
const {RouletteMath} = require('./../math');

class ErrorResponse
{
    constructor(){}

    error ( state )
    {
        let response = {};
        response.game = state.game;
        response.error = state.error;
        response.error.message = 'Wrong Sequence. Expected '.concat(state.game.nextAction).
        concat(' got ').concat(state.game.action).concat('.');
        return response;
    }
}

class SlotResponse 
{
    constructor(){}

    refresh ( state )
    {
        let response = {}
        if (state.game.status == "open") {
            switch (state.game.nextAction) {
                case "freespin": response = this.freespin(state); break;
                case "bonus": response = this.bonus(state); break;
                default: response = this.spin(state); break;
            }
        } else {
            response.game = state.game;
            response.init = {};
            response.init.grid = [
                ["4", "6", "3"],
                ["7", "3", "0"],
                ["5", "4", "2"],
                ["6", "2", "8"],
                ["3", "8", "9"]];
            response.init.stops = [61, 42, 0, 18, 34];
        }
        response.config = SlotConfig;
        return response;
    }

    spin ( state )
    {
        let response = {};
        response.game = state.game;
        response.spinRequest = state.request;
        response.spinResponse = state.spin;
        response.spinResponse.wingrid = undefined;
        response.freespin = state.freespin;
        response.bonus = state.bonus;
        return response;
    }

    freespin ( state )
    {
        let response = {};
        response.game = state.game;
        response.spinRequest = state.request;
        response.spinResponse = state.spin;
        response.freespin = {};
        response.freespin.spinsAwarded = state.freespin.spinsAwarded;
        response.freespin.spinsRemaining = state.freespin.spinsRemaining; 
        response.freespin.spinsRetriggered = state.freespin.spinsRetriggered; 
        response.freespin.offsets = state.freespin.offsets;
        response.freespin.totalWin = state.freespin.totalWin;
        response.currentResponse = {};
        response.currentResponse.stops = state.freespin.stops;
        response.currentResponse.grid = state.freespin.grid;
        response.currentResponse.winnings = state.freespin.winnings;
        response.currentResponse.win = state.freespin.win;
        return response;
    }

    bonus(state)
    {
        return this.spin(state);
    }
}

class RouletteResponse
{
    constructor(){}

    refresh ( state )
    {
        let response = {};
        response.game = state.game;
        response.config = RouletteConfig;
        response.config.bets = RouletteMath.bets;

        response.config.bets.forEach( v => { const stakeLimit = RouletteMath.mixMaxStake[v.type];
            v.minStake = stakeLimit[0]; v.mxnStake = stakeLimit[1]; v.multiplier = RouletteMath.bettypes[v.type];});
        return response;
    }

    play ( state )
    {
        return state;
    }

}

class BlackJackResponse
{
    constructor(){}
    
    refresh(state)
    {
        let response = {};
        response.game = state.game;
        response.config = BlackJackConfig;
        response.config.cards = ["C2","C3","C4","C5","C6","C7","C8","C9","C10","CJ","CK","CQ","CA","D2","D3","D4","D5","D6","D7","D8","D9","D10","DJ","DK","DQ","DA","H2","H3","H4","H5","H6","H7","H8","H9","H10","HJ","HK","HQ","HA","S2","S3","S4","S5","S6","S7","S8","S9","S10","SJ","SK","SQ","SA"];
        return response;
    }

    deal(state)
    { 
        let response = {};
        response.game = state.game;
        response.request = state.request;
        response.response = {};
        response.response.players = state.player;
        response.response.dealer = state.dealer;
        response.cards = undefined;

        // ---- Added to make it similar to openbet 
        response.game.held_funds = 0;
        response.game.ccy_code = "GBP";
        response.game.adjusted_free_balance = "No";
        response.game.ccy_decimal_separator = ".";
        response.game.ccy_thousand_separator = ",";

        response.request.id = "0";
        
        response.response.blackjackState = {};
        response.response.blackjackState.current_player = -1;
        response.response.blackjackState.total_players = response.response.players.length;
        response.response.blackjackState.insurance_offered = state.dealer.insurance;
        response.response.blackjackState.options = response.game.nextAction == 'deal' ? 'deal' : 'Hit,Stay';

        response.response.players.forEach( (v, i) => { 
            v.current_hand = 1; v.total_hands = 1; v.insurance = 'No'; 
            v.total = v.points; v.double_card='0'; 
            v.player_status = v.actions.length > 0 ? 'playing' : 'stick';
            v.player_status = response.game.status = 'open' ? v.player_status : v.win > 0 ? 'won' : 'lost';
            v.burnt_cards = '';
			if(v.actions.length > 0 && response.response.blackjackState.current_player == -1) response.response.blackjackState.current_player = v.id;});
        // ---- End  

        return response; 
    }
    
    hit(state){ return this.deal(state); }
    double(state){ return this.deal(state); }
    split(state){ return this.deal(state); }
    stand(state){ return this.deal(state); }
    insurance(state){ return this.deal(state); }
}

exports.ErrorResponse = new ErrorResponse();
exports.SlotResponse = new SlotResponse();
exports.RouletteResponse = new RouletteResponse();
exports.BlackJackResponse = new BlackJackResponse();
