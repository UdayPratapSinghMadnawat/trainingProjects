const rng = require('./rng').RNG;
const slotengine = require('../common/engine').SlotEngine;
const slotresponse = require('./response').SlotResponse;
const rouletteengine = require('../common/engine').RouletteEngine;
const rouletteresponse = require('./response').RouletteResponse;
const blackjackengine = require('../common/engine').BlackJackEngine;
const blackjackresponse = require('./response').BlackJackResponse;
const errorresponse = require('./response').ErrorResponse;

const slotAction = 
{
    refresh : (s, i) => { return slotengine.refresh(s);},
    spin : (s, i) => { return slotengine.spin(s, rng, i.stakePerLine);},
    freespin: (s, i) => { return slotengine.freespin(s, rng); },
    bonus: (s, i) => { return slotengine.bonus(s, rng); }
};

const slotResponse = 
{
    refresh : (s) => { return slotresponse.refresh(s);},
    spin : (s) => { return slotresponse.spin(s);},
    freespin: (s) => { return slotresponse.freespin(s); },
    bonus: (s) => { return slotresponse.bonus(s); },
    error : (s) => { return errorresponse.error(s);}
};

const rouletteAction = 
{
    refresh : (s, i) => { return rouletteengine.refresh(s);},
    play : (s, i) => { return rouletteengine.play(s, rng, i.bets);},
};

const rouletteResponse = 
{
    refresh : (s) => { return rouletteresponse.refresh(s);},
    play : (s) => { return rouletteresponse.play(s);},
    error : (s) => { return errorresponse.error(s);}
};

const blackjackAction = 
{
    refresh : (s, i) => { return blackjackengine.refresh(s);},
    deal : (s, i) => { return blackjackengine.deal(s, rng, i.bets);},
    hit : (s, i) => { return blackjackengine.hit(s, i.bets);},
    stand : (s, i) => { return blackjackengine.stand(s, i.bets);},
    double : (s, i) => { return blackjackengine.double(s, i.bets);},
    split : (s, i) => { return blackjackengine.split(s, i.bets);},
    insurance : (s, i) => { return blackjackengine.insurance(s, i.bets);},
};

const blackjackResponse = 
{
    refresh : (s) => { return blackjackresponse.refresh(s);},
    deal : (s) => { return blackjackresponse.deal(s);},
    hit : (s) => { return blackjackresponse.hit(s);},
    stand : (s) => { return blackjackresponse.stand(s);},
    double : (s) => { return blackjackresponse.double(s);},
    split : (s) => { return blackjackresponse.split(s);},
    insurance : (s) => { return blackjackresponse.insurance(s);},
    error : (s) => { return errorresponse.error(s);},
};

class ProcessGame
{
    constructor( gameType )
    {
        this.state = {
            game : {
                status : 'close',
                nextAction : 'spin',
                balance : 10000,
                totalWin : 0,
                version: '1.1.2'
            }
        };

        this.action = this.response = {};
        // todo - remove this switch case 
        switch (gameType) 
        {
            case 'slot':
                this.action = slotAction;
                this.response = slotResponse;
            break;
            case 'roulette':
                this.state.game.nextAction = 'play';
                this.action = rouletteAction;
                this.response = rouletteResponse;
            break;
            case 'blackjack':
                this.state.game.nextAction = 'deal';
                this.action = blackjackAction;
                this.response = blackjackResponse;
            break;
        }
    }

    processRequest(input)
    {
        this.state.error = undefined;
        this.state.game.action = input.action;
        if (input.action == this.state.game.nextAction || input.action == 'refresh' || this.state.game.nextAction == '')
        {
            if (input.cheat) { rng.setCheats(input.cheat); }
            this.state = this.action[input.action.toString().toLowerCase()](this.state, input);
            if (['spin', 'play', 'deal'].indexOf(this.state.game.action) >= 0) { this.state.game.balance -= this.state.request.totalBet; }
            if (['insurance'].indexOf(this.state.game.action) >= 0){ this.state.game.balance -= this.state.request.insuranceBet;}
            if (this.state.game.status == 'close'){ this.state.game.balance += this.state.game.totalWin;}
        }
        else 
        {
            this.state.error = {};
            this.state.error.id = 1;
        }
        
        return (this.state.error ) ? this.response.error(this.state) : this.response[this.state.game.action](this.state);
    }
}

exports.ProcessGame = ProcessGame;
