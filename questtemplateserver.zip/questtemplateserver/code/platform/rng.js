class RNG 
{
    constructor()
    {
        this.cheat = [];
    }
    
    setCheats(cheats) 
    {
        this.cheat = cheats;
    }
    
    getNextRandom(upper)
    {
        return (this.cheat.length>0) ? this.cheat.shift() : Math.floor(Math.random()*upper);
    }

    getUniqueRandomNumbers(min, max, count)
    {
        const arrNum = Array.from(new Array(max-min),(v,i)=>i)
        const cheat = this.cheat.slice();
        cheat.forEach(v => arrNum.splice(arrNum.indexOf(v), 1));
        const suffle = arrNum.map((a) => [this.getNextRandom(max*count),a]).sort((a,b) => a[0]-b[0]).map((a) => a[1])
        return cheat.concat(suffle)
    }
}

exports.RNG = new RNG();
