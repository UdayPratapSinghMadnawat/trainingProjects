# Template Server

> version - 1.1.1

```
API simulator for creating template for games.
```


## Steps to Run Server 
* Install all dependencies - npm i 
* Run Slot Server - npm run s 
* Run Roulette Server - npm run r 
* Run Blackjack Server - npm run b 

## Slot Request Format 

> Refresh 
```
{
  "action":"refresh"
}
```

> Spin 
```
{
  "action":"spin",
  "stakePerLine":1
}
```

> Freespin 
```
{
  "action": "freespin"
}
```

## Roulette Request Format 

> Refresh 
```
{
  "action":"refresh"
}
```

> Play 
```
{
  "action":"play",
  "bets" : [ { id : 1, bet : 5 }, { id : 3, bet : 2 } ]
}
```

## Blackjack Request Format 

> Refresh 
```
{
  "action":"refresh"
}
```

> Deal 
```
{
  "action":"deal",
  "bets" : [ {"id":1,"bet":5},{"id":2,"bet":2},{"id":3,"bet":3}],
}
```

> Hit 
```
{
  "action":"hit",
  "bets" : [ {"id":1}]
}
```

> Double 
```
{
  "action":"double",
  "bets" : [ {"id":1}]
}
```

> Split 
```
{
  "action":"split",
  "bets" : [ {"id":1}]
}
```

> Stand
```
{
  "action":"stand",
  "bets" : [ {"id":2}]
}
```

> Insurance 
```
{
  "action":"insurance",
  "bets" : [ {"id":1,"insured":"yes"},{"id":2,"insured":"no"},{"id":3,"insured":"yes"}]
}

## Known Issues 

* Multiplayer is not suppported 
* Insurance is not supported in Blackjack

## Change Log

> 1.0.0

```
* Added Blackjack with 
  - Split
  - Double  
* Added Roulette 
* Added Slot with 
  - Free Spin
  - Retrigger in free spin 
  - Expending wild  
  - Random Wild 
  - Sticky Wild 
```