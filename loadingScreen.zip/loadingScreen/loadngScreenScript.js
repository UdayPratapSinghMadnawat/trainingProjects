var abloadingStatus = document.getElementById("loadingStatus");
var abloadbar2 = document.getElementById("loadbar2");
var width1 = 0 ;
 var ab1 = setInterval(setPosition1,100);
 function setPosition1(){
     if (width1 >= 100) {
         clearInterval(ab1);
     }
     else {
     width1 +=1;
abloadbar2.style.width = width1 + "%";
abloadingStatus.innerHTML="Loading"+" " + width1+"%";
     }

}

